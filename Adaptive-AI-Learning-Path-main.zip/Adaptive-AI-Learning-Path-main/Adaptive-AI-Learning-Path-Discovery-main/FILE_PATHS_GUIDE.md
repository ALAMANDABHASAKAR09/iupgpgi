# COMPLETE FILE PATH & QUESTION LOADING GUIDE

## 📍 Your Question Files

Located in: `c:\Users\anilp\Downloads\Adaptive-AI-Learning-Path-Discovery-main\Adaptive-AI-Learning-Path-Discovery-main\public\`

| File                    | Location                         | Count | Type               |
| ----------------------- | -------------------------------- | ----- | ------------------ |
| mcq_questions.json      | `public/mcq_questions.json`      | 26    | MCQ (with 6 tags)  |
| mcms_questions.json     | `public/mcms_questions.json`     | 1     | MCMS (RAG/Vector)  |
| profiler_questions.json | `public/profiler_questions.json` | 3     | Profiler questions |

## 🎯 How Your App Works

### Step 1: Dev Server Starts (npm run dev)

```
vite.config.js:
  base: "/Adaptive-AI-Learning-Path-Discovery/"

This tells Vite to serve files from this base path
```

### Step 2: Questions Get Fetched (When you reach Step 5)

```javascript
// Home.jsx line ~100
const baseUrl = import.meta.env.BASE_URL; // '/Adaptive-AI-Learning-Path-Discovery/'

// These URLs are constructed:
fetch("/Adaptive-AI-Learning-Path-Discovery/mcq_questions.json");
fetch("/Adaptive-AI-Learning-Path-Discovery/mcms_questions.json");
fetch("/Adaptive-AI-Learning-Path-Discovery/profiler_questions.json");
```

### Step 3: Files Are Read & Organized

```
Questions Load (30 total)
  ├─ MCQ Questions: 26
  │  ├─ Generative AI (6 questions)
  │  ├─ Prompt Engineering (2 questions)
  │  ├─ AI Ethics (1 question)
  │  ├─ RAG/Vector (7 questions)
  │  ├─ Langchain (4 questions)
  │  └─ Huggingface (6 questions)
  ├─ MCMS Questions: 1
  │  └─ RAG/Vector (1 question)
  └─ Profiler Questions: 3
     └─ Profiler Tag (3 questions)
```

### Step 4: Assessment Begins

```javascript
// Step5_AdaptiveAssessment.jsx
// Shows 7 questions total:
// - 2 MCQ questions
// - 2 MCMS questions
// - 2 MCQ-Reorder questions
// - 1 ShortAnswer question (OR Profiler questions if needed)
```

## ✅ Actual Question Tags & Counts

```
Total in System: 30 questions

By Tag:
1. Generative AI          → 6 questions  (tags: genai_b_001-005, 007)
2. Prompt Engineering     → 2 questions  (tags: genai_b_006, 008)
3. AI Ethics              → 1 question   (tag: genai_b_009)
4. RAG/Vector             → 8 questions  (7 MCQ + 1 MCMS)
5. Langchain              → 4 questions  (tags: langchain_d_001-004)
6. Huggingface            → 6 questions  (tag: huggingface_b_001+)
7. Profiler               → 3 questions  (tags: prof_001-003)
```

## 🔗 File Path References

### In Home.jsx (Data Loading)

```javascript
// Line ~95-165
const baseUrl = import.meta.env.BASE_URL;
// Result: '/Adaptive-AI-Learning-Path-Discovery/'

const mcqPath = `${baseUrl}mcq_questions.json`;
// Result: '/Adaptive-AI-Learning-Path-Discovery/mcq_questions.json'

const mcmsPath = `${baseUrl}mcms_questions.json`;
// Result: '/Adaptive-AI-Learning-Path-Discovery/mcms_questions.json'

const profilerPath = `${baseUrl}profiler_questions.json`;
// Result: '/Adaptive-AI-Learning-Path-Discovery/profiler_questions.json'

// Then fetches:
Promise.all([fetch(mcqPath), fetch(mcmsPath), fetch(profilerPath)]);
```

### In vite.config.js

```javascript
export default defineConfig({
  base: "/Adaptive-AI-Learning-Path-Discovery/", // This sets the base path
  plugins: [react()],
  // ... rest of config
});
```

## 🧪 Test Files Are Loading

### Method 1: Debug Page (Easiest)

1. Visit: `http://localhost:5174/Adaptive-AI-Learning-Path-Discovery/debug.html`
2. Scroll down to see:
   - All files and their status (✓ OK or ✗ FAILED)
   - Sample questions
   - Tag analysis
   - Question counts

### Method 2: Browser Console (F12)

1. Press F12 to open DevTools
2. Go to Console tab
3. Paste this:

```javascript
// Test each file separately
fetch("/Adaptive-AI-Learning-Path-Discovery/mcq_questions.json")
  .then((r) => r.json())
  .then((data) => console.log("MCQ:", data.length, "questions"));

fetch("/Adaptive-AI-Learning-Path-Discovery/mcms_questions.json")
  .then((r) => r.json())
  .then((data) => console.log("MCMS:", data.length, "questions"));

fetch("/Adaptive-AI-Learning-Path-Discovery/profiler_questions.json")
  .then((r) => r.json())
  .then((data) => console.log("Profiler:", data.length, "questions"));
```

4. You should see:
   ```
   MCQ: 26 questions
   MCMS: 1 questions
   Profiler: 3 questions
   ```

### Method 3: Network Tab

1. Press F12 to open DevTools
2. Go to Network tab
3. Navigate to Step 5 (Assessment)
4. Look for these requests:

   - `mcq_questions.json` → Status should be **200**
   - `mcms_questions.json` → Status should be **200**
   - `profiler_questions.json` → Status should be **200**

5. If any show **404** → Files aren't being found

## 🐛 If You See "No Question Available"

### Checklist to Fix:

```
❑ Step 1: Verify Files Exist
   Command: dir public/
   Look for: mcq_questions.json, mcms_questions.json, profiler_questions.json

❑ Step 2: Verify Files Load
   Use: Debug page at /debug.html
   Expected: All 3 files show status "✓ OK"

❑ Step 3: Check Console Logs
   Open F12 → Console
   Navigate to Step 5
   Look for [Step5] messages

❑ Step 4: Verify Pool Structure
   Expected log: [Step5] Preprocessed pool structure
   Should show tags: ['Generative AI', 'Prompt Engineering', ...]

❑ Step 5: Check Tag Levels
   localStorage check:
   JSON.parse(localStorage.getItem('adaptive-user-profile')).tagLevels
   Should have 6 tags with value 5 each
```

## 📊 Current System Structure

```
App (src/App.jsx)
  └─ Home.jsx
      ├─ Loads courses (fetchAllCourses)
      ├─ When Step 5 is reached:
      │   ├─ Fetch mcq_questions.json
      │   ├─ Fetch mcms_questions.json
      │   ├─ Fetch profiler_questions.json
      │   ├─ Call preprocessQuestionBank()
      │   ├─ Initialize userProfile
      │   └─ Initialize questionPool
      │
      └─ Step5_AdaptiveAssessment
          ├─ Receives: questionPool, allQuestions, allTags, userProfile
          ├─ Calls: pickNextForQuotas() to select question
          ├─ Shows: Question with renderOptions()
          ├─ Handles: Answer submission
          └─ Calls: selectNextQuestion() for adaptive logic
```

## 🔧 Debugging with Console Logs (Already Added!)

When you navigate to Step 5, look for:

```javascript
[Step5] Loading question banks...
[Step5] Using base URL: /Adaptive-AI-Learning-Path-Discovery/
[Step5] Fetch paths: {
  mcqPath: '/Adaptive-AI-Learning-Path-Discovery/mcq_questions.json',
  mcmsPath: '/Adaptive-AI-Learning-Path-Discovery/mcms_questions.json',
  profilerPath: '/Adaptive-AI-Learning-Path-Discovery/profiler_questions.json'
}

[Step5] MCQ response: 200 OK      ← Should be 200
[Step5] MCMS response: 200 OK     ← Should be 200
[Step5] Profiler response: 200 OK ← Should be 200

[Step5] Loaded question data: { mcq: 26, mcms: 1, profiler: 3 }
[Step5] Filtered questions: { mcq: 26, mcms: 1, profiler: 3 }
[Step5] Combined pool size: 30

[Step5] Unique tags: [           ← Should have 6 tags
  'Generative AI',
  'Prompt Engineering',
  'AI Ethics',
  'RAG/Vector',
  'Langchain',
  'Huggingface'
]

[Step5] Preprocessed pool structure: {
  tags: [ ... ],
  sampleTag: 'Generative AI',
  sampleTagDifficulties: [ '1', '2', '3' ]  ← Should have difficulties
}
```

## 🎨 Visual Diagram: How Questions Flow

```
┌─────────────────────────────────────────────────┐
│  User Navigates to Step 5 (Assessment)          │
└────────────────┬────────────────────────────────┘
                 │
                 ▼
┌─────────────────────────────────────────────────┐
│  Home.jsx useEffect triggers                    │
│  (appState.currentStep === 5)                   │
└────────────────┬────────────────────────────────┘
                 │
        ┌────────┼────────┐
        │        │        │
        ▼        ▼        ▼
   ┌──────┐ ┌──────┐ ┌──────────┐
   │ MCQ  │ │ MCMS │ │ Profiler │
   │ (26) │ │ (1)  │ │   (3)    │
   └──┬───┘ └──┬───┘ └────┬─────┘
      │        │          │
      ▼        ▼          ▼
   ┌──────────────────────────────┐
   │  preprocessQuestionBank()     │
   │  Organize by Tag/Difficulty  │
   └──┬───────────────────────────┘
      │
      ▼
   ┌──────────────────────────────┐
   │  questionPool = {             │
   │    'GenAI': {                 │
   │      1: [...questions],       │
   │      2: [...questions],       │
   │      ...                      │
   │    },                         │
   │    'RAG/Vector': {...},       │
   │    ...                        │
   │  }                            │
   └──┬───────────────────────────┘
      │
      ▼
   ┌──────────────────────────────┐
   │  Step5_AdaptiveAssessment    │
   │  rendered with pool data     │
   └──┬───────────────────────────┘
      │
      ▼
   ┌──────────────────────────────┐
   │  pickNextForQuotas()          │
   │  Find first question          │
   └──┬───────────────────────────┘
      │
      ├─ Success? ──▶ Show Question ✓
      │
      └─ Fail? ──▶ "No Question Available" ✗
```

## 🚀 Quick Test

1. **Start dev server:**

   ```bash
   npm run dev
   ```

2. **Open app:**

   ```
   http://localhost:5174/Adaptive-AI-Learning-Path-Discovery/
   ```

3. **Navigate:**

   - Step 1: Select field
   - Step 2: Select level
   - Step 3: Select topic
   - Step 4: Select duration
   - Step 5: Should see assessment question

4. **If stuck on Step 5:**
   - Check debug page: `http://localhost:5174/Adaptive-AI-Learning-Path-Discovery/debug.html`
   - Open console: F12
   - Look for [Step5] logs
   - Share output here

## 📝 Summary

**Files:** ✅ All 30 questions exist and are properly formatted
**Paths:** ✅ Using `import.meta.env.BASE_URL` for reliability  
**Fetch:** ✅ Should be status 200 when loading from /Adaptive-AI-Learning-Path-Discovery/
**Logging:** ✅ Detailed [Step5] console logs added for debugging

**Next action:** Run the app and check:

1. Does `/debug.html` show all files loaded?
2. Do console logs show [Step5] messages?
3. Does first question appear in Step 5?

Let me know what you see!
