# QUICK REFERENCE CARD

## Essential Info at a Glance

---

## 🔴 THE 8 CRITICAL BUGS

| #   | Bug                            | File                                      | Lines   | Status    |
| --- | ------------------------------ | ----------------------------------------- | ------- | --------- |
| 1   | Set Serialization              | `src/pages/Home.jsx`                      | 54-72   | PATCH 1   |
| 2   | Question Race Condition        | `src/pages/Home.jsx`                      | 91-126  | PATCH 2   |
| 3   | Course Data Inconsistency      | `src/utils/api.js`                        | entire  | PATCH 3   |
| 4   | Question Type Detection        | `src/pages/Home.jsx`                      | 91-126  | PATCH 2   |
| 5   | Assessment Results Persistence | `src/pages/Home.jsx`                      | 188-230 | PATCH 4   |
| 6   | Step6 Input Validation         | `src/components/Wizard/Step6_Results.jsx` | 8-25    | PATCH 5   |
| 7   | Explorer Filter Reset          | `src/components/Explorer/Explorer.jsx`    | 23-24   | PATCH 6   |
| 8   | Missing Error Boundary         | `src/components/ErrorBoundary.jsx` (NEW)  | -       | PATCH 7+8 |

---

## 📋 PATCHES AT A GLANCE

```
PATCH 1 - Set Serialization Fix
File: src/pages/Home.jsx (lines 54-72)
What: Convert Set ↔ Array for localStorage
Time: 5 minutes
Status: ✅ CRITICAL

PATCH 2 - Question Loading Fix
File: src/pages/Home.jsx (lines 91-126)
What: Remove questionPool from dependencies
Time: 10 minutes
Status: ✅ CRITICAL

PATCH 3 - Course Normalization
File: src/utils/api.js (entire)
What: Add normalizeCourse() function
Time: 15 minutes
Status: ✅ CRITICAL

PATCH 4 - Assessment Results Handling
File: src/pages/Home.jsx (lines 188-230)
What: Add defensive checks to handleAdaptiveComplete
Time: 10 minutes
Status: ✅ CRITICAL

PATCH 5 - Step6 Validation
File: src/components/Wizard/Step6_Results.jsx (lines 8-25)
What: Add input validation and fallback UI
Time: 5 minutes
Status: ✅ HIGH

PATCH 6 - Explorer Filter Reset
File: src/components/Explorer/Explorer.jsx (lines 23-24)
What: Reset filters when initialCourses changes
Time: 3 minutes
Status: ✅ HIGH

PATCH 7 - Create ErrorBoundary
File: src/components/ErrorBoundary.jsx (NEW)
What: Create new component
Time: 10 minutes
Status: ✅ RECOMMENDED

PATCH 8 - Wrap App with ErrorBoundary
File: src/App.jsx (imports + wrapper)
What: Import and use ErrorBoundary
Time: 2 minutes
Status: ✅ RECOMMENDED

PATCH 9 - Create useLoadingState Hook
File: src/hooks/useLoadingState.js (NEW)
What: Create new hook
Time: 5 minutes
Status: ✅ OPTIONAL

PATCH 10 - Step1 Accessibility
File: src/components/Wizard/Step1_Field.jsx (fields)
What: Add ARIA labels and semantic HTML
Time: 5 minutes
Status: ✅ RECOMMENDED

TOTAL TIME: ~60-90 minutes
```

---

## 🎯 IMPLEMENTATION ORDER

**MUST DO IN THIS ORDER:**

1. PATCH 1 (Set Serialization) ← Start here
2. PATCH 2 (Question Loading)
3. PATCH 3 (Course Normalization)
4. PATCH 4 (Assessment Results)
5. PATCH 5 (Step6 Validation)
6. PATCH 6 (Explorer Filters)
7. PATCH 7 & 8 (Error Boundary) ← After 1-6 work
8. PATCH 9 & 10 (Optional/Recommended)

---

## ✅ SUCCESS CHECKLIST

**After Phase 1 (Critical Bugs):**

- [ ] No Set serialization errors
- [ ] Questions load (count > 0)
- [ ] Courses display with all fields
- [ ] Assessment completes
- [ ] Results show on Step 6

**After Phase 2 (Architecture):**

- [ ] Errors caught gracefully
- [ ] User sees error messages
- [ ] No full-app crashes

**After Phase 3 (Accessibility):**

- [ ] Tab navigation works
- [ ] ARIA labels present
- [ ] Screen reader reads labels

**After Phase 4 (Build & Test):**

- [ ] `npm run build` → 0 errors
- [ ] Full wizard flow works
- [ ] Dark mode works
- [ ] Mobile layout responsive

---

## 🚀 DEPLOYMENT COMMANDS

```bash
# Test locally
npm run dev

# Build for production
npm run build

# Commit changes
git add .
git commit -m "Fix data flow, course normalization, error handling"

# Deploy to GitHub Pages
git push origin main
```

---

## 📊 STATE OBJECTS

### appState (in Home.jsx)

```javascript
{
  currentStep: 1-7,
  maxStep: number,
  selections: {
    field: string,
    level: string,
    topic: [string],
    duration: [string],
    assessmentAnswers: {},
    assessmentResults: { ... }, // ← CRITICAL
    outcome: string,
    format: [string],
    tools: [string],
    maxHours: number
  }
}
```

### userProfile (in Home.jsx + localStorage)

```javascript
{
  isActive: boolean,
  isComplete: boolean,
  questionsAsked: Set(), // ← CONVERT TO ARRAY FOR STORAGE
  tagLevels: { tag: difficulty },
  tagScores: { tag: score },
  profilerAnswers: {},
  // ...
}
```

### courses

```javascript
[{
  id: string,
  title: string,
  level: string,
  Rating: 0-5,
  totalHours: number,
  ImageURL: string,
  analytics: { ... }
}, ...]
```

---

## 🔧 KEY FIXES SUMMARY

| Issue                      | Fix                    | Impact              |
| -------------------------- | ---------------------- | ------------------- |
| Set not serializable       | Convert to Array       | localStorage works  |
| Question loading loops     | Fix dependencies       | Step 5 works        |
| Inconsistent course fields | Normalize all courses  | CourseCard displays |
| Question types don't match | Normalize types        | Questions load      |
| Results disappear          | Validate & fallback    | Results persist     |
| App crashes on error       | Add ErrorBoundary      | Graceful fallback   |
| Dark mode incomplete       | Add dark: classes      | Dark mode works     |
| Mobile breaks              | Add responsive classes | Mobile works        |

---

## 💡 DEBUGGING TIPS

```javascript
// Check courses loaded
console.log("Courses:", courses.length);
console.log("First course:", courses[0]);

// Check question pool
console.log("Question types:", Object.keys(questionPool));
console.log("MCQ questions:", questionPool["Core ML"]?.[5]?.length);

// Check assessment complete
console.log("Assessment results:", appState.selections.assessmentResults);
console.log("User profile:", userProfile);

// Check localStorage
console.log(JSON.parse(localStorage.getItem("wizard-state")));
console.log(JSON.parse(localStorage.getItem("adaptive-user-profile")));

// Test dark mode
document.documentElement.classList.toggle("dark");
```

---

## 📱 RESPONSIVE BREAKPOINTS

```
xs: 0px (base)
sm: 640px
md: 768px
lg: 1024px
xl: 1280px
2xl: 1536px
```

**Use classes:** `grid-cols-1 sm:grid-cols-2 lg:grid-cols-3`

---

## 🎨 TAILWIND DARK MODE

**Pattern:**

```javascript
className = "bg-white dark:bg-gray-800 text-gray-900 dark:text-white";
```

**Avoid:**

```javascript
// DON'T DO THIS:
className = "dark:bg-white"; // inverted!
```

---

## 📚 DOCUMENTATION MAP

```
README_DEBUGGING_PACKAGE.md
    ↓ (read for overview)
DOCUMENTATION_INDEX.md
    ↓ (navigate using this)
    ├→ QUICK_START_CHECKLIST.md (follow this)
    ├→ DEBUGGING_AND_MODERNIZATION_GUIDE.md (understand bugs)
    ├→ EXACT_CODE_PATCHES.md (copy code)
    └→ ARCHITECTURE_OVERVIEW.md (visualize system)
```

---

## ⏱️ TIME BREAKDOWN

```
Phase 1 (Critical): 60-90 minutes
├─ Patch 1: 5 min
├─ Patch 2: 10 min
├─ Patch 3: 15 min
├─ Patch 4: 10 min
├─ Patch 5: 5 min
├─ Patch 6: 3 min
└─ Test: 20-40 min

Phase 2 (Architecture): 20-30 minutes
├─ Patch 7: 10 min
├─ Patch 8: 2 min
└─ Test: 8-18 min

Phase 3 (Optional): 10-15 minutes
└─ Patch 9-10: 10-15 min

Phase 4 (Build & Test): 30-45 minutes
├─ npm run build: 5 min
├─ npm run dev: 2 min
├─ Manual testing: 20-30 min
└─ Verification: 3-8 min

TOTAL: 2.5-3 hours

```

---

## 🎯 ONE-LINE SUMMARY OF EACH BUG

1. **Set Serialization** - JavaScript Sets can't be JSON.stringify'd
2. **Race Condition** - useEffect dependency array triggers infinite loops
3. **Course Data** - Field names vary across JSON files (title vs courseTitle)
4. **Type Detection** - Question types case-sensitive ('MCQ' vs 'mcq')
5. **Results Lost** - No validation, crashes when profile incomplete
6. **Crashes on Error** - No ErrorBoundary to catch component failures
7. **Filter Persist** - Filters don't reset when new courses load
8. **Questions Infinite** - Race condition in useEffect dependency

---

## ✨ FINAL CHECKLIST

Before submitting as complete:

- [ ] All 8 bugs fixed
- [ ] Phase 1 patches applied (1-6)
- [ ] Phase 2 architecture added (7-8)
- [ ] npm run build succeeds
- [ ] npm run dev works
- [ ] Full wizard completes
- [ ] No console errors
- [ ] Dark mode works
- [ ] Mobile responsive
- [ ] Errors caught gracefully

**If ALL checked → DEPLOYMENT READY ✅**

---

**Last Updated:** December 2024  
**Package Version:** 1.0  
**Status:** Production Ready
