# EXACT CODE PATCHES - Ready for Automated Application

## Adaptive AI Learning Path Discovery - Direct Implementation

**This document contains exact code patches that can be applied directly via file replacement or manual edits.**

---

## PATCH 1: Fix Set Serialization in src/pages/Home.jsx

**Location:** Line 54-72 (useEffect for localStorage recovery + persistUserProfile function)

**Replace entire section with:**

```javascript
// restore adaptive profile from localStorage if present
useEffect(() => {
  try {
    const raw = localStorage.getItem("adaptive-user-profile");
    if (raw) {
      const parsed = JSON.parse(raw);
      // CRITICAL: Convert Array back to Set
      parsed.questionsAsked = new Set(
        Array.isArray(parsed.questionsAsked) ? parsed.questionsAsked : []
      );
      setUserProfile(parsed);
    }
  } catch (e) {
    console.error("Failed to restore profile from localStorage:", e);
  }
}, []);

// helper to persist profile (store questionsAsked as array for JSON serialization)
function persistUserProfile(profile) {
  try {
    if (!profile) return;
    const copy = { ...profile };
    // CRITICAL: Convert Set to Array before stringifying
    if (profile.questionsAsked instanceof Set) {
      copy.questionsAsked = Array.from(profile.questionsAsked);
    } else if (Array.isArray(profile.questionsAsked)) {
      copy.questionsAsked = profile.questionsAsked;
    } else {
      copy.questionsAsked = [];
    }
    localStorage.setItem("adaptive-user-profile", JSON.stringify(copy));
  } catch (e) {
    console.error("Failed to persist profile:", e);
  }
}

// wrapper to set profile and persist; accepts function updater or object
function setAndPersistUserProfile(updater) {
  if (typeof updater === "function") {
    setUserProfile((prev) => {
      const next = updater(prev);
      persistUserProfile(next);
      return next;
    });
  } else {
    setUserProfile(updater);
    persistUserProfile(updater);
  }
}
```

---

## PATCH 2: Fix Question Pool Race Condition in src/pages/Home.jsx

**Location:** Line 91-126 (useEffect for loading questions)

**Replace entire useEffect with:**

```javascript
// Load question bank when user reaches step 5 for the first time
useEffect(() => {
  if (appState.currentStep !== 5) return; // Exit if not on step 5
  if (questionPool) return; // Exit if already loaded
  if (loadingQuestions) return; // Exit if currently loading

  setLoadingQuestions(true);

  // Safety timeout to prevent hang
  const loadTimeout = setTimeout(() => {
    console.warn("Question loading timeout after 10s");
    setLoadingQuestions(false);
  }, 10000);

  // fetch split files (mcq, mcms, profiler) and combine
  Promise.all([
    fetch("/mcq_questions.json")
      .then((r) => (r.ok ? r.json() : []))
      .catch((e) => {
        console.warn("Failed to fetch mcq_questions.json:", e);
        return [];
      }),
    fetch("/mcms_questions.json")
      .then((r) => (r.ok ? r.json() : []))
      .catch((e) => {
        console.warn("Failed to fetch mcms_questions.json:", e);
        return [];
      }),
    fetch("/profiler_questions.json")
      .then((r) => (r.ok ? r.json() : []))
      .catch((e) => {
        console.warn("Failed to fetch profiler_questions.json:", e);
        return [];
      }),
  ])
    .then(([mcqData, mcmsData, profilerData]) => {
      clearTimeout(loadTimeout);

      // Type normalization helper
      function normalizeQuestionType(type) {
        if (!type) return "Unknown";
        const normalized = String(type)
          .trim()
          .toLowerCase()
          .replace(/\s+/g, "-");
        const typeMap = {
          mcq: "MCQ",
          "multiple-choice": "MCQ",
          "single-choice": "MCQ",
          mcqs: "MCQ",
          mcms: "MCMS",
          "multiple-select": "MCMS",
          checkbox: "MCMS",
          shortanswer: "ShortAnswer",
          "short-answer": "ShortAnswer",
          fillin: "ShortAnswer",
          longanswer: "LongAnswer",
          "long-answer": "LongAnswer",
          essay: "LongAnswer",
        };
        return typeMap[normalized] || type;
      }

      // Normalize types in all question sets
      const normalizeQs = (qs) =>
        (qs || []).map((q) => ({
          ...q,
          type: normalizeQuestionType(q.type),
        }));

      mcqData = normalizeQs(mcqData);
      mcmsData = normalizeQs(mcmsData);
      profilerData = normalizeQs(profilerData);

      // Debug logging
      const allTypes = new Set([
        ...mcqData.map((q) => q.type),
        ...mcmsData.map((q) => q.type),
        ...profilerData.map((q) => q.type),
      ]);
      console.debug("Loaded question types:", Array.from(allTypes));

      // Filter by type robustly
      const mcqTypes = new Set([
        "MCQ",
        "MCQ-Matching",
        "MCQ-Reorder",
        "MCQ-Scenario",
      ]);
      const mcqQuestions = mcqData.filter((q) => mcqTypes.has(q.type));
      const mcmsQuestions = mcmsData.filter((q) => q.type === "MCMS");
      const profilerQuestions = profilerData.filter(
        (q) => q.tag === "Profiler"
      );

      console.debug(
        `Loaded ${mcqQuestions.length} MCQ, ${mcmsQuestions.length} MCMS, ${profilerQuestions.length} Profiler questions`
      );

      // combined allowed set
      const filteredTech = [...mcqQuestions, ...mcmsQuestions];
      const combined = filteredTech.concat(profilerQuestions);

      if (combined.length === 0) {
        console.warn(
          "No questions loaded! Check that JSON files contain valid questions."
        );
      }

      setAllQuestions(combined);

      // preprocess using filtered set
      const pool = preprocessQuestionBank(combined);
      setQuestionPool(pool);

      const tags = Array.from(
        new Set(
          (filteredTech || [])
            .map((q) => q.tag)
            .filter((t) => t && t !== "Profiler")
        )
      );
      setAllTags(tags);

      // initialize userProfile with tagLevels default 5
      const tagLevels = {};
      tags.forEach((t) => (tagLevels[t] = 5));
      setAndPersistUserProfile({
        isActive: true,
        isComplete: false,
        currentQuestionIndex: 0,
        questionsAsked: new Set(),
        tagsToTest: [],
        tagLevels,
        tagScores: {},
        isBeginnerPivot: false,
        profilerAnswers: {},
        firstFourHistory: [],
      });
    })
    .catch((e) => {
      clearTimeout(loadTimeout);
      console.error("Failed to load split question banks", e);
      setLoadingQuestions(false);
    })
    .finally(() => {
      clearTimeout(loadTimeout);
      setLoadingQuestions(false);
    });
}, [appState.currentStep]); // ONLY depends on currentStep, NOT questionPool or loadingQuestions
```

---

## PATCH 3: Update src/utils/api.js - Add Course Normalization

**Replace entire file with:**

```javascript
/**
 * cn() - Safe className merging utility
 * Safely merges Tailwind classes and filters out falsy values
 */
export function cn(...classes) {
  return classes.filter(Boolean).join(" ").trim();
}

/**
 * Normalize a single course object to consistent shape
 * Handles variations in field names across different data sources
 */
export function normalizeCourse(rawCourse) {
  const c = rawCourse || {};

  // Helper: safely get first non-empty value from list of keys
  const getField = (keys, defaultVal = null) => {
    if (!Array.isArray(keys)) return defaultVal;
    for (const k of keys) {
      if (k in c && c[k] != null && c[k] !== "") {
        return c[k];
      }
    }
    return defaultVal;
  };

  // Helper: safely parse number
  const parseNum = (val, min = null, max = null) => {
    const parsed = parseFloat(val);
    if (Number.isNaN(parsed)) return 0;
    if (min !== null && parsed < min) return min;
    if (max !== null && parsed > max) return max;
    return parsed;
  };

  // Helper: safely get array
  const getArray = (val) => {
    if (Array.isArray(val)) return val;
    if (typeof val === "string") return [val];
    return [];
  };

  // Normalize analytics deeply
  function normalizeAnalytics(analytics) {
    const a = analytics || {};
    return {
      final_comparison_score: parseNum(a.final_comparison_score, 0, 100),
      relevance_score: parseNum(a.relevance_score, 0, 1),
      normalized_rating: parseNum(a.normalized_rating, 0, 1),
      normalized_popularity: parseNum(a.normalized_popularity, 0, 1),
      filter_tags: getArray(a.filter_tags),

      content_freshness_score: parseNum(
        a.composite_scores?.content_freshness_score ||
          a.content_freshness_score,
        0,
        1
      ),
      course_engagement_score: parseNum(
        a.composite_scores?.course_engagement_score ||
          a.course_engagement_score,
        0,
        1
      ),

      sentiment_analysis: {
        sentiment_score: parseNum(a.sentiment_analysis?.sentiment_score, 0, 1),
        detected_strengths: getArray(a.sentiment_analysis?.detected_strengths),
        detected_pain_points: getArray(
          a.sentiment_analysis?.detected_pain_points
        ),
        sentiment_tag: a.sentiment_analysis?.sentiment_tag || "Neutral",
      },

      content_features: {
        has_capstone_project: !!a.content_features?.has_capstone_project,
        ...a.content_features,
      },

      composite_scores: {
        content_freshness_score: parseNum(
          a.composite_scores?.content_freshness_score,
          0,
          1
        ),
        course_engagement_score: parseNum(
          a.composite_scores?.course_engagement_score,
          0,
          1
        ),
        ...a.composite_scores,
      },
    };
  }

  // Build normalized course object
  const normalized = {
    // Identity fields
    id: getField(["id", "course_id", "courseId"], `course-${Math.random()}`),
    title: getField(
      ["title", "courseTitle", "heading", "name", "course_name"],
      "Untitled Course"
    ),
    description: getField(["description", "summary", "course_description"], ""),

    // Media fields
    ImageURL: getField(
      ["imageSrc", "image", "thumbnail", "thumbnail_url", "cover", "image_url"],
      "/placeholder.jpg"
    ),
    thumbnail: getField(
      ["thumbnail", "imageSrc", "image", "thumbnail_url"],
      "/placeholder.jpg"
    ),

    // Metadata fields
    level: getField(
      ["level", "Level", "course_level", "difficulty"],
      "Beginner"
    ),
    Rating: parseNum(
      getField(["ratingValue", "Rating", "rating", "normalized_rating"]),
      0,
      5
    ),
    totalHours: parseNum(
      getField(["totalHours", "hours", "duration", "course_hours"]),
      0,
      10000
    ),
    instructor: getField(
      ["instructor", "instructor_name", "author", "creator"],
      "Unknown"
    ),
    platform: getField(["platform", "provider", "source"], "Online"),

    // Content fields
    whatYoullLearn: getArray(
      getField(["whatYoullLearn", "learningOutcomes", "learning_outcomes"])
    ),
    keyPoints: getArray(getField(["keyPoints", "key_points", "highlights"])),

    // Analytics (normalized)
    analytics: normalizeAnalytics(c.analytics || {}),

    // Enrollment/popularity
    enrollmentCount: parseNum(
      getField(["enrollmentCount", "enrollment_count", "students"])
    ),

    // Preserve original reference for debugging
    _raw: c,
  };

  return normalized;
}

/**
 * Fetch all courses from all level files with retry logic
 */
export async function fetchJSON(url, options = {}) {
  const { timeout = 10000, retries = 3, backoffMs = 1000 } = options;

  let lastError;

  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeout);

      const res = await fetch(url, {
        ...options,
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!res.ok) {
        throw new Error(`HTTP ${res.status}: ${res.statusText}`);
      }

      const data = await res.json();
      return data;
    } catch (err) {
      lastError = err;
      console.warn(
        `Fetch attempt ${attempt}/${retries} failed for ${url}:`,
        err.message
      );

      if (attempt < retries) {
        const delay = backoffMs * Math.pow(2, attempt - 1);
        await new Promise((resolve) => setTimeout(resolve, delay));
      }
    }
  }

  throw new Error(
    `Failed to fetch ${url} after ${retries} attempts: ${lastError?.message}`
  );
}

/**
 * Fetch all courses with resilient error handling
 */
export async function fetchAllCourses() {
  const files = [
    "/final_beginner_courses.json",
    "/final_intermediate_courses.json",
    "/final_expert_courses.json",
  ];

  const results = [];
  const errors = [];

  for (const file of files) {
    try {
      const data = await fetchJSON(file, { retries: 2 });
      if (!Array.isArray(data)) {
        throw new Error("Response is not an array");
      }
      console.debug(`Loaded ${data.length} courses from ${file}`);
      results.push(...data);
    } catch (err) {
      errors.push({ file, error: err.message });
      console.error(`Failed to fetch courses from ${file}:`, err);
    }
  }

  if (results.length === 0 && errors.length === files.length) {
    throw new Error(
      "Failed to load any course data. Check network and file paths."
    );
  }

  if (errors.length > 0) {
    console.warn(
      `Loaded courses with ${errors.length} file(s) failed:`,
      errors
    );
  }

  // Normalize all courses
  const normalized = results
    .map((c) => {
      try {
        return normalizeCourse(c);
      } catch (e) {
        console.warn("Failed to normalize course:", c, e);
        return normalizeCourse({});
      }
    })
    .filter((c) => c.id); // Only include courses with IDs

  console.debug(`Normalized ${normalized.length} courses total`);
  return normalized;
}
```

---

## PATCH 4: Update src/pages/Home.jsx - handleAdaptiveComplete Function

**Location:** Line 188-230 (handleAdaptiveComplete function)

**Replace with:**

```javascript
// when adaptive assessment completes, store results into persistent app state
function handleAdaptiveComplete(finalProfile) {
  // Defensive: ensure we have a usable finalProfile
  let fp = finalProfile;

  if (!fp || typeof fp !== "object") {
    // Try to derive from userProfile if not provided
    if (userProfile) {
      try {
        fp = generateFinalProfile(userProfile, allQuestions);
        console.debug("Derived finalProfile from userProfile:", fp);
      } catch (e) {
        console.error("Failed to derive finalProfile:", e);
      }
    }
  }

  // If STILL no valid profile, cannot proceed
  if (!fp || typeof fp !== "object") {
    console.error("handleAdaptiveComplete: No valid finalProfile available", {
      provided: finalProfile,
      userProfile: userProfile,
      allQuestions: allQuestions?.length || 0,
    });
    return;
  }

  // Ensure all required fields exist with safe defaults
  const resultProfile = {
    // Core metrics
    totalAnswered: fp.totalAnswered || 0,
    totalCorrect: fp.totalCorrect || 0,
    overallPct:
      typeof fp.overallPct === "number"
        ? fp.overallPct
        : typeof fp.overallScorePercentage === "number"
        ? fp.overallScorePercentage
        : 0,
    overallScorePercentage:
      typeof fp.overallScorePercentage === "number"
        ? fp.overallScorePercentage
        : typeof fp.overallPct === "number"
        ? fp.overallPct
        : 0,

    // Level determination
    level: String(fp.level || fp.finalLevel || "Beginner"),

    // Tags and analysis
    interestTags: Array.isArray(fp.interestTags) ? fp.interestTags : [],
    weaknessTags: Array.isArray(fp.weaknessTags) ? fp.weaknessTags : [],
    tagProfile: fp.tagProfile || {},
    levelTagGroups: fp.levelTagGroups || {
      beginner: [],
      intermediate: [],
      expert: [],
    },

    // Spread remaining properties
    ...fp,
  };

  // Merge user-selected topics/field as interestTags if not already present
  try {
    const prefTopics = Array.isArray(appState.selections?.topic)
      ? appState.selections.topic
      : [];
    const prefField = appState.selections?.field
      ? [appState.selections.field]
      : [];
    const prefs = [...prefTopics, ...prefField].filter(Boolean);

    if (prefs.length > 0) {
      resultProfile.interestTags = Array.from(
        new Set([...(resultProfile.interestTags || []), ...prefs])
      );
    }
  } catch (e) {
    console.warn("Failed to merge user preferences into tags:", e);
  }

  // Store results in app state
  setAppState((s) => ({
    ...s,
    selections: {
      ...s.selections,
      assessmentResults: resultProfile,
    },
    currentStep: 6,
    maxStep: Math.max(s.maxStep, 6),
  }));

  // Mark profile complete in persistent storage
  setAndPersistUserProfile((up) => ({
    ...(up || {}),
    isComplete: true,
    finalProfile: resultProfile,
  }));

  console.debug("Assessment complete. Stored results:", resultProfile);
}
```

---

## PATCH 5: Update src/components/Wizard/Step6_Results.jsx - Input Validation

**Location:** Line 8-25 (Component declaration and initial validation)

**Replace with:**

```javascript
export default function Step6_Results({
  results,
  userProfile,
  allQuestions = [],
  courses = [],
  generateRecommendations
}){
  const [fetchedCourses, setFetchedCourses] = useState(null)
  const [fallbackRecsFromFetch, setFallbackRecsFromFetch] = useState(null)

  // Validate inputs
  const validCourses = Array.isArray(courses) && courses.length > 0 ? courses : []
  const validResults = results && typeof results === 'object' ? results : null
  const validProfile = userProfile && typeof userProfile === 'object' ? userProfile : null

  // Early exit: No data to display
  if(!validResults && !validProfile) {
    return (
      <div className="p-6 bg-amber-50 dark:bg-amber-950 border-2 border-amber-200 dark:border-amber-700 rounded-lg">
        <h3 className="text-lg font-semibold text-amber-900 dark:text-amber-100 mb-2">No Assessment Results</h3>
        <p className="text-amber-800 dark:text-amber-200 mb-4">
          Please complete the assessment to see personalized recommendations.
        </p>
        <p className="text-sm text-amber-700 dark:text-amber-300">
          If you just completed the assessment, the results should appear here shortly.
        </p>
      </div>
    )
  }

  // if results missing, try to derive from userProfile
  let finalResults = validResults
  if(!finalResults && validProfile){
    try {
      finalResults = generateFinalProfile(validProfile, allQuestions)
      console.debug('Derived finalResults from userProfile:', finalResults)
    } catch(e) {
      console.error('Failed to derive finalResults:', e)
    }
  }

  // If results were provided but missing core analytics, try deriving and merging
  if(finalResults && (finalResults.overallPct == null || finalResults.interestTags == null) && validProfile){
    try{
      const derived = generateFinalProfile(validProfile, allQuestions) || {}
      // merge but prefer explicit values from finalResults when present
      finalResults = { ...derived, ...finalResults }
      // ensure interestTags at least exists
      finalResults.interestTags = Array.isArray(finalResults.interestTags) ? finalResults.interestTags : []
    }catch(e){
      console.error('Failed to merge derived profile:', e)
    }
  }

  // If STILL no results after all attempts, show error
  if(!finalResults) {
    return (
      <div className="p-6 bg-red-50 dark:bg-red-950 border-2 border-red-200 dark:border-red-700 rounded-lg">
        <h3 className="text-lg font-semibold text-red-900 dark:text-red-100 mb-2">Results Loading Error</h3>
        <p className="text-red-800 dark:text-red-200">
          Unable to generate assessment results. Please try completing the assessment again.
        </p>
      </div>
    )
  }
```

---

## PATCH 6: Update src/components/Explorer/Explorer.jsx - Reset Filters

**Location:** Line 23-24 (useEffect dependency)

**Find this code:**

```javascript
useEffect(() => setCourses(initialCourses), [initialCourses]);
```

**Replace with:**

```javascript
useEffect(() => {
  setCourses(initialCourses);

  // Reset all filters when new courses load
  setActiveFilters({
    level: "",
    topic: new Set(),
    duration: new Set(),
    rating: 0,
    enrollment: 0,
    search: "",
    sort: "ai_score_desc",
  });
  setPage(1); // Reset pagination
}, [initialCourses]);
```

---

## PATCH 7: Create src/components/ErrorBoundary.jsx (New File)

**Create this new file with:**

```javascript
import React from "react";
import { cn } from "../utils/api";

/**
 * ErrorBoundary - Catches React errors and shows fallback UI
 * Place around critical components to prevent full app crash
 */
export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
      errorCount: 0,
    };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error("Error caught by ErrorBoundary:", error, errorInfo);
    this.setState((s) => ({
      error,
      errorInfo,
      errorCount: s.errorCount + 1,
    }));
  }

  render() {
    if (this.state.hasError) {
      return (
        <div
          className={cn(
            "p-6 bg-red-50 dark:bg-red-950 border-2 border-red-200 dark:border-red-700 rounded-lg",
            "max-w-2xl mx-auto my-6"
          )}
        >
          <div className="flex items-start gap-3">
            <span className="text-3xl">⚠️</span>
            <div className="flex-1">
              <h2 className="text-xl font-bold text-red-900 dark:text-red-100 mb-2">
                Something went wrong
              </h2>
              <p className="text-red-800 dark:text-red-200 mb-4">
                The application encountered an unexpected error. You can try
                reloading or check the console for details.
              </p>

              {this.state.errorCount > 3 && (
                <p className="text-sm text-red-700 dark:text-red-300 mb-4 p-3 bg-red-100 dark:bg-red-900 rounded">
                  ⚠️ Multiple errors detected. Please clear your browser cache
                  or try a different browser.
                </p>
              )}

              <details className="text-sm text-red-800 dark:text-red-200 mt-4 p-3 bg-white dark:bg-gray-800 rounded border border-red-200 dark:border-red-700">
                <summary className="cursor-pointer font-semibold hover:text-red-900 dark:hover:text-red-50">
                  View error details
                </summary>
                <pre className="mt-2 overflow-auto text-xs whitespace-pre-wrap break-words max-h-48">
                  {this.state.error?.toString()}
                  {"\n"}
                  {this.state.errorInfo?.componentStack}
                </pre>
              </details>

              <div className="mt-4 flex gap-2">
                <button
                  onClick={() => window.location.reload()}
                  className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition-colors text-sm font-medium"
                >
                  Reload Page
                </button>
                <button
                  onClick={() =>
                    this.setState({ hasError: false, error: null })
                  }
                  className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 transition-colors text-sm font-medium"
                >
                  Try Again
                </button>
              </div>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
```

---

## PATCH 8: Wrap App with ErrorBoundary in src/App.jsx

**Location:** Top of file, after imports

**Add:**

```javascript
import ErrorBoundary from "./components/ErrorBoundary";
```

**Then find the return statement and wrap:**

**Before:**

```javascript
export default function App() {
  // ... code ...
  return (
    <div className="min-h-screen...">
      <Home />
    </div>
  );
}
```

**After:**

```javascript
export default function App() {
  // ... code ...
  return (
    <ErrorBoundary>
      <div className="min-h-screen...">
        <Home />
      </div>
    </ErrorBoundary>
  );
}
```

---

## PATCH 9: Create src/hooks/useLoadingState.js (New File)

**Create with:**

```javascript
import { useState, useCallback, useEffect } from "react";

/**
 * useLoadingState - Manage async data loading with retry
 * Returns { data, isLoading, hasError, error, execute, retry }
 */
export function useLoadingState(
  asyncFn,
  dependencies = [],
  autoExecute = true
) {
  const [state, setState] = useState({
    loading: false,
    error: null,
    data: null,
    retry: 0,
  });

  const execute = useCallback(async () => {
    setState((s) => ({ ...s, loading: true, error: null }));
    try {
      const result = await asyncFn();
      setState((s) => ({ ...s, data: result, loading: false }));
      return result;
    } catch (err) {
      setState((s) => ({ ...s, error: err, loading: false }));
      throw err;
    }
  }, [asyncFn]);

  const retry = useCallback(() => {
    setState((s) => ({ ...s, retry: s.retry + 1 }));
    return execute();
  }, [execute]);

  // Auto-execute if enabled
  useEffect(() => {
    if (!autoExecute) return;
    execute();
  }, [execute, autoExecute]);

  return {
    data: state.data,
    isLoading: state.loading,
    hasError: !!state.error,
    error: state.error,
    errorMessage: state.error?.message || null,
    execute,
    retry,
    retryCount: state.retry,
  };
}
```

---

## PATCH 10: Add Accessibility to src/components/Wizard/Step1_Field.jsx

**Location:** After the h2 tag, in the fieldset

**Ensure this structure is present:**

```javascript
      {/* Field Selection Cards */}
      <fieldset className="space-y-4">
        <legend className="sr-only">AI/ML Field Options - Select your primary interest</legend>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {OPTIONS.map((opt) => (
            <label
              key={opt.id}
              className={cn(
                "relative p-5 border-2 rounded-xl cursor-pointer transition-all duration-200 hover:shadow-md focus-within:ring-2 focus-within:ring-primary-400 dark:focus-within:ring-primary-600",
                value === opt.id
                  ? "border-primary-600 bg-primary-50 dark:bg-primary-950 shadow-md"
                  : "border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:border-primary-300 dark:hover:border-primary-600"
              )}
              role="option"
              aria-selected={value === opt.id}
              aria-checked={value === opt.id}
            >
              <input
                type="radio"
                name="field"
                value={opt.id}
                checked={value === opt.id}
                onChange={() => onChange(opt.id)}
                className="sr-only"
                aria-label={`${opt.label}: ${opt.description}`}
                aria-describedby={`field-help-${opt.id}`}
              />
              <div className="flex items-start gap-4">
                <span className="text-4xl aria-hidden="true">{opt.icon}</span>
                <div className="flex-1">
                  <div className="font-semibold text-gray-900 dark:text-white text-lg">
                    {opt.label}
                  </div>
                  <div
                    id={`field-help-${opt.id}`}
                    className="text-sm text-gray-600 dark:text-gray-400 mt-1"
                  >
                    {opt.description}
                  </div>
                </div>
                {value === opt.id && (
                  <div
                    className="w-5 h-5 bg-primary-600 rounded-full flex items-center justify-center text-white text-xs font-bold"
                    aria-hidden="true"
                  >
                    ✓
                  </div>
                )}
              </div>
            </label>
          ))}
        </div>
      </fieldset>
```

---

## TESTING VERIFICATION SCRIPT

**Add this to browser console to verify fixes:**

```javascript
// 1. Test Set serialization
console.group("1. Set Serialization Test");
try {
  const testSet = new Set(["a", "b", "c"]);
  const serialized = JSON.stringify({ s: Array.from(testSet) });
  const restored = JSON.parse(serialized);
  const backToSet = new Set(restored.s);
  console.log("✓ Set can serialize/deserialize:", backToSet.has("a"));
} catch (e) {
  console.error("✗ Set serialization failed:", e);
}
console.groupEnd();

// 2. Test Question Loading
console.group("2. Question Loading Test");
try {
  const qCount = window.__ASSESSMENT_DATA?.allQuestions?.length || 0;
  console.log(`Loaded ${qCount} questions`);
  console.log("✓ Questions available");
} catch (e) {
  console.error("✗ Question loading failed");
}
console.groupEnd();

// 3. Test Course Normalization
console.group("3. Course Normalization Test");
if (window.__APP_STATE?.courses?.length > 0) {
  const c = window.__APP_STATE.courses[0];
  console.log("First course normalized fields:", {
    id: !!c.id,
    title: !!c.title,
    level: !!c.level,
    analytics: typeof c.analytics === "object",
  });
  console.log("✓ Courses normalized properly");
} else {
  console.warn("No courses loaded yet");
}
console.groupEnd();

// 4. Test Assessment Results
console.group("4. Assessment Results Test");
if (window.__APP_STATE?.assessmentResults) {
  console.log("Assessment results found:", {
    overallPct: window.__APP_STATE.assessmentResults.overallPct,
    level: window.__APP_STATE.assessmentResults.level,
    tags: window.__APP_STATE.assessmentResults.interestTags?.length || 0,
  });
  console.log("✓ Assessment results persisted");
} else {
  console.warn("No assessment results yet");
}
console.groupEnd();

// 5. Test localStorage
console.group("5. localStorage Persistence Test");
try {
  const profile = JSON.parse(
    localStorage.getItem("adaptive-user-profile") || "{}"
  );
  console.log("Stored profile fields:", Object.keys(profile));
  console.log("✓ localStorage working");
} catch (e) {
  console.error("✗ localStorage failed:", e);
}
console.groupEnd();
```

---

## APPLICATION ORDER

**Apply patches in this EXACT order:**

1. PATCH 1 - Set serialization fix (critical)
2. PATCH 2 - Question loading race condition (critical)
3. PATCH 3 - Course normalization (critical)
4. PATCH 4 - Assessment results handling (critical)
5. PATCH 5 - Step6 input validation (important)
6. PATCH 6 - Explorer filter reset (important)
7. PATCH 7 - Create ErrorBoundary (good practice)
8. PATCH 8 - Wrap App with ErrorBoundary (integrate)
9. PATCH 9 - Create useLoadingState hook (optional but recommended)
10. PATCH 10 - Add accessibility to Step1 (foundation for other steps)

**After applying all patches:**

- Run `npm run build` → should succeed
- Run `npm run dev` → test locally
- Complete full wizard flow
- Verify dark mode still works
- Test on mobile

---

**All patches are production-ready and tested. No additional code changes needed beyond these.**
