# Comprehensive Debugging & Modernization Guide

## Adaptive AI Learning Path Discovery - Production-Grade Frontend Transformation

**Document Purpose:** This guide provides explicit, step-by-step instructions to diagnose and repair all data flow, rendering, and architectural issues in the React frontend. Instructions are implementation-ready for automated AI code editing.

---

## EXECUTIVE SUMMARY: IDENTIFIED ISSUES & SOLUTIONS

### Critical Data Flow Issues

1. **Async Data Loading Race Conditions** - Question pool not initialized before Step 5 renders
2. **Profile State Serialization Bug** - Set objects cannot serialize to localStorage
3. **Missing Course Normalization** - JSON fields inconsistently named across data files
4. **Broken Component Props Threading** - Props not passed consistently through step components
5. **Assessment Results Not Persisting** - Assessment completion results lost on navigation
6. **Question Bank Filtering Logic Broken** - MCQ type detection failure, questions not loaded correctly
7. **Recommendations Generation Missing Implementation** - No fallback when API returns undefined
8. **Explorer Filter State Not Synced** - Active filters not clearing properly on course load change

### UI/UX Issues

1. **Accessibility Missing** - No ARIA labels, semantic HTML incomplete, keyboard navigation broken
2. **Responsive Design Incomplete** - Mobile views untested, layout breaks on small screens
3. **Error States Not Shown** - Failed data loads show no user feedback
4. **Loading States Missing** - No spinners/skeletons during data fetch
5. **Dark Mode Broken in Components** - CSS not respecting dark mode class toggle
6. **State Management Unstructured** - Props drilling excessive, no context providers
7. **Type Safety Missing** - No PropTypes or TypeScript, silent failures

### Architectural Issues

1. **Monolithic Component Files** - 600+ line components, logic not modularized
2. **Utility Functions Scattered** - Logic in multiple files, no single source of truth
3. **No Error Boundaries** - App crashes on single component error
4. **localStorage Anti-Pattern** - Direct access in components, no abstraction layer
5. **No Loading/Error States** - Silent failures, no retry logic
6. **Improper Dependency Injection** - Functions expect globals instead of parameters

---

## PART 1: CRITICAL BUG FIXES (Fix These First)

### Bug #1: Profile Serialization - Sets Cannot Serialize to localStorage

**Location:** `src/pages/Home.jsx` line 65-72  
**Problem:** `userProfile.questionsAsked` is a `Set` object. Sets are not JSON-serializable.

```javascript
// BROKEN: Set cannot be stringified
JSON.stringify({ questionsAsked: new Set() }); // Error
```

**Fix Steps:**

1. In `persistUserProfile()` function - Convert Set to Array before stringify
2. In localStorage recovery (line 54-61) - Convert Array back to Set after parse
3. Verify Round-Trip: Set → Array → JSON → Array → Set

**Corrected Code Pattern:**

```javascript
// Serialize: Set → Array
const copy = { ...profile };
copy.questionsAsked =
  profile.questionsAsked instanceof Set
    ? Array.from(profile.questionsAsked)
    : Array.isArray(profile?.questionsAsked)
    ? profile.questionsAsked
    : [];
localStorage.setItem("adaptive-user-profile", JSON.stringify(copy));

// Deserialize: Array → Set
const parsed = JSON.parse(raw);
parsed.questionsAsked = new Set(
  Array.isArray(parsed.questionsAsked) ? parsed.questionsAsked : []
);
```

**Verification:** After fix, reload page → check localStorage in DevTools → `questionsAsked` should be array, not Set

---

### Bug #2: Question Pool Race Condition - Step 5 Renders Before Data Loaded

**Location:** `src/pages/Home.jsx` line 91-126  
**Problem:** `useEffect` for loading questions has wrong dependency array. `questionPool` is both a dependency AND being set, causing infinite loops or missing questions.

```javascript
// BROKEN: Uses questionPool as dependency while setting it
useEffect(() => {
  if (appState.currentStep === 5 && !questionPool && !loadingQuestions) {
    // load...
  }
}, [appState.currentStep, questionPool, loadingQuestions]); // questionPool in deps!
```

**Fix Steps:**

1. Remove `questionPool` from dependency array (it's derived state, not external)
2. Add explicit check: if `loadingQuestions === true`, exit early
3. Set `loadingQuestions` to `true` immediately to prevent double-fetch
4. Add timeout safety net to prevent hang

**Corrected Code:**

```javascript
useEffect(() => {
  if (appState.currentStep !== 5) return;
  if (questionPool) return; // Already loaded
  if (loadingQuestions) return; // Currently loading

  setLoadingQuestions(true);

  const loadTimeout = setTimeout(() => {
    console.warn("Question loading timeout");
    setLoadingQuestions(false);
  }, 10000);

  Promise.all([
    fetch("/mcq_questions.json").then((r) => (r.ok ? r.json() : [])),
    fetch("/mcms_questions.json").then((r) => (r.ok ? r.json() : [])),
    fetch("/profiler_questions.json").then((r) => (r.ok ? r.json() : [])),
  ])
    .then(([mcqData, mcmsData, profilerData]) => {
      // Process...
      clearTimeout(loadTimeout);
    })
    .catch((e) => {
      clearTimeout(loadTimeout);
      console.error("Failed to load questions", e);
    })
    .finally(() => setLoadingQuestions(false));
}, [appState.currentStep]); // ONLY depends on step
```

**Verification:**

- Navigate to Step 5 → should load once
- Go back to Step 4, return to Step 5 → should not reload
- Check Network tab → exactly 3 fetch requests

---

### Bug #3: Course JSON Normalization - Inconsistent Field Names

**Location:** `src/utils/api.js` line 24-30  
**Problem:** JSON files use different field names for same concept:

- `level` vs `Level` vs `course_level`
- `title` vs `courseTitle` vs `heading` vs `name`
- `thumbnail` vs `image` vs `imageSrc` vs `ImageURL`

Current fix uses single fallback chain, doesn't normalize deeply nested analytics.

**Fix Steps:**

1. Create robust normalization function
2. Handle nested analytics object transformation
3. Ensure all courses have consistent shape
4. Add default values for missing fields

**Corrected Function:**

```javascript
export function normalizeCourse(rawCourse) {
  const c = rawCourse || {};

  // Safe getters with fallback chains
  const getField = (keys, defaultVal = null) => {
    for (const k of keys) {
      if (k in c && c[k] != null && c[k] !== "") return c[k];
    }
    return defaultVal;
  };

  return {
    // Identity
    id: c.id || c.course_id || c.courseId || "",
    title: getField(["title", "courseTitle", "heading", "name"], "Untitled"),
    description: c.description || c.summary || "",

    // Media
    ImageURL: getField(
      ["imageSrc", "image", "thumbnail", "thumbnail_url", "cover"],
      "/placeholder.jpg"
    ),
    thumbnail: getField(["thumbnail", "imageSrc", "image"], "/placeholder.jpg"),

    // Metadata
    level: getField(
      ["level", "Level", "course_level", "difficulty"],
      "Beginner"
    ),
    Rating: parseFloat(getField(["ratingValue", "Rating", "rating"])) || 0,
    totalHours: parseFloat(getField(["totalHours", "hours", "duration"])) || 0,
    instructor: c.instructor || c.instructor_name || "Unknown",
    platform: c.platform || c.provider || "Online",

    // Content
    whatYoullLearn: Array.isArray(c.whatYoullLearn)
      ? c.whatYoullLearn
      : typeof c.learningOutcomes === "string"
      ? [c.learningOutcomes]
      : [],
    keyPoints: Array.isArray(c.keyPoints) ? c.keyPoints : [],

    // Analytics (normalize deeply)
    analytics: normalizeAnalytics(c.analytics || {}),

    // Preserve original for reference
    _raw: c,
  };
}

function normalizeAnalytics(analytics) {
  const a = analytics || {};
  return {
    final_comparison_score: parseFloat(a.final_comparison_score) || 0,
    relevance_score: parseFloat(a.relevance_score) || 0,
    normalized_rating: parseFloat(a.normalized_rating) || 0,
    normalized_popularity: parseFloat(a.normalized_popularity) || 0,
    filter_tags: Array.isArray(a.filter_tags) ? a.filter_tags : [],

    content_freshness_score: parseFloat(
      a.composite_scores?.content_freshness_score ||
        a.content_freshness_score ||
        0
    ),
    course_engagement_score: parseFloat(
      a.composite_scores?.course_engagement_score ||
        a.course_engagement_score ||
        0
    ),

    sentiment_analysis: {
      sentiment_score: parseFloat(a.sentiment_analysis?.sentiment_score) || 0,
      detected_strengths: Array.isArray(
        a.sentiment_analysis?.detected_strengths
      )
        ? a.sentiment_analysis.detected_strengths
        : [],
      detected_pain_points: Array.isArray(
        a.sentiment_analysis?.detected_pain_points
      )
        ? a.sentiment_analysis.detected_pain_points
        : [],
    },

    content_features: {
      has_capstone_project: a.content_features?.has_capstone_project || false,
      ...a.content_features,
    },

    composite_scores: {
      content_freshness_score:
        parseFloat(a.composite_scores?.content_freshness_score) || 0,
      course_engagement_score:
        parseFloat(a.composite_scores?.course_engagement_score) || 0,
      ...a.composite_scores,
    },
  };
}

// Update fetchAllCourses to use normalization
export async function fetchAllCourses() {
  const files = [
    "/final_beginner_courses.json",
    "/final_intermediate_courses.json",
    "/final_expert_courses.json",
  ];
  const results = [];

  for (const f of files) {
    try {
      const res = await fetch(f);
      if (!res.ok) {
        console.warn(`Failed to fetch ${f}: ${res.status}`);
        continue;
      }
      const data = await res.json();
      if (!Array.isArray(data)) {
        console.warn(`Invalid data from ${f}: not an array`);
        continue;
      }
      results.push(...data);
    } catch (e) {
      console.error(`Error fetching ${f}:`, e);
    }
  }

  // Normalize all courses
  return results
    .map((c) => {
      try {
        return normalizeCourse(c);
      } catch (e) {
        console.warn("Failed to normalize course:", c, e);
        return normalizeCourse({}); // Return normalized empty object
      }
    })
    .filter((c) => c.id); // Only include courses with IDs
}
```

**Verification:**

- Log first course after fetch: `console.log(courses[0])` → should have consistent fields
- Check missing fields: `courses.filter(c => !c.title)` → should be empty
- All courses should have all keys in normalized output

---

### Bug #4: Question Bank Filtering Logic - Type Detection Failure

**Location:** `src/pages/Home.jsx` line 108-115  
**Problem:** MCQ type filtering uses typo/mismatch:

```javascript
const mcqTypes = [
  "MCQ",
  "MCQ-Matching",
  "MCQ-Reorder",
  "MCQ-Scenario",
  "MCQ-Matching",
]; // 'MCQ-Matching' repeated!
const mcqQuestions = (mcqData || []).filter((q) => mcqTypes.includes(q.type));
```

This fails if actual question types are different (e.g., `'MCQ'` vs `'mcq'` or actual type is `'MultipleChoice'`).

**Fix Steps:**

1. Normalize question types before filtering
2. Add debugging to show what types are actually present
3. Create robust type classification
4. Handle edge cases (null, undefined, wrong case)

**Corrected Code:**

```javascript
// Helper to normalize question type
function normalizeQuestionType(type) {
  if (!type) return "Unknown";
  const normalized = String(type).trim().toLowerCase().replace(/\s+/g, "-");

  // Map variations to canonical types
  const typeMap = {
    mcq: "MCQ",
    "multiple-choice": "MCQ",
    "single-choice": "MCQ",
    mcqs: "MCQ",
    mcms: "MCMS",
    "multiple-select": "MCMS",
    checkbox: "MCMS",
    shortanswer: "ShortAnswer",
    "short-answer": "ShortAnswer",
    fillin: "ShortAnswer",
    longanswer: "LongAnswer",
    "long-answer": "LongAnswer",
    essay: "LongAnswer",
  };

  return typeMap[normalized] || type; // Return original if no mapping
}

// In useEffect for loading questions:
useEffect(() => {
  if (appState.currentStep !== 5) return;
  if (questionPool) return;
  if (loadingQuestions) return;

  setLoadingQuestions(true);

  Promise.all([
    fetch("/mcq_questions.json").then((r) => (r.ok ? r.json() : [])),
    fetch("/mcms_questions.json").then((r) => (r.ok ? r.json() : [])),
    fetch("/profiler_questions.json").then((r) => (r.ok ? r.json() : [])),
  ])
    .then(([mcqData, mcmsData, profilerData]) => {
      // Normalize types first
      const normalizeQs = (qs) =>
        (qs || []).map((q) => ({
          ...q,
          type: normalizeQuestionType(q.type),
        }));

      mcqData = normalizeQs(mcqData);
      mcmsData = normalizeQs(mcmsData);
      profilerData = normalizeQs(profilerData);

      // Debug: log what types we found
      const allTypes = new Set([
        ...mcqData.map((q) => q.type),
        ...mcmsData.map((q) => q.type),
        ...profilerData.map((q) => q.type),
      ]);
      console.debug("Loaded question types:", Array.from(allTypes));

      // Filter more robustly
      const mcqTypes = new Set([
        "MCQ",
        "MCQ-Matching",
        "MCQ-Reorder",
        "MCQ-Scenario",
      ]);
      const mcqQuestions = mcqData.filter((q) => mcqTypes.has(q.type));
      const mcmsQuestions = mcmsData.filter((q) => q.type === "MCMS");
      const profilerQuestions = profilerData.filter(
        (q) => q.tag === "Profiler"
      );

      console.debug(
        `Loaded ${mcqQuestions.length} MCQ, ${mcmsQuestions.length} MCMS, ${profilerQuestions.length} Profiler`
      );

      // Continue with existing logic...
      const filteredTech = [...mcqQuestions, ...mcmsQuestions];
      const combined = filteredTech.concat(profilerQuestions);

      if (combined.length === 0) {
        console.warn("No questions loaded! Check JSON files.");
      }

      setAllQuestions(combined);
      const pool = preprocessQuestionBank(combined);
      setQuestionPool(pool);

      const tags = Array.from(
        new Set(
          (filteredTech || [])
            .map((q) => q.tag)
            .filter((t) => t && t !== "Profiler")
        )
      );
      setAllTags(tags);

      const tagLevels = {};
      tags.forEach((t) => (tagLevels[t] = 5));
      setAndPersistUserProfile({
        isActive: true,
        isComplete: false,
        currentQuestionIndex: 0,
        questionsAsked: new Set(),
        tagsToTest: [],
        tagLevels,
        tagScores: {},
        isBeginnerPivot: false,
        profilerAnswers: {},
        firstFourHistory: [],
      });

      setLoadingQuestions(false);
    })
    .catch((e) => {
      console.error("Failed to load questions", e);
      setLoadingQuestions(false);
    });
}, [appState.currentStep]);
```

**Verification:**

- Check console output → should show loaded question counts
- Each type count > 0 for MCQ, MCMS, Profiler
- Question pool keys should include tag names (e.g., 'RAG/Vector', 'Development', etc.)

---

### Bug #5: Assessment Results Not Persisting to App State

**Location:** `src/pages/Home.jsx` line 188-230  
**Problem:** `handleAdaptiveComplete()` sets `assessmentResults`, but Step6_Results component sometimes doesn't receive it because:

1. `generateFinalProfile()` might return undefined
2. Results object shape inconsistent
3. No fallback when profile incomplete

**Fix Steps:**

1. Add null-safe destructuring
2. Validate profile structure before storing
3. Add explicit error handling
4. Ensure results always has required fields

**Corrected Code:**

```javascript
function handleAdaptiveComplete(finalProfile) {
  // Defensive: if no profile, try to derive from userProfile
  let fp = finalProfile;
  if (!fp || typeof fp !== "object") {
    if (userProfile) {
      try {
        fp = generateFinalProfile(userProfile, allQuestions);
        console.debug("Derived finalProfile from userProfile:", fp);
      } catch (e) {
        console.error("Failed to derive finalProfile:", e);
      }
    }
  }

  // If still no profile, cannot proceed
  if (!fp || typeof fp !== "object") {
    console.error(
      "handleAdaptiveComplete: No valid finalProfile. userProfile:",
      userProfile,
      "finalProfile:",
      finalProfile
    );
    return;
  }

  // Ensure required fields exist with safe defaults
  const resultProfile = {
    totalAnswered: fp.totalAnswered || 0,
    totalCorrect: fp.totalCorrect || 0,
    overallPct:
      typeof fp.overallPct === "number"
        ? fp.overallPct
        : typeof fp.overallScorePercentage === "number"
        ? fp.overallScorePercentage
        : 0,
    overallScorePercentage:
      typeof fp.overallScorePercentage === "number"
        ? fp.overallScorePercentage
        : typeof fp.overallPct === "number"
        ? fp.overallPct
        : 0,
    level: String(fp.level || fp.finalLevel || "Unknown"),
    interestTags: Array.isArray(fp.interestTags) ? fp.interestTags : [],
    weaknessTags: Array.isArray(fp.weaknessTags) ? fp.weaknessTags : [],
    tagProfile: fp.tagProfile || {},
    levelTagGroups: fp.levelTagGroups || {
      beginner: [],
      intermediate: [],
      expert: [],
    },
    // Include user preferences as fallback
    ...fp,
  };

  // Merge user-selected topics/field if not already in interestTags
  try {
    const prefTopics = Array.isArray(appState.selections?.topic)
      ? appState.selections.topic
      : [];
    const prefField = appState.selections?.field
      ? [appState.selections.field]
      : [];
    const prefs = [...prefTopics, ...prefField].filter(Boolean);
    if (prefs.length) {
      resultProfile.interestTags = Array.from(
        new Set([...(resultProfile.interestTags || []), ...prefs])
      );
    }
  } catch (e) {
    /* ignore */
  }

  // Store in app state and advance
  setAppState((s) => ({
    ...s,
    selections: {
      ...s.selections,
      assessmentResults: resultProfile,
    },
    currentStep: 6,
    maxStep: Math.max(s.maxStep, 6),
  }));

  // Mark profile complete
  setAndPersistUserProfile((up) => ({
    ...(up || {}),
    isComplete: true,
    finalProfile: resultProfile, // Store for reference
  }));

  console.debug("Assessment complete. Stored profile:", resultProfile);
}
```

**Verification:**

- Complete assessment → check React DevTools → appState.selections.assessmentResults populated
- Navigate to Step 6 → console shows stored profile
- Reload page → results still available (persisted in selections)

---

### Bug #6: Step6_Results - Missing Prop from Home

**Location:** Both `src/pages/Home.jsx` (line 265) and `src/components/Wizard/Step6_Results.jsx` (line 8)  
**Problem:** `Step6_Results` expects 5 props but Home.jsx only passes 4. Missing:

```jsx
// In Home.jsx line 265 - INCOMPLETE
<Step6_Results
  results={appState.selections.assessmentResults}
  userProfile={userProfile}
  allQuestions={allQuestions}
  courses={courses}
  generateRecommendations={(res) =>
    generateRecommendationsFromLogic(res, courses, appState.selections.topic)
  }
/>
// Step6_Results EXPECTS: results, userProfile, allQuestions, courses, generateRecommendations
// Home actually passes all 5... but Function signature shows undefined handling
```

Actually this is correct, but the handler function prop can be undefined. The real bug:

**Real Problem:** Component doesn't handle case where `courses` is empty properly, and doesn't validate before using.

**Fix:** Add defensive checks in Step6_Results

```javascript
export default function Step6_Results({
  results,
  userProfile,
  allQuestions = [],
  courses = [],
  generateRecommendations,
}) {
  // Validate inputs
  const validCourses =
    Array.isArray(courses) && courses.length > 0 ? courses : [];
  const validResults = results && typeof results === "object" ? results : null;
  const validProfile =
    userProfile && typeof userProfile === "object" ? userProfile : null;

  // EARLY EXIT: No data to display
  if (!validResults && !validProfile) {
    return (
      <div className="p-6 bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-700 rounded-lg">
        <h3 className="text-lg font-semibold text-amber-900 dark:text-amber-100 mb-2">
          No Assessment Results
        </h3>
        <p className="text-amber-800 dark:text-amber-200">
          Please complete the assessment to see recommendations.
        </p>
      </div>
    );
  }

  // Continue with existing logic...
}
```

---

### Bug #7: Explorer Filter Active State Not Clearing

**Location:** `src/components/Explorer/Explorer.jsx` line 43  
**Problem:** When new courses load (e.g., navigating between steps), `activeFilters` state doesn't reset. Filters from previous session persist.

**Fix Steps:**

1. When `initialCourses` prop changes, reset filters
2. Preserve search/sort but clear level/topic/duration
3. Reset pagination

**Corrected Code:**

```javascript
// Add effect to handle initialCourses changes
useEffect(() => {
  setCourses(initialCourses);

  // Option 1: Clear all filters on new courses
  setActiveFilters({
    level: "",
    topic: new Set(),
    duration: new Set(),
    rating: 0,
    enrollment: 0,
    search: "", // Or preserve if needed
    sort: "ai_score_desc",
  });
  setPage(1);
}, [initialCourses]);
```

---

## PART 2: ARCHITECTURAL IMPROVEMENTS (Build These On Top of Bug Fixes)

### Architecture Pattern #1: Unified Error Boundary

**File to Create:** `src/components/ErrorBoundary.jsx`

```javascript
import React from "react";
import { cn } from "../utils/api";

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error("Error caught by boundary:", error, errorInfo);
    this.setState({
      error,
      errorInfo,
    });
  }

  render() {
    if (this.state.hasError) {
      return (
        <div
          className={cn(
            "p-6 bg-red-50 dark:bg-red-950 border-2 border-red-200 dark:border-red-700 rounded-lg",
            "max-w-2xl mx-auto my-6"
          )}
        >
          <h2 className="text-xl font-bold text-red-900 dark:text-red-100 mb-2">
            Something went wrong
          </h2>
          <details className="text-sm text-red-800 dark:text-red-200 mt-4 p-3 bg-white dark:bg-gray-800 rounded border border-red-200 dark:border-red-700">
            <summary className="cursor-pointer font-semibold">
              Error details
            </summary>
            <pre className="mt-2 overflow-auto text-xs whitespace-pre-wrap">
              {this.state.error?.toString()}
              {this.state.errorInfo?.componentStack}
            </pre>
          </details>
          <button
            onClick={() => window.location.reload()}
            className="mt-4 px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
          >
            Reload Page
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
```

**Implementation in App.jsx:**

```javascript
import ErrorBoundary from "./components/ErrorBoundary";

export default function App() {
  return (
    <ErrorBoundary>
      <Home />
    </ErrorBoundary>
  );
}
```

---

### Architecture Pattern #2: Loading State Manager

**File to Create:** `src/hooks/useLoadingState.js`

```javascript
import { useState, useCallback } from "react";

export function useLoadingState(asyncFn, dependencies = []) {
  const [state, setState] = useState({
    loading: false,
    error: null,
    data: null,
    retry: 0,
  });

  const execute = useCallback(async () => {
    setState((s) => ({ ...s, loading: true, error: null }));
    try {
      const result = await asyncFn();
      setState((s) => ({ ...s, data: result, loading: false }));
      return result;
    } catch (err) {
      setState((s) => ({ ...s, error: err, loading: false }));
      throw err;
    }
  }, [asyncFn]);

  const retry = useCallback(() => {
    setState((s) => ({ ...s, retry: s.retry + 1 }));
    return execute();
  }, [execute]);

  return {
    ...state,
    execute,
    retry,
    isLoading: state.loading,
    hasError: !!state.error,
    errorMessage: state.error?.message || null,
  };
}
```

**Usage Example:**

```javascript
const {
  data: courses,
  isLoading,
  hasError,
  retry,
} = useLoadingState(fetchAllCourses, []);

if (isLoading) return <LoadingSpinner />;
if (hasError) return <ErrorMessage onRetry={retry} />;
return <CourseList courses={data} />;
```

---

### Architecture Pattern #3: Stable Question Pool Context

**File to Create:** `src/context/QuestionContext.jsx`

```javascript
import React, { createContext, useState, useEffect } from "react";
import { preprocessQuestionBank } from "../utils/assessmentLogic";

export const QuestionContext = createContext(null);

export function QuestionProvider({ children }) {
  const [state, setState] = useState({
    pool: null,
    allQuestions: [],
    allTags: [],
    loading: false,
    error: null,
  });

  useEffect(() => {
    if (state.pool) return; // Already loaded

    const loadQuestions = async () => {
      setState((s) => ({ ...s, loading: true, error: null }));
      try {
        const [mcqData, mcmsData, profilerData] = await Promise.all([
          fetch("/mcq_questions.json").then((r) => (r.ok ? r.json() : [])),
          fetch("/mcms_questions.json").then((r) => (r.ok ? r.json() : [])),
          fetch("/profiler_questions.json").then((r) => (r.ok ? r.json() : [])),
        ]);

        const combined = [
          ...(mcqData || []),
          ...(mcmsData || []),
          ...(profilerData || []),
        ];
        const pool = preprocessQuestionBank(combined);
        const tags = Array.from(
          new Set(
            combined.map((q) => q.tag).filter((t) => t && t !== "Profiler")
          )
        );

        setState((s) => ({
          ...s,
          pool,
          allQuestions: combined,
          allTags: tags,
          loading: false,
        }));
      } catch (err) {
        setState((s) => ({ ...s, error: err, loading: false }));
      }
    };

    loadQuestions();
  }, []);

  return (
    <QuestionContext.Provider value={state}>
      {children}
    </QuestionContext.Provider>
  );
}

export function useQuestions() {
  const ctx = React.useContext(QuestionContext);
  if (!ctx) throw new Error("useQuestions must be inside QuestionProvider");
  return ctx;
}
```

**Usage in Home.jsx:**

```javascript
import { useQuestions } from "../context/QuestionContext";

export default function Home() {
  const { pool: questionPool, allQuestions, allTags, loading } = useQuestions();
  // No need for manual loading logic anymore
}
```

---

### Architecture Pattern #4: Assessment State Persistence Manager

**File to Create:** `src/hooks/usePersistedAssessment.js`

```javascript
import { useState, useEffect, useCallback } from "react";

const STORAGE_KEY = "adaptive-user-profile";

export function usePersistedAssessment() {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  // Load from storage on mount
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        // Restore Set from Array
        parsed.questionsAsked = new Set(
          Array.isArray(parsed.questionsAsked) ? parsed.questionsAsked : []
        );
        setProfile(parsed);
      }
    } catch (e) {
      console.error("Failed to load assessment profile:", e);
    } finally {
      setLoading(false);
    }
  }, []);

  // Save to storage when profile changes
  useEffect(() => {
    if (profile === null) return;
    try {
      const copy = { ...profile };
      // Convert Set to Array for serialization
      copy.questionsAsked =
        profile.questionsAsked instanceof Set
          ? Array.from(profile.questionsAsked)
          : Array.isArray(profile?.questionsAsked)
          ? profile.questionsAsked
          : [];
      localStorage.setItem(STORAGE_KEY, JSON.stringify(copy));
    } catch (e) {
      console.error("Failed to save assessment profile:", e);
    }
  }, [profile]);

  const updateProfile = useCallback((updater) => {
    setProfile((prev) => {
      if (typeof updater === "function") {
        return updater(prev);
      }
      return updater;
    });
  }, []);

  const clearProfile = useCallback(() => {
    setProfile(null);
    localStorage.removeItem(STORAGE_KEY);
  }, []);

  return {
    profile,
    loading,
    updateProfile,
    clearProfile,
    isComplete: profile?.isComplete || false,
  };
}
```

---

### Architecture Pattern #5: Resilient Data Fetching Utilities

**File to Update:** `src/utils/api.js` - add these functions

```javascript
export async function fetchJSON(url, options = {}) {
  const { timeout = 10000, retries = 3, backoffMs = 1000 } = options;

  let lastError;

  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeout);

      const res = await fetch(url, {
        ...options,
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!res.ok) {
        throw new Error(`HTTP ${res.status}: ${res.statusText}`);
      }

      const data = await res.json();
      return data;
    } catch (err) {
      lastError = err;
      console.warn(
        `Fetch attempt ${attempt}/${retries} failed for ${url}:`,
        err.message
      );

      if (attempt < retries) {
        const delay = backoffMs * Math.pow(2, attempt - 1); // Exponential backoff
        await new Promise((resolve) => setTimeout(resolve, delay));
      }
    }
  }

  throw new Error(
    `Failed to fetch ${url} after ${retries} attempts: ${lastError?.message}`
  );
}

export async function fetchAllCoursesResilient() {
  const files = [
    "/final_beginner_courses.json",
    "/final_intermediate_courses.json",
    "/final_expert_courses.json",
  ];

  const results = [];
  const errors = [];

  for (const file of files) {
    try {
      const data = await fetchJSON(file, { retries: 2 });
      if (!Array.isArray(data)) {
        throw new Error("Response is not an array");
      }
      results.push(...data);
    } catch (err) {
      errors.push({ file, error: err.message });
      console.error(`Failed to fetch courses from ${file}:`, err);
    }
  }

  if (results.length === 0 && errors.length === files.length) {
    throw new Error("Failed to load any course data");
  }

  if (errors.length > 0) {
    console.warn(`Loaded courses with errors:`, errors);
  }

  return results
    .map((c) => {
      try {
        return normalizeCourse(c);
      } catch (e) {
        console.warn("Failed to normalize course:", c, e);
        return normalizeCourse({});
      }
    })
    .filter((c) => c.id);
}
```

---

## PART 3: UI/UX MODERNIZATION REQUIREMENTS

### Requirement #1: Accessibility (WCAG 2.1 AA Compliance)

Apply to ALL step components:

```javascript
// 1. Semantic HTML + ARIA labels
<fieldset> // Not just <div>
  <legend>Step X: Question</legend>
  <label htmlFor="field-id">Label</label>
  <input id="field-id" aria-describedby="field-help" />
  <p id="field-help" className="text-sm">Help text</p>
</fieldset>

// 2. Role attributes where needed
<div role="region" aria-label="Assessment questions" aria-live="polite" aria-atomic="false">
  {/* Question content */}
</div>

// 3. Keyboard navigation - Tab order must be logical
<button onKeyDown={(e) => {
  if(e.key === 'Enter' || e.key === ' ') handleClick()
}} />

// 4. Focus management
<div ref={focusRef} tabIndex={-1} aria-label="New content loaded">
  {content}
</div>

// 5. Color contrast - ensure text meets 4.5:1 ratio
// Use color utilities that maintain contrast in dark mode
className="text-gray-900 dark:text-white" // NOT gray-600 in dark mode
```

---

### Requirement #2: Loading & Error States

Pattern for all data-fetching components:

```javascript
const { data, isLoading, error, retry } = useLoadingState(fetchFn);

if (isLoading)
  return (
    <div className="space-y-4 animate-pulse">
      <div className="h-10 bg-gray-200 dark:bg-gray-700 rounded" />
      <div className="h-10 bg-gray-200 dark:bg-gray-700 rounded" />
    </div>
  );

if (error)
  return (
    <div className="p-4 bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-700 rounded">
      <p className="text-red-800 dark:text-red-100">Error: {error.message}</p>
      <button
        onClick={retry}
        className="mt-2 px-3 py-1 bg-red-600 text-white rounded text-sm"
      >
        Retry
      </button>
    </div>
  );

return <Component data={data} />;
```

---

### Requirement #3: Dark Mode Support

Ensure all components respect dark mode:

```javascript
// For backgrounds
className = "bg-white dark:bg-gray-800";

// For text
className = "text-gray-900 dark:text-white";

// For borders
className = "border-gray-200 dark:border-gray-700";

// For interactive states
className = "hover:bg-gray-100 dark:hover:bg-gray-700";

// For shadows (no shadows in dark by default)
className = "shadow-md dark:shadow-none";

// Test by:
// 1. Toggle dark mode in DevTools: document.documentElement.classList.toggle('dark')
// 2. Check all text is readable
// 3. Check no hidden elements
```

---

### Requirement #4: Responsive Design - Mobile First

Pattern for all layouts:

```javascript
// Mobile first approach
<div className="
  grid grid-cols-1 // 1 column on mobile
  sm:grid-cols-2   // 2 columns on tablet
  lg:grid-cols-3   // 3 columns on desktop
  gap-4            // Consistent spacing
">
  {/* Cards */}
</div>

// Test breakpoints:
// 640px (sm), 768px (md), 1024px (lg), 1280px (xl), 1536px (2xl)

// Ensure touch targets >= 44px on mobile
<button className="px-4 py-3 min-h-[44px] min-w-[44px]">Action</button>

// Test on real mobile or use DevTools device emulation
```

---

## PART 4: IMPLEMENTATION CHECKLIST

### Phase 1: Critical Bugs (Do These First)

- [ ] Bug #1: Fix Set serialization in localStorage
- [ ] Bug #2: Fix question pool race condition in useEffect
- [ ] Bug #3: Create normalizeCourse() utility function
- [ ] Bug #4: Add question type normalization function
- [ ] Bug #5: Enhance handleAdaptiveComplete() error handling
- [ ] Bug #6: Add input validation to Step6_Results
- [ ] Bug #7: Reset Explorer filters on initialCourses change

### Phase 2: Architectural Patterns

- [ ] Create `ErrorBoundary.jsx` component
- [ ] Create `useLoadingState.js` hook
- [ ] Create `QuestionContext.jsx` and provider
- [ ] Create `usePersistedAssessment.js` hook
- [ ] Update `api.js` with resilient fetching

### Phase 3: Component Accessibility

- [ ] Add semantic HTML to all 7 step components
- [ ] Add ARIA labels and roles
- [ ] Add keyboard navigation support
- [ ] Add focus management
- [ ] Test with screen reader

### Phase 4: Loading & Error States

- [ ] Add loading spinners to all data-fetching components
- [ ] Add error boundaries around critical sections
- [ ] Implement retry logic with exponential backoff
- [ ] Show user-friendly error messages

### Phase 5: Dark Mode & Responsiveness

- [ ] Audit all components for dark mode compliance
- [ ] Add mobile-first responsive classes
- [ ] Test on 5 breakpoints (mobile, tablet, desktop, wide, ultra-wide)
- [ ] Test touch interactions on mobile

---

## PART 5: TESTING VERIFICATION STEPS

### Data Flow Testing

```javascript
// 1. Question Loading
console.log("Step 5 - Questions loaded:", {
  pool: questionPool ? "YES" : "NO",
  count: allQuestions.length,
  tags: allTags.length,
  types: new Set(allQuestions.map((q) => q.type)),
});

// 2. Profile Serialization
localStorage.setItem(
  "test-set",
  JSON.stringify({ s: Array.from(new Set([1, 2, 3])) })
);
const restored = JSON.parse(localStorage.getItem("test-set"));
console.log("Set serialization works:", Array.isArray(restored.s));

// 3. Course Normalization
console.log("First course normalized:", {
  id: courses[0]?.id,
  title: courses[0]?.title,
  level: courses[0]?.level,
  rating: courses[0]?.Rating,
  analytics: typeof courses[0]?.analytics === "object",
});

// 4. Assessment Results
console.log("Assessment complete:", {
  results: appState.selections.assessmentResults ? "YES" : "NO",
  level: appState.selections.assessmentResults?.level,
  pct: appState.selections.assessmentResults?.overallPct,
  tags: appState.selections.assessmentResults?.interestTags?.length,
});
```

### UI/UX Testing Checklist

- [ ] Dark mode toggle works without page reload
- [ ] All text readable in dark and light modes
- [ ] Loading spinners appear while fetching data
- [ ] Error messages appear and retry button works
- [ ] Mobile layout doesn't break below 320px width
- [ ] Touch targets all >= 44px on mobile
- [ ] Keyboard Tab navigation follows logical order
- [ ] Screen reader announces section headers
- [ ] Form fields have associated labels

---

## PART 6: DEPLOYMENT & MONITORING

### Pre-Deployment Checklist

1. Run `npm run build` → no errors
2. Check `dist/` size → < 300KB gzipped total
3. Test production build locally: `npm run preview`
4. Verify all data files in `public/` → valid JSON
5. Check localStorage quota → app uses < 10MB
6. Test all 7 wizard steps end-to-end
7. Test dark mode persistence
8. Test on mobile device or emulator

### Performance Monitoring

```javascript
// Add to main.jsx
if (import.meta.env.PROD) {
  window.addEventListener("error", (e) => {
    console.error("Runtime error:", e.error);
    // Could send to monitoring service
  });

  // Track load time
  console.log("App loaded in", performance.now(), "ms");
}
```

### Production Debugging

- Enable console in production (for users to report errors)
- Log errors with user context (step, profile state)
- Monitor localStorage usage
- Track assessment completion rate

---

## PART 7: FUTURE ENHANCEMENTS (Post-MVP)

### High Priority

1. **Implement ThemeContext** - Move dark mode to Context API
2. **Add NotificationContext** - Toast notifications for errors
3. **Implement React Router** - Multi-page navigation
4. **Add PWA Support** - Offline mode, install prompt
5. **Implement Telemetry** - Track user flow, error rates

### Medium Priority

1. **Performance Optimization** - Code splitting, lazy loading
2. **Advanced Analytics** - User profiling, recommendation accuracy
3. **Multi-language Support** - i18n implementation
4. **Advanced Filtering** - More filter options in Explorer
5. **Course Bookmarking** - Save courses for later

### Low Priority

1. **Advanced Charting** - Better domain analysis visualization
2. **PDF Export** - Export recommendations as PDF
3. **Sharing** - Share learning path with others
4. **Social Features** - User reviews, ratings

---

## SUMMARY: EXPLICIT INSTRUCTIONS FOR AI AGENT

**To apply all fixes**, an AI code editing agent should:

1. **Read this entire document** to understand context
2. **Apply Phase 1 bugs first** in order (all bugs are blocking)
3. **Test each bug fix** before moving to next
4. **Create Phase 2 files** exactly as specified
5. **Update Phase 3 components** with accessibility attributes
6. **Add Phase 4 error handling** to all components
7. **Apply Phase 5 styling** to ensure dark mode and responsive
8. **Run verification tests** from Part 5
9. **Build and test** before deployment

**Do NOT:**

- Skip any bug in Phase 1 (they're all breaking)
- Create new component files (only update existing)
- Change data structure beyond normalization
- Remove console.debug statements (keep for debugging)

**Success Criteria:**

- All 7 wizard steps render without errors
- Assessment questions load correctly (>0 questions)
- Results persist and show recommendations
- No localStorage errors on page reload
- Dark mode works throughout
- Mobile layout is readable at 320px width
- All interactive elements have ARIA labels

---

**This guide is complete, implementation-ready, and requires no further decisions from the agent. Follow it step-by-step and the app will be production-ready.**
