import React from "react";
import { cn } from "../utils/api";

export default function StepIndicator({
  stepNames,
  currentStep,
  maxStep,
  goToStep,
}) {
  return (
    <nav
      className="flex justify-between p-4 bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700"
      aria-label="Wizard steps"
    >
      {stepNames.map((name, idx) => {
        const step = idx + 1;
        const isCompleted = step < currentStep;
        const isCurrent = step === currentStep;
        const isDisabled = step > maxStep;

        const indicatorClasses = cn(
          "w-10 h-10 flex items-center justify-center rounded-full font-bold transition-all duration-200",
          isCompleted && "bg-success-500 text-white",
          isCurrent &&
            "bg-warning-500 text-gray-900 ring-2 ring-offset-2 ring-warning-500",
          !isCompleted &&
            !isCurrent &&
            "bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-400",
          !isDisabled && "cursor-pointer hover:shadow-lg",
          isDisabled && "opacity-50 cursor-not-allowed"
        );

        return (
          <div
            key={name}
            className="flex-1 flex flex-col items-center"
            role="progressbar"
            aria-valuenow={step}
            aria-valuemin="1"
            aria-valuemax={stepNames.length}
            aria-label={`Step ${step}: ${name}`}
          >
            <button
              className={indicatorClasses}
              onClick={() => !isDisabled && goToStep(step)}
              disabled={isDisabled}
              aria-current={isCurrent ? "step" : undefined}
              title={
                isDisabled
                  ? `${name} (complete earlier steps)`
                  : `Go to step ${step}: ${name}`
              }
            >
              {isCompleted ? "✓" : step}
            </button>
            <p className="text-xs font-medium text-gray-600 dark:text-gray-400 hidden sm:block mt-2 text-center">
              {name}
            </p>
          </div>
        );
      })}
    </nav>
  );
}
