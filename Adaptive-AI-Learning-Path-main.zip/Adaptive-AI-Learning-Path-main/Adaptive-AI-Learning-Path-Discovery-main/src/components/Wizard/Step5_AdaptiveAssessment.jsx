import React, { useEffect, useState } from "react";
import {
  selectNextQuestion,
  updateProfile,
  scoreWrittenAnswer,
  generateFinalProfile,
} from "../../utils/assessmentLogic";

export default function Step5_AdaptiveAssessment({
  userProfile,
  setUserProfile,
  questionPool,
  allTags = [],
  allQuestions = [],
  onComplete,
}) {
  const [currentQuestion, setCurrentQuestion] = useState(null);
  const [currentAnswer, setCurrentAnswer] = useState(null);
  const [loading, setLoading] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [warning, setWarning] = useState("");
  const totalQuestions = 7;

  // track how many of each question TYPE we've asked (local state)
  const [answeredCounts, setAnsweredCounts] = useState({});
  const [questionHistory, setQuestionHistory] = useState([]); // stack of previous question objects
  const [answersMap, setAnswersMap] = useState({}); // qid -> answer

  // initialize answeredCounts from userProfile.questionsAsked if present
  useEffect(() => {
    if (!allQuestions || !userProfile) return;
    const asked =
      userProfile.questionsAsked instanceof Set
        ? Array.from(userProfile.questionsAsked)
        : Array.isArray(userProfile.questionsAsked)
        ? userProfile.questionsAsked
        : [];
    const counts = {};
    asked.forEach((qid) => {
      const q = allQuestions.find((x) => x.id === qid || x.id === String(qid));
      if (q) {
        counts[q.type] = (counts[q.type] || 0) + 1;
      }
    });
    setAnsweredCounts(counts);
  }, [userProfile, allQuestions]);

  // helper: quotas for types (2+2+2+1 -> total 7)
  const TYPE_QUOTAS = { MCQ: 2, MCMS: 2, "MCQ-Reorder": 2, ShortAnswer: 1 };

  // helper to check if a type still needs more questions
  function typeNeedsMore(type) {
    const have = answeredCounts[type] || 0;
    const want = TYPE_QUOTAS[type] || 0;
    return have < want;
  }

  // helper to find candidate by preferred types without mutating questionPool
  function findCandidateByTypes(preferredTypes = [], profile = userProfile) {
    // iterate tags and difficulty similar to selectNextQuestion but do not pop
    const tried = new Set();
    const askedArr = Array.isArray(profile?.questionsAsked)
      ? profile.questionsAsked
      : profile?.questionsAsked instanceof Set
      ? Array.from(profile.questionsAsked)
      : [];
    for (const t of allTags) {
      if (!t) continue;
      const buckets = questionPool[t] || {};
      const targetDifficulty = Math.max(
        1,
        Math.min(10, Number(profile?.tagLevels?.[t] || 5))
      );
      // search outward from targetDifficulty
      const diffs = [0];
      for (let o = 1; o <= 9; o++) {
        diffs.push(o);
        diffs.push(-o);
      }
      for (const dOff of diffs) {
        const d = targetDifficulty + dOff;
        if (d < 1 || d > 10) continue;
        const bucket = Array.isArray(buckets[d]) ? buckets[d] : [];
        for (const q of bucket) {
          if (!q) continue;
          if (tried.has(q.id)) continue;
          tried.add(q.id);
          if (askedArr.includes(q.id)) continue;
          if (
            preferredTypes.includes(q.type) ||
            (preferredTypes.includes("ShortAnswer") &&
              (q.type === "ShortAnswer" || q.type === "LongAnswer"))
          ) {
            return q;
          }
        }
      }
    }
    return null;
  }

  // helper to pick the next question honoring quotas; returns question or null
  function pickNextForQuotas(profile = userProfile) {
    // build list of types that still need more
    const remainingTypes = Object.keys(TYPE_QUOTAS).filter((t) =>
      typeNeedsMore(t)
    );
    if (remainingTypes.length === 0) return null;
    // prefer fixed order: MCQ -> MCMS -> MCQ-Reorder -> ShortAnswer
    const order = ["MCQ", "MCMS", "MCQ-Reorder", "ShortAnswer"];
    const preferred = order.filter((o) => remainingTypes.includes(o));
    // try each preferred type in order
    for (const pt of preferred) {
      const candidate = findCandidateByTypes([pt], profile);
      if (candidate) return candidate;
      // also try similar MCQ variants for 'MCQ' group if none found
      if (pt === "MCQ") {
        const alt = findCandidateByTypes(
          ["MCQ-Matching", "MCQ-Scenario", "MCQ"],
          profile
        );
        if (alt) return alt;
      }
    }
    return null;
  }

  // helper to initialize first question
  useEffect(() => {
    if (!userProfile || !questionPool || completed) return;
    if (userProfile.isComplete) return;

    if (!currentQuestion) {
      // try quota-aware pick first
      const first = pickNextForQuotas(userProfile);
      if (first) {
        console.debug(
          "[Step5] Loaded first question with quota logic:",
          first.id,
          first.text
        );
        setCurrentQuestion(first);
        setCurrentAnswer(answersMap[first.id] || null);
        return;
      }

      const { question, updatedTagsToTest } = selectNextQuestion(
        userProfile,
        questionPool,
        allTags
      );
      if (!question) {
        const finalProfile = generateFinalProfile(userProfile, allQuestions);
        console.debug(
          "Step5 init: no question available, derived finalProfile=",
          finalProfile,
          "userProfile=",
          userProfile
        );
        setUserProfile((up) => ({ ...(up || {}), isComplete: true }));
        setCompleted(true);
        if (typeof onComplete === "function") onComplete(finalProfile);
        return;
      }
      console.debug(
        "[Step5] Loaded first question via adaptive logic:",
        question.id,
        question.text
      );
      setCurrentQuestion(question);
      setUserProfile((up) => ({
        ...(up || {}),
        tagsToTest: updatedTagsToTest,
      }));
      setCurrentAnswer(answersMap[question.id] || null);
    }
  }, [
    userProfile,
    questionPool,
    currentQuestion,
    allTags,
    setUserProfile,
    allQuestions,
    onComplete,
    completed,
  ]);

  if (!userProfile || !questionPool)
    return (
      <div className="p-6">
        <h2 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">
          Step 5: Adaptive Knowledge Assessment
        </h2>
        <div className="p-4 border rounded bg-blue-50 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300 border-blue-200 dark:border-blue-800">
          <p className="animate-pulse">Loading assessment questions...</p>
          <p className="text-sm mt-2">
            This may take a moment as we prepare personalized questions for you.
          </p>
        </div>
      </div>
    );

  function renderOptions(q) {
    if (!q)
      return (
        <div className="text-gray-500 dark:text-gray-400">
          Question data not available
        </div>
      );

    const questionType = q.type || "unknown";

    // MCQ variants: render as radio buttons
    if (
      ["MCQ", "MCQ-Matching", "MCQ-Reorder", "MCQ-Scenario"].includes(
        questionType
      )
    ) {
      const options = Array.isArray(q.options) ? q.options : [];
      if (options.length === 0)
        return (
          <div className="text-gray-500 dark:text-gray-400">
            No options available
          </div>
        );
      return (
        <div className="space-y-2">
          {options.map((opt, idx) => (
            <label
              key={idx}
              className="flex items-center p-3 border-2 border-gray-200 dark:border-gray-600 rounded hover:bg-gray-100 dark:hover:bg-gray-600 cursor-pointer transition-colors"
            >
              <input
                type="radio"
                name={q.id}
                checked={currentAnswer === opt}
                onChange={() => setCurrentAnswer(opt)}
                className="mr-2 accent-blue-600 dark:accent-blue-400"
              />
              <span className="text-gray-900 dark:text-gray-100">{opt}</span>
            </label>
          ))}
        </div>
      );
    }

    // MCMS: render as checkboxes
    if (questionType === "MCMS") {
      const options = Array.isArray(q.options) ? q.options : [];
      if (options.length === 0)
        return (
          <div className="text-gray-500 dark:text-gray-400">
            No options available
          </div>
        );
      const sel = Array.isArray(currentAnswer) ? currentAnswer : [];
      function toggleOpt(o) {
        const s = new Set(sel);
        if (s.has(o)) s.delete(o);
        else s.add(o);
        setCurrentAnswer(Array.from(s));
      }
      return (
        <div className="space-y-2">
          {options.map((opt, idx) => (
            <label
              key={idx}
              className="flex items-center p-3 border-2 border-gray-200 dark:border-gray-600 rounded hover:bg-gray-100 dark:hover:bg-gray-600 cursor-pointer transition-colors"
            >
              <input
                type="checkbox"
                name={q.id}
                checked={sel.includes(opt)}
                onChange={() => toggleOpt(opt)}
                className="mr-2 accent-purple-600 dark:accent-purple-400"
              />
              <span className="text-gray-900 dark:text-gray-100">{opt}</span>
            </label>
          ))}
        </div>
      );
    }

    // Short/Long Answer: render textarea
    if (questionType === "ShortAnswer" || questionType === "LongAnswer") {
      return (
        <div>
          <textarea
            value={currentAnswer || ""}
            onChange={(e) => setCurrentAnswer(e.target.value)}
            rows={4}
            placeholder="Enter your answer here..."
            className="w-full p-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          {q.helpText && (
            <p className="text-sm text-gray-500 mt-2">{q.helpText}</p>
          )}
        </div>
      );
    }

    // Profiler questions
    if (q.tag === "Profiler") {
      const options = Array.isArray(q.options) ? q.options : [];
      if (options.length > 1) {
        return (
          <div className="space-y-2">
            {options.map((opt, idx) => (
              <label
                key={idx}
                className="flex items-center p-2 border rounded hover:bg-gray-100 cursor-pointer"
              >
                <input
                  type="radio"
                  name={q.id}
                  checked={currentAnswer === opt}
                  onChange={() => setCurrentAnswer(opt)}
                  className="mr-2"
                />
                <span>{opt}</span>
              </label>
            ))}
          </div>
        );
      }
      return (
        <div className="text-gray-500">Profiler question data incomplete</div>
      );
    }

    return (
      <div className="text-gray-500">
        Question type "{questionType}" not supported
      </div>
    );
  }

  // guard: require answer before proceeding
  function hasAnswerForCurrent() {
    if (!currentQuestion) return false;
    const t = currentQuestion.type;
    if (["MCQ", "MCQ-Matching", "MCQ-Reorder", "MCQ-Scenario"].includes(t))
      return !!currentAnswer;
    if (t === "MCMS")
      return Array.isArray(currentAnswer) && currentAnswer.length > 0;
    if (t === "ShortAnswer" || t === "LongAnswer") {
      const wc = (currentAnswer || "").split(/\s+/).filter(Boolean).length;
      return wc >= (currentQuestion.minLength || 0);
    }
    // profiler or unknown: accept any non-empty
    return !!currentAnswer;
  }

  async function handleNext() {
    if (completed || loading) return;
    if (!currentQuestion) return;
    if (!hasAnswerForCurrent()) {
      setWarning("Please answer the question before proceeding.");
      setTimeout(() => setWarning(""), 2500);
      return;
    }

    setLoading(true);
    setWarning("");
    const q = currentQuestion;
    let isCorrect = false;
    let writtenScores = null;

    if (
      ["MCQ", "MCQ-Matching", "MCQ-Reorder", "MCQ-Scenario"].includes(q.type)
    ) {
      isCorrect = currentAnswer === q.correctAnswer;
    } else if (q.type === "MCMS") {
      const expected = Array.isArray(q.correctAnswers)
        ? q.correctAnswers.slice().sort()
        : [];
      const got = Array.isArray(currentAnswer)
        ? currentAnswer.slice().sort()
        : [];
      isCorrect = JSON.stringify(expected) === JSON.stringify(got);
    } else if (q.type === "ShortAnswer" || q.type === "LongAnswer") {
      writtenScores = scoreWrittenAnswer(
        currentAnswer || "",
        q.scoringTags || {},
        q.minLength || 0
      );
      isCorrect = Object.values(writtenScores.tagScores || {}).some(
        (s) => s >= 0.7
      );
    } else if (q.tag === "Profiler") {
      isCorrect = true;
    }

    // build updated profile
    const updated = updateProfile(
      userProfile,
      q,
      currentAnswer,
      isCorrect,
      writtenScores
    );

    // persist current answer in local map
    setAnswersMap((prev) => ({ ...(prev || {}), [q.id]: currentAnswer }));

    // update local answeredCounts for quotas
    setAnsweredCounts((prev) => {
      const next = { ...(prev || {}) };
      next[q.type] = (next[q.type] || 0) + 1;
      return next;
    });

    // determine next question respecting quotas
    let nextQ = pickNextForQuotas(updated);
    if (!nextQ) {
      // fallback to adaptive selector
      const { question: selQ, updatedTagsToTest } = selectNextQuestion(
        updated,
        questionPool,
        allTags
      );
      nextQ = selQ;
      updated.tagsToTest = updatedTagsToTest;
    }

    // before navigating forward, push current question onto history so Previous can work
    setQuestionHistory((h) => {
      const next = Array.isArray(h) ? [...h] : [];
      next.push(q);
      return next;
    });

    // finalize check
    const answered = updated.currentQuestionIndex || 0;
    const profilerQs = allQuestions
      .filter((x) => x.tag === "Profiler")
      .map((p) => p.id);
    const beginnerPivotDone =
      updated.isBeginnerPivot &&
      profilerQs.length > 0 &&
      profilerQs.every((pq) => updated.questionsAsked.has(pq));

    if (answered >= totalQuestions || beginnerPivotDone || !nextQ) {
      const finalProfile = generateFinalProfile(updated, allQuestions);
      updated.tagsToTest = updated.tagsToTest || [];
      console.debug(
        "Step5 complete: finalProfile=",
        finalProfile,
        "updatedProfile=",
        updated
      );
      setUserProfile(updated);
      setCompleted(true);
      setLoading(false);
      setUserProfile((up) => ({ ...(up || {}), isComplete: true }));
      if (typeof onComplete === "function") onComplete(finalProfile);
      return;
    }

    // otherwise continue
    setUserProfile(updated);
    setCurrentQuestion(nextQ);
    setCurrentAnswer(answersMap[nextQ?.id] || null);
    setLoading(false);
  }

  function handlePrev() {
    if (loading) return;
    if (!questionHistory || questionHistory.length === 0) return;
    const h = [...questionHistory];
    const prevQ = h.pop();
    setQuestionHistory(h);
    setCurrentQuestion(prevQ);
    setCurrentAnswer(answersMap[prevQ.id] || null);
  }

  // compute current correct count from tagScores in userProfile
  function getCorrectCount() {
    try {
      const ts =
        userProfile && userProfile.tagScores ? userProfile.tagScores : {};
      return Object.values(ts).reduce((s, t) => s + (t.correct || 0), 0);
    } catch (e) {
      return 0;
    }
  }

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-2 text-gray-900 dark:text-white">
        Step 5: Adaptive Knowledge Assessment
      </h2>
      <p className="text-gray-600 dark:text-gray-400 mb-4">
        This assessment adapts to your performance. Answer {totalQuestions}{" "}
        questions or finish profiler flow if identified as a beginner.
      </p>

      {completed ? (
        <div className="p-4 border rounded bg-green-50 dark:bg-green-900/30 text-green-800 dark:text-green-300 border-green-200 dark:border-green-800 mb-4">
          <p className="font-semibold">Assessment complete!</p>
          <p className="text-sm">
            Saving your results and moving to the Results screen...
          </p>
        </div>
      ) : null}

      <div className="p-6 border rounded mb-4 bg-white dark:bg-gray-800 dark:border-gray-700 shadow">
        <div className="mb-4 flex justify-between items-center">
          <div className="text-sm text-gray-600 dark:text-gray-400">
            Question{" "}
            <span className="font-semibold">
              {Math.min(
                (userProfile.currentQuestionIndex || 0) + 1,
                totalQuestions
              )}
            </span>{" "}
            / <span className="font-semibold">{totalQuestions}</span>
          </div>
          <div className="text-sm text-green-600 dark:text-green-400 font-semibold">
            ✓ Correct: {getCorrectCount()}
          </div>
        </div>

        <div className="mb-6 h-1 bg-gray-200 dark:bg-gray-700 rounded">
          <div
            className="h-full bg-blue-500 rounded transition-all"
            style={{
              width: `${Math.min(
                ((userProfile.currentQuestionIndex || 0) / totalQuestions) *
                  100,
                100
              )}%`,
            }}
          ></div>
        </div>

        {currentQuestion ? (
          <div>
            <div className="mb-4">
              <p className="text-lg font-semibold text-gray-900 dark:text-white">
                {currentQuestion.text || "Question text not available"}
              </p>
            </div>

            <div className="mb-6 p-4 bg-gray-50 dark:bg-gray-700 rounded">
              {renderOptions(currentQuestion)}
            </div>

            {warning && (
              <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/30 text-red-700 dark:text-red-300 text-sm border border-red-200 dark:border-red-800 rounded">
                ⚠️ {warning}
              </div>
            )}

            <div className="flex justify-between items-center gap-4">
              <button
                onClick={handlePrev}
                disabled={loading || !questionHistory.length}
                className="px-6 py-2 bg-gray-300 dark:bg-gray-600 text-gray-800 dark:text-white rounded font-medium hover:bg-gray-400 dark:hover:bg-gray-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                ← Previous
              </button>
              <button
                onClick={handleNext}
                disabled={loading}
                className="px-6 py-2 bg-blue-600 dark:bg-blue-500 text-white rounded font-medium hover:bg-blue-700 dark:hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {loading
                  ? "Processing..."
                  : (userProfile.currentQuestionIndex || 0) + 1 >=
                    totalQuestions
                  ? "Submit Assessment"
                  : "Next →"}
              </button>
            </div>
          </div>
        ) : (
          <div className="p-6 text-center">
            <p className="text-gray-600 dark:text-gray-400 mb-2">
              ⚠️ No question available
            </p>
            <p className="text-sm text-gray-500 dark:text-gray-500">
              The question bank may be exhausted for your selected topics.
            </p>
            <button
              onClick={handleNext}
              className="mt-4 px-4 py-2 bg-blue-600 dark:bg-blue-500 text-white rounded text-sm hover:bg-blue-700 dark:hover:bg-blue-600 transition-colors"
            >
              Proceed to Results
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
