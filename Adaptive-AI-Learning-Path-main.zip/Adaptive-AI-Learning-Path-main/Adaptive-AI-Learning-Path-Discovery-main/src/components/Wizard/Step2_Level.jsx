import React from "react";
import { cn } from "../../utils/api";

const OPTIONS = [
  {
    id: "beginner",
    label: "Beginner",
    icon: "🌱",
    description: "New to this field, basic knowledge",
  },
  {
    id: "intermediate",
    label: "Intermediate",
    icon: "📈",
    description: "Some experience, ready to go deeper",
  },
  {
    id: "advanced",
    label: "Advanced",
    icon: "🚀",
    description: "Solid expertise, seeking mastery",
  },
];

export default function Step2_Level({
  value,
  onChange,
  selections,
  setSelectionProp,
}) {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-3">
          Step 2: Your Experience Level
        </h2>
        <p className="text-lg text-gray-600 dark:text-gray-400">
          How experienced are you in this field?
        </p>
      </div>

      {/* Level Selection Cards */}
      <fieldset className="space-y-4">
        <legend className="sr-only">Experience Level Options</legend>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {OPTIONS.map((opt) => (
            <label
              key={opt.id}
              className={cn(
                "relative p-6 border-2 rounded-xl cursor-pointer transition-all duration-200 hover:shadow-md",
                value === opt.id
                  ? "border-primary-600 bg-primary-50 dark:bg-primary-950 shadow-md"
                  : "border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:border-primary-300"
              )}
              role="option"
              aria-selected={value === opt.id}
            >
              <input
                type="radio"
                name="level"
                value={opt.id}
                checked={value === opt.id}
                onChange={() => onChange(opt.id)}
                className="sr-only"
                aria-label={`${opt.label}: ${opt.description}`}
              />
              <div className="flex flex-col items-center text-center gap-3">
                <span className="text-5xl">{opt.icon}</span>
                <div>
                  <div className="font-semibold text-gray-900 dark:text-white text-lg">
                    {opt.label}
                  </div>
                  <div className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                    {opt.description}
                  </div>
                </div>
                {value === opt.id && (
                  <div className="w-5 h-5 bg-primary-600 rounded-full flex items-center justify-center text-white text-xs font-bold mt-2">
                    ✓
                  </div>
                )}
              </div>
            </label>
          ))}
        </div>
      </fieldset>

      {/* Info Box */}
      <div className="bg-purple-50 dark:bg-purple-950 border border-purple-200 dark:border-purple-800 rounded-lg p-4 text-sm text-purple-900 dark:text-purple-100">
        <strong>ℹ️ Note:</strong> This helps us recommend courses at the right
        difficulty level and pacing for your skill growth.
      </div>
    </div>
  );
}
