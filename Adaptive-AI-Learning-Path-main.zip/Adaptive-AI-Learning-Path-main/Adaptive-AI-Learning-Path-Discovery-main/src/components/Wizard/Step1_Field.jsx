import React from "react";
import { cn } from "../../utils/api";
import SelectionCard from "./SelectionCard";

const OPTIONS = [
  {
    id: "ai-ml",
    label: "AI/ML",
    icon: "🤖",
    description: "Core AI and Machine Learning",
  },
  {
    id: "data-science",
    label: "Data Science",
    icon: "📊",
    description: "Data analysis and visualization",
  },
  {
    id: "mlops",
    label: "MLOps",
    icon: "⚙️",
    description: "ML deployment and operations",
  },
  {
    id: "gen-ai",
    label: "Generative AI",
    icon: "✨",
    description: "LLMs and creative AI",
  },
];

const OUTCOMES = [
  { value: "product", label: "Build a product (RAG/LLM app)" },
  { value: "job", label: "Job-ready skill" },
  { value: "manager", label: "Manager upskilling" },
];

export default function Step1_Field({
  value,
  onChange,
  selections,
  setSelectionProp,
}) {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-3">
          Step 1: Choose Your Field
        </h2>
        <p className="text-lg text-gray-600 dark:text-gray-400">
          What's your primary interest in AI/ML?
        </p>
      </div>

      {/* Field Selection Cards */}
      <fieldset className="space-y-4">
        <legend className="sr-only">AI/ML Field Options</legend>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {OPTIONS.map((opt) => (
            <label
              key={opt.id}
              className={cn(
                "relative p-5 border-2 rounded-xl cursor-pointer transition-all duration-200 hover:shadow-md",
                value === opt.id
                  ? "border-primary-600 bg-primary-50 dark:bg-primary-950 shadow-md"
                  : "border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:border-primary-300"
              )}
              role="option"
              aria-selected={value === opt.id}
            >
              <input
                type="radio"
                name="field"
                value={opt.id}
                checked={value === opt.id}
                onChange={() => onChange(opt.id)}
                className="sr-only"
                aria-label={`${opt.label}: ${opt.description}`}
              />
              <div className="flex items-start gap-4">
                <span className="text-4xl">{opt.icon}</span>
                <div className="flex-1">
                  <div className="font-semibold text-gray-900 dark:text-white text-lg">
                    {opt.label}
                  </div>
                  <div className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                    {opt.description}
                  </div>
                </div>
                {value === opt.id && (
                  <div className="w-5 h-5 bg-primary-600 rounded-full flex items-center justify-center text-white text-xs font-bold">
                    ✓
                  </div>
                )}
              </div>
            </label>
          ))}
        </div>
      </fieldset>

      {/* Desired Outcome */}
      <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6 shadow-sm">
        <label
          htmlFor="outcome-select"
          className="block text-lg font-semibold text-gray-900 dark:text-white mb-3"
        >
          What's your desired outcome?{" "}
          <span className="text-gray-500 text-sm font-normal">(Optional)</span>
        </label>
        <select
          id="outcome-select"
          value={selections.outcome || ""}
          onChange={(e) => setSelectionProp("outcome", e.target.value)}
          className={cn(
            "w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg",
            "bg-white dark:bg-gray-700 text-gray-900 dark:text-white",
            "focus:border-primary-600 focus:ring-2 focus:ring-primary-600 focus:ring-opacity-50",
            "transition-colors duration-200 font-medium"
          )}
          aria-describedby="outcome-help"
        >
          <option value="">Select an outcome...</option>
          {OUTCOMES.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
        <p
          id="outcome-help"
          className="text-sm text-gray-500 dark:text-gray-400 mt-2"
        >
          This helps us personalize your learning path recommendations
        </p>
      </div>

      {/* Helper Text */}
      <div className="bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg p-4 text-sm text-blue-900 dark:text-blue-100">
        <strong>💡 Tip:</strong> Your selection will help personalize course
        recommendations based on your goals and learning style.
      </div>
    </div>
  );
}
