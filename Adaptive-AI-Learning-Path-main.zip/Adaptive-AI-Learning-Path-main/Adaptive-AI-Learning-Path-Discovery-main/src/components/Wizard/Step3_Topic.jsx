import React from "react";
import { cn } from "../../utils/api";

const OPTIONS = [
  { id: "llm-finetune", label: "LLM Fine-Tuning", icon: "🔧" },
  { id: "rag", label: "RAG", icon: "📚" },
  { id: "cv", label: "Computer Vision", icon: "👁️" },
  { id: "timeseries", label: "Time-Series Analysis", icon: "📈" },
  { id: "ethics", label: "Ethical AI", icon: "⚖️" },
  { id: "deeplearning", label: "Deep Learning", icon: "🧠" },
  { id: "viz", label: "Data Visualization", icon: "📊" },
  { id: "deployment", label: "Cloud Deployment", icon: "☁️" },
];

const QUICK_ADD = ["RAG", "LLM Fine-Tuning", "Computer Vision"];

export default function Step3_Topic({
  value = [],
  onChange,
  selections,
  setSelectionProp,
}) {
  function toggle(opt) {
    const next = value.includes(opt)
      ? value.filter((v) => v !== opt)
      : [...value, opt];
    onChange(next);
  }

  function quickAdd(opt) {
    if (!value.includes(opt)) {
      onChange([...value, opt]);
    }
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-3">
          Step 3: Specific Topics
        </h2>
        <p className="text-lg text-gray-600 dark:text-gray-400">
          Select one or more topics you want to focus on
        </p>
      </div>

      {/* Quick Add Buttons */}
      <div>
        <p className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
          Popular Topics
        </p>
        <div className="flex flex-wrap gap-2">
          {QUICK_ADD.map((topic) => (
            <button
              key={topic}
              onClick={() => quickAdd(topic)}
              className={cn(
                "px-4 py-2 rounded-full font-medium transition-all duration-200 text-sm",
                value.includes(topic)
                  ? "bg-primary-600 text-white shadow-md"
                  : "bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-white hover:bg-gray-300 dark:hover:bg-gray-600"
              )}
              aria-pressed={value.includes(topic)}
            >
              + {topic}
            </button>
          ))}
        </div>
      </div>

      {/* Topic Selection Grid */}
      <fieldset className="space-y-4">
        <legend className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
          All Topics
        </legend>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {OPTIONS.map((opt) => (
            <label
              key={opt.id}
              className={cn(
                "relative p-4 border-2 rounded-lg cursor-pointer transition-all duration-200 hover:shadow-md",
                value.includes(opt.label)
                  ? "border-primary-600 bg-primary-50 dark:bg-primary-950 shadow-md"
                  : "border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800"
              )}
              role="option"
              aria-selected={value.includes(opt.label)}
            >
              <input
                type="checkbox"
                checked={value.includes(opt.label)}
                onChange={() => toggle(opt.label)}
                className="sr-only"
                aria-label={opt.label}
              />
              <div className="flex items-start gap-3">
                <span className="text-2xl flex-shrink-0">{opt.icon}</span>
                <div className="flex-1">
                  <span className="font-medium text-gray-900 dark:text-white block">
                    {opt.label}
                  </span>
                </div>
                {value.includes(opt.label) && (
                  <div className="w-5 h-5 bg-primary-600 rounded flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                    ✓
                  </div>
                )}
              </div>
            </label>
          ))}
        </div>
      </fieldset>

      {/* Selection Count */}
      <div className="bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800 rounded-lg p-4">
        <p className="text-sm text-green-900 dark:text-green-100">
          <strong>
            {value.length} topic{value.length !== 1 ? "s" : ""} selected
          </strong>
          {value.length > 0 && (
            <span className="ml-2 text-xs">({value.join(", ")})</span>
          )}
        </p>
      </div>
    </div>
  );
}
