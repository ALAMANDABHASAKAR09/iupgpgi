import React from "react";
import { cn } from "../../../utils/api";

export default function Question({ q, value, onChange }) {
  const opts = q.options || [];
  const domains = q.domains || (q.tag ? [q.tag] : []);

  // Helper for MCMS checkbox toggling
  function handleToggleCheckbox(option) {
    const current = Array.isArray(value) ? [...value] : [];
    const idx = current.indexOf(option);
    if (idx === -1) current.push(option);
    else current.splice(idx, 1);
    onChange(q.id, current);
  }

  const mcqLike = ["MCQ", "MCQ-Matching", "MCQ-Reorder", "MCQ-Scenario"];

  if (mcqLike.includes(q.type)) {
    return (
      <fieldset className="p-6 border-2 border-gray-200 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-800 mb-6">
        <legend className="sr-only">Question</legend>
        <div className="mb-4">
          <p className="font-bold text-lg text-gray-900 dark:text-white mb-2">
            {q.text}
          </p>
          <p className="text-xs text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 px-3 py-1 rounded-full inline-block">
            {domains.join(", ")}
          </p>
        </div>
        <div className="space-y-3">
          {opts.map((opt, idx) => (
            <label
              key={opt}
              className={cn(
                "flex items-center p-4 border-2 rounded-lg cursor-pointer transition-all duration-200",
                value === opt
                  ? "border-blue-600 dark:border-blue-400 bg-blue-50 dark:bg-blue-900/30"
                  : "border-gray-200 dark:border-gray-600 hover:border-blue-500 dark:hover:border-blue-400"
              )}
            >
              <input
                type="radio"
                name={q.id}
                checked={value === opt}
                onChange={() => onChange(q.id, opt)}
                className="w-4 h-4 mr-3 cursor-pointer accent-blue-600 dark:accent-blue-400"
                aria-label={opt}
              />
              <span className="text-gray-900 dark:text-gray-100 font-medium">
                {opt}
              </span>
            </label>
          ))}
        </div>
      </fieldset>
    );
  }

  if (q.type === "MCMS") {
    const sel = Array.isArray(value) ? value : [];
    return (
      <fieldset className="p-6 border-2 border-gray-200 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-800 mb-6">
        <legend className="sr-only">Question</legend>
        <div className="mb-4">
          <p className="font-bold text-lg text-gray-900 dark:text-white mb-2">
            {q.text}
          </p>
          <p className="text-xs text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 px-3 py-1 rounded-full inline-block">
            {domains.join(", ")} • Select multiple
          </p>
        </div>
        <div className="space-y-3">
          {opts.map((opt) => (
            <label
              key={opt}
              className={cn(
                "flex items-center p-4 border-2 rounded-lg cursor-pointer transition-all duration-200",
                sel.includes(opt)
                  ? "border-purple-600 dark:border-purple-400 bg-purple-50 dark:bg-purple-900/30"
                  : "border-gray-200 dark:border-gray-600 hover:border-purple-500 dark:hover:border-purple-400"
              )}
            >
              <input
                type="checkbox"
                name={q.id}
                checked={sel.includes(opt)}
                onChange={() => handleToggleCheckbox(opt)}
                className="w-4 h-4 mr-3 cursor-pointer accent-purple-600 dark:accent-purple-400"
                aria-label={opt}
              />
              <span className="text-gray-900 dark:text-gray-100 font-medium">
                {opt}
              </span>
            </label>
          ))}
        </div>
      </fieldset>
    );
  }

  // Written answers (ShortAnswer / LongAnswer)
  return (
    <div className="p-6 border-2 border-gray-200 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-800 mb-6">
      <label htmlFor={q.id} className="block">
        <p className="font-bold text-lg text-gray-900 dark:text-white mb-2">
          {q.text}
        </p>
        <p className="text-xs text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 px-3 py-1 rounded-full inline-block mb-4">
          {domains.join(", ")}
        </p>
      </label>
      <textarea
        id={q.id}
        rows={q.minLength > 100 ? 8 : 4}
        value={value || ""}
        onChange={(e) => onChange(q.id, e.target.value)}
        placeholder="Type your answer here..."
        className={cn(
          "w-full px-4 py-3 border-2 border-gray-300 dark:border-gray-600 rounded-lg",
          "bg-white dark:bg-gray-700 text-gray-900 dark:text-white",
          "placeholder-gray-500 dark:placeholder-gray-400",
          "focus:border-blue-600 dark:focus:border-blue-400 focus:ring-2 focus:ring-blue-600 dark:focus:ring-blue-400 focus:ring-opacity-50",
          "transition-colors duration-200 font-medium resize-none"
        )}
        aria-describedby={`${q.id}-hint`}
      />
      <div
        id={`${q.id}-hint`}
        className="text-xs text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-900/30 px-3 py-2 rounded mt-3 border border-blue-200 dark:border-blue-800"
      >
        <strong>💡 Hint:</strong> {q.helpText || "Provide detailed answer"}.
        Minimum {q.minLength || 0} words.
      </div>
    </div>
  );
}
