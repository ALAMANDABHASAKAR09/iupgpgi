import React from "react";
import { cn } from "../../utils/api";

export default function SelectionCard({
  children,
  className = "",
  raised = false,
}) {
  return (
    <div
      className={cn(
        "p-6 bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700",
        "shadow-sm hover:shadow-md transition-shadow duration-200",
        raised && "shadow-lg",
        className
      )}
    >
      {children}
    </div>
  );
}
