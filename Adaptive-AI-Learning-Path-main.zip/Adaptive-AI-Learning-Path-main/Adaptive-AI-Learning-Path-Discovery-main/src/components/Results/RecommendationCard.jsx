import React from "react";
import { cn } from "../../utils/api";
import { generateTags } from "../../utils/recommender";

export default function RecommendationCard({ course, userPrefs = {} }) {
  // Prefer precomputed tags from recommender utility when present
  const tags =
    Array.isArray(course._tags) && course._tags.length
      ? course._tags
      : generateTags(course, userPrefs);
  const drivers = Array.isArray(course._drivers) ? course._drivers : [];
  const score =
    course._score != null
      ? Math.round(course._score * 100)
      : Math.round(course.analytics?.final_comparison_score || 0);
  const rating = course.Rating || course.ratingValue || "-";

  return (
    <a
      href={course.link || "#"}
      target="_blank"
      rel="noreferrer"
      className={cn(
        "group block p-4 border-2 rounded-xl shadow-sm hover:shadow-lg transition-all duration-200",
        "bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700",
        "hover:border-primary-600 dark:hover:border-primary-500",
        "hover:-translate-y-1"
      )}
    >
      <div className="flex gap-4 items-start">
        {/* Thumbnail */}
        <div className="relative flex-shrink-0 w-32 h-24 rounded-lg overflow-hidden bg-gray-200 dark:bg-gray-700">
          <img
            src={
              course.imageSrc ||
              course.ImageURL ||
              course.thumbnail ||
              "/background.jpg"
            }
            alt={course.title || course.name || "course"}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          {score > 0 && (
            <div className="absolute top-2 right-2 bg-gradient-to-r from-primary-600 to-secondary-600 text-white px-2 py-1 rounded-lg text-xs font-bold">
              {score}%
            </div>
          )}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-3 mb-2">
            <div className="min-w-0 flex-1">
              <h3 className="text-base md:text-lg font-semibold text-gray-900 dark:text-white line-clamp-2 group-hover:text-primary-600 transition-colors">
                {course.title}
              </h3>
              {rating !== "-" && (
                <p className="text-xs text-gray-600 dark:text-gray-400 mt-0.5">
                  ⭐ {rating}
                </p>
              )}
            </div>
          </div>

          {/* Drivers: show small inline badges */}
          {drivers.length > 0 && (
            <div className="flex gap-2 mt-2 mb-2 flex-wrap">
              {drivers.slice(0, 3).map((d, i) => (
                <span
                  key={i}
                  className="text-xs px-2 py-1 bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-100 rounded-full font-medium"
                  title={d.name}
                >
                  {d.name}: {Math.round((d.contribution || 0) * 100)}%
                </span>
              ))}
            </div>
          )}

          {/* Description */}
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-3 line-clamp-2">
            {course.whatYoullLearn?.[0] ||
              course.analytics?.insight ||
              course.description ||
              "No description"}
          </p>

          {/* Tags */}
          <div className="flex flex-wrap gap-2 max-h-20 overflow-y-auto">
            {tags && tags.length ? (
              tags
                .slice(0, 20)
                .map((t, idx) => (
                  <TagChip key={idx} tag={t} userPrefs={userPrefs} />
                ))
            ) : (
              <span className="text-xs text-gray-500 dark:text-gray-400">
                No tags
              </span>
            )}
          </div>
        </div>
      </div>
    </a>
  );
}

function TagChip({ tag, userPrefs }) {
  const typeClasses = {
    interest:
      "bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-100",
    topic:
      "bg-indigo-100 dark:bg-indigo-900 text-indigo-800 dark:text-indigo-100",
    badge: "bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-100",
    weakness: "bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-100",
    mixed:
      "bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-100",
    score: "bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-100",
  };

  const baseClass = typeClasses[tag.type || "topic"] || typeClasses.topic;
  const border = tag.match
    ? "ring-2 ring-offset-1 ring-primary-600 dark:ring-offset-gray-800"
    : "";
  const opacity = tag.durationMismatch ? "opacity-50" : "";

  return (
    <span
      className={cn(
        "inline-flex px-2.5 py-1 rounded-full text-xs font-medium transition-all",
        baseClass,
        border,
        opacity
      )}
      title={`${tag.type || "tag"}: ${tag.name}`}
    >
      {tag.name}
    </span>
  );
}
