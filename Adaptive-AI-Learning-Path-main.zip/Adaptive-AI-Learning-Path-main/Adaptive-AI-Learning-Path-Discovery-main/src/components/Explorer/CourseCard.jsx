import React, { useState } from "react";
import { cn } from "../../utils/api";

export default function CourseCard({
  course,
  compact = false,
  showImage = true,
}) {
  const [isHovered, setIsHovered] = useState(false);
  const rating = course.ratingValue || course.Rating || "-";
  const enroll = course.analytics?.enrollments || course.enrollments || "-";
  const hours = course.totalHours || course.duration || "-";
  const myScore = course.analytics?.myScore || course.myScore || "";
  const level = course.level || "All Levels";
  const platform = course.platform || "Course";

  const renderStars = (rating) => {
    const num = parseFloat(rating);
    if (isNaN(num)) return "-";
    return "⭐ " + num.toFixed(1);
  };

  return (
    <a
      href={course.link || "#"}
      target="_blank"
      rel="noreferrer"
      className={cn(
        "course-card group block rounded-xl overflow-hidden transition-all duration-300",
        "bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700",
        "hover:shadow-lg hover:-translate-y-1",
        compact ? "p-2" : "h-full flex flex-col"
      )}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      title={course.title}
      aria-label={`${course.title} - ${platform}`}
    >
      {/* Image Container */}
      {showImage && (
        <div
          className={cn(
            "overflow-hidden bg-gray-200 dark:bg-gray-700",
            compact ? "h-20" : "h-48"
          )}
        >
          <img
            src={
              course.ImageURL ||
              course.imageSrc ||
              course.image ||
              "/background.jpg"
            }
            alt={course.title || course.name || "Course thumbnail"}
            loading="lazy"
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
        </div>
      )}

      {/* Content Container */}
      <div
        className={cn(
          "flex flex-col flex-1",
          compact ? "p-2 text-xs" : "p-5 text-sm"
        )}
      >
        {/* Title & Rating */}
        <div className="mb-2">
          <div className="flex items-start justify-between gap-2 mb-1">
            <h3
              className={cn(
                "font-bold text-gray-900 dark:text-white line-clamp-2",
                compact ? "text-xs" : "text-lg"
              )}
            >
              {course.title}
            </h3>
            {!compact && (
              <span className="text-yellow-500 text-sm font-semibold flex-shrink-0 whitespace-nowrap">
                {renderStars(rating)}
              </span>
            )}
          </div>
          {!compact && (
            <span className="inline-block text-xs bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-100 px-2 py-1 rounded-full font-medium">
              {level}
            </span>
          )}
        </div>

        {/* Description */}
        <p
          className={cn(
            "text-gray-600 dark:text-gray-400 mb-3",
            compact
              ? "text-xs line-clamp-2"
              : "text-sm line-clamp-3 group-hover:line-clamp-none"
          )}
        >
          {course.description ||
            course.analytics?.insight?.reason ||
            "No description available"}
        </p>

        {/* Metadata Footer */}
        <div
          className={cn(
            "mt-auto pt-3 border-t border-gray-200 dark:border-gray-700",
            "flex flex-wrap items-center justify-between gap-2 text-xs text-gray-600 dark:text-gray-400"
          )}
        >
          <span className="font-medium">
            {hours} {hours !== "-" ? "hrs" : ""}
          </span>
          <span>📊 {enroll}</span>
          {myScore && (
            <span className="text-green-600 dark:text-green-400">
              ✓ {myScore}
            </span>
          )}
        </div>

        {/* Insight (hover) */}
        {!compact && course.analytics?.insight?.reason && isHovered && (
          <div className="mt-3 p-2 bg-blue-50 dark:bg-blue-950 rounded text-xs text-blue-900 dark:text-blue-100">
            <strong>Why:</strong> {course.analytics.insight.reason}
          </div>
        )}
      </div>

      {/* Hover Overlay Badge */}
      {!compact && isHovered && (
        <div className="absolute top-3 right-3 bg-blue-600 text-white px-3 py-1 rounded-full text-xs font-semibold">
          View →
        </div>
      )}
    </a>
  );
}
