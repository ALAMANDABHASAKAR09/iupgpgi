import React from "react";
import { cn } from "../../utils/api";

export default function ActiveFilters({ filters, onRemove }) {
  const tags = [];
  if (filters.search)
    tags.push({ key: "search", label: `Search: "${filters.search}"` });
  if (filters.level)
    tags.push({ key: "level", label: `Level: ${filters.level}` });
  filters.topic &&
    Array.from(filters.topic).forEach((t) =>
      tags.push({ key: `topic:${t}`, label: `${t}`, value: t })
    );
  filters.duration &&
    Array.from(filters.duration).forEach((t) =>
      tags.push({ key: `duration:${t}`, label: `${t}`, value: t })
    );
  if (filters.rating > 0)
    tags.push({ key: "rating", label: `⭐ ${filters.rating}+` });
  if (filters.enrollment > 0)
    tags.push({
      key: "enrollment",
      label: `📊 ${filters.enrollment}+ enrolls`,
    });
  if (filters.sort && filters.sort !== "ai_score_desc")
    tags.push({ key: "sort", label: `Sort: ${filters.sort}` });

  if (tags.length === 0) {
    return (
      <div className="text-sm text-gray-500 dark:text-gray-400 italic py-2">
        No active filters
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm font-semibold text-gray-700 dark:text-gray-300">
          Active Filters ({tags.length})
        </p>
      </div>
      <div className="flex flex-wrap gap-2">
        {tags.map((t) => (
          <button
            key={t.key}
            onClick={() => onRemove && onRemove(t.key, t.value)}
            className={cn(
              "inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-medium",
              "bg-primary-100 dark:bg-primary-900 text-primary-700 dark:text-primary-100",
              "border border-primary-300 dark:border-primary-700",
              "hover:bg-primary-200 dark:hover:bg-primary-800",
              "transition-colors duration-200 group"
            )}
            aria-label={`Remove filter: ${t.label}`}
            title={`Remove: ${t.label}`}
          >
            <span>{t.label}</span>
            <span className="group-hover:rotate-90 transition-transform duration-200">
              ✕
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}
