import React from "react";
import { cn } from "../../utils/api";
import CourseCard from "./CourseCard";

export default function CourseGrid({ courses, compact = false }) {
  if (!courses || courses.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <div className="text-5xl mb-4">🔍</div>
        <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
          No courses found
        </h3>
        <p className="text-gray-600 dark:text-gray-400">
          Try adjusting your filters or search terms
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="text-sm font-medium text-gray-600 dark:text-gray-400">
        Showing{" "}
        <strong className="text-gray-900 dark:text-white">
          {courses.length}
        </strong>{" "}
        course{courses.length !== 1 ? "s" : ""}
      </div>
      <div
        className={cn(
          "grid gap-6",
          compact
            ? "grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6"
            : "grid-cols-1 md:grid-cols-2 lg:grid-cols-3"
        )}
      >
        {courses.map((c, i) => (
          <CourseCard
            key={c.id || i}
            course={c}
            compact={compact}
            showImage={!compact}
          />
        ))}
      </div>
    </div>
  );
}
