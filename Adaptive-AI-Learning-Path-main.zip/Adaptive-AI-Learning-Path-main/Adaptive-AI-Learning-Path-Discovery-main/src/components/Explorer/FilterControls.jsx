import React, { useState } from "react";
import { cn } from "../../utils/api";

export default function FilterControls({
  uniqueTags = { level: [], topic: [], duration: [] },
  onLevelChange,
  onTopicChange,
  onDurationChange,
  onRatingChange,
  onEnrollmentChange,
  onSortChange,
  activeLevel = "",
  activeTopics = new Set(),
  activeDurations = new Set(),
}) {
  const [expandedSections, setExpandedSections] = useState({
    level: true,
    topic: true,
    duration: true,
  });

  const toggleSection = (section) => {
    setExpandedSections((prev) => ({ ...prev, [section]: !prev[section] }));
  };

  const SectionHeader = ({ title, section }) => (
    <button
      onClick={() => toggleSection(section)}
      className={cn(
        "w-full flex items-center justify-between py-3 px-4 font-semibold rounded-lg",
        "bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700",
        "transition-colors duration-200 text-gray-900 dark:text-white"
      )}
      aria-expanded={expandedSections[section]}
      aria-controls={`${section}-content`}
    >
      <span>{title}</span>
      <span
        className={cn(
          "transition-transform duration-200",
          expandedSections[section] ? "rotate-180" : ""
        )}
      >
        ▼
      </span>
    </button>
  );

  return (
    <div className="space-y-4 bg-white dark:bg-gray-800 p-5 rounded-xl border border-gray-200 dark:border-gray-700">
      <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
        🔍 Filters
      </h3>

      {/* Level Filter */}
      <div>
        <SectionHeader title="Experience Level" section="level" />
        {expandedSections.level && (
          <div id="level-content" className="mt-2 space-y-2 px-4 py-3">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                checked={activeLevel === ""}
                onChange={() => onLevelChange && onLevelChange("")}
                className="w-4 h-4"
              />
              <span className="text-gray-900 dark:text-white">All Levels</span>
            </label>
            {uniqueTags.level.map((level) => (
              <label
                key={level}
                className="flex items-center gap-2 cursor-pointer"
              >
                <input
                  type="radio"
                  checked={activeLevel === level}
                  onChange={() => onLevelChange && onLevelChange(level)}
                  className="w-4 h-4"
                />
                <span className="text-gray-900 dark:text-white text-sm">
                  {level}
                </span>
              </label>
            ))}
          </div>
        )}
      </div>

      {/* Topic Filter */}
      {uniqueTags.topic && uniqueTags.topic.length > 0 && (
        <div>
          <SectionHeader title="Topics" section="topic" />
          {expandedSections.topic && (
            <div
              id="topic-content"
              className="mt-2 space-y-2 px-4 py-3 max-h-48 overflow-y-auto"
            >
              {uniqueTags.topic.map((topic) => (
                <label
                  key={topic}
                  className="flex items-center gap-2 cursor-pointer"
                >
                  <input
                    type="checkbox"
                    checked={activeTopics.has(topic)}
                    onChange={() => onTopicChange && onTopicChange(topic)}
                    className="w-4 h-4"
                  />
                  <span className="text-gray-900 dark:text-white text-sm">
                    {topic}
                  </span>
                </label>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Duration Filter */}
      {uniqueTags.duration && uniqueTags.duration.length > 0 && (
        <div>
          <SectionHeader title="Duration" section="duration" />
          {expandedSections.duration && (
            <div
              id="duration-content"
              className="mt-2 space-y-2 px-4 py-3 max-h-48 overflow-y-auto"
            >
              {uniqueTags.duration.map((duration) => (
                <label
                  key={duration}
                  className="flex items-center gap-2 cursor-pointer"
                >
                  <input
                    type="checkbox"
                    checked={activeDurations.has(duration)}
                    onChange={() =>
                      onDurationChange && onDurationChange(duration)
                    }
                    className="w-4 h-4"
                  />
                  <span className="text-gray-900 dark:text-white text-sm">
                    {duration}
                  </span>
                </label>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Rating Filter */}
      <div className="pt-3 border-t border-gray-200 dark:border-gray-700">
        <label
          htmlFor="rating-select"
          className="block text-sm font-semibold text-gray-900 dark:text-white mb-2"
        >
          Minimum Rating
        </label>
        <select
          id="rating-select"
          onChange={(e) => onRatingChange && onRatingChange(e.target.value)}
          className={cn(
            "w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg",
            "bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm",
            "focus:border-primary-600 focus:ring-1 focus:ring-primary-600"
          )}
        >
          <option value="0">Any Rating</option>
          <option value="3">3.0+</option>
          <option value="3.5">3.5+</option>
          <option value="4">4.0+</option>
          <option value="4.5">4.5+</option>
        </select>
      </div>

      {/* Sorting */}
      <div className="pt-3 border-t border-gray-200 dark:border-gray-700">
        <label
          htmlFor="sort-select"
          className="block text-sm font-semibold text-gray-900 dark:text-white mb-2"
        >
          Sort By
        </label>
        <select
          id="sort-select"
          onChange={(e) => onSortChange && onSortChange(e.target.value)}
          className={cn(
            "w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg",
            "bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm",
            "focus:border-primary-600 focus:ring-1 focus:ring-primary-600"
          )}
        >
          <option value="ai_score_desc">Best Match</option>
          <option value="rating_desc">Highest Rated</option>
          <option value="enrollment_desc">Most Popular</option>
          <option value="title_asc">Title (A-Z)</option>
        </select>
      </div>
    </div>
  );
}
