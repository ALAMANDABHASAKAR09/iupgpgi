import React, { useEffect, useState } from "react";
import { cn } from "../../utils/api";

export default function Header({ onSearch }) {
  const [query, setQuery] = useState("");
  const [isDark, setIsDark] = useState(
    typeof document !== "undefined" &&
      document.documentElement.classList.contains("dark")
  );

  useEffect(() => {
    // Keep internal state in sync if other code toggles the class
    const obs = new MutationObserver(() =>
      setIsDark(document.documentElement.classList.contains("dark"))
    );
    obs.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["class"],
    });
    return () => obs.disconnect();
  }, []);

  function toggle() {
    document.documentElement.classList.toggle("dark");
    setIsDark(document.documentElement.classList.contains("dark"));
  }

  return (
    <header className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 py-6">
      {/* Branding */}
      <div>
        <h1 className="text-4xl font-extrabold bg-gradient-to-r from-primary-600 to-secondary-600 bg-clip-text text-transparent">
          Course Explorer
        </h1>
        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
          Discover curated learning paths & courses
        </p>
      </div>

      {/* Search & Controls */}
      <div className="flex items-center gap-3 w-full sm:w-auto">
        <div className="flex-1 sm:flex-none sm:w-96">
          <input
            aria-label="Search courses"
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              onSearch && onSearch(e.target.value);
            }}
            placeholder="Search 'LLM', 'RAG', 'AI'..."
            className={cn(
              "w-full px-4 py-3 rounded-lg border-2 transition-all duration-200",
              "bg-white dark:bg-gray-800 text-gray-900 dark:text-white",
              "border-gray-300 dark:border-gray-600",
              "focus:border-primary-600 focus:ring-2 focus:ring-primary-600 focus:ring-opacity-50",
              "placeholder:text-gray-500 dark:placeholder:text-gray-500"
            )}
          />
        </div>

        {/* Theme Toggle */}
        <button
          onClick={toggle}
          className={cn(
            "p-3 rounded-lg transition-all duration-200",
            "hover:bg-gray-200 dark:hover:bg-gray-700",
            "focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-600"
          )}
          aria-label={`Switch to ${isDark ? "light" : "dark"} mode`}
          aria-pressed={isDark}
          title={`Toggle theme (${isDark ? "Light" : "Dark"} mode)`}
        >
          <span className="text-2xl">{isDark ? "☀️" : "🌙"}</span>
        </button>
      </div>
    </header>
  );
}
