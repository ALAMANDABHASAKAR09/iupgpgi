import React, { useEffect, useRef } from "react";

export default function StageRevealModal({ open, onClose, stage }) {
  const dialogRef = useRef(null);
  const previouslyFocused = useRef(null);

  useEffect(() => {
    if (!open) return;
    previouslyFocused.current = document.activeElement;

    // Move focus into the dialog
    const focusable = dialogRef.current?.querySelectorAll(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    );
    if (focusable && focusable.length) {
      focusable[0].focus();
    } else if (dialogRef.current) {
      dialogRef.current.focus();
    }

    function onKey(e) {
      if (e.key === "Escape") {
        e.preventDefault();
        onClose && onClose();
      }
      if (e.key === "Tab") {
        // basic focus trap
        const nodes = focusable ? Array.from(focusable) : [];
        if (nodes.length === 0) return;
        const first = nodes[0];
        const last = nodes[nodes.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    }

    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("keydown", onKey);
      try {
        previouslyFocused.current && previouslyFocused.current.focus();
      } catch (e) {}
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} aria-hidden="true" />
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="stage-modal-title"
        tabIndex={-1}
        className="relative bg-white dark:bg-gray-900 rounded-xl p-6 max-w-2xl w-full shadow-2xl"
      >
        <h2 id="stage-modal-title" className="text-xl font-bold mb-2">
          {stage.title}
        </h2>
        <p className="text-sm text-gray-700 dark:text-gray-300">
          {stage.longDescription || stage.summary}
        </p>
        <div className="mt-4 flex justify-end gap-2">
          <button
            onClick={onClose}
            className="px-3 py-1 rounded border"
            aria-label={`Close ${stage.title} details`}
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
