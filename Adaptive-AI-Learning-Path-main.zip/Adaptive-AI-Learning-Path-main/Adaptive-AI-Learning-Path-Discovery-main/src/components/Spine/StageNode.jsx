import React, { useEffect, useRef } from "react";
import { useActiveStage } from "./ActiveStageController";
import useInView from "./hooks/useInView";
import MotionWrapper from "./MotionWrapper";

export default function StageNode({ stage, index, total = 0 }) {
  const {
    activeIndex,
    setActive,
    registerRef,
    scrollTo,
    completed,
    markCompleted,
  } = useActiveStage();
  const [ref, inView] = useInView({
    rootMargin: "-30% 0px -30% 0px",
    threshold: 0.5,
  });
  const localRef = useRef(null);
  const side = index % 2 === 0 ? "left" : "right";
  const isActive = activeIndex === index;

  useEffect(() => {
    if (localRef.current) registerRef(index, localRef.current);
  }, [localRef.current]);

  useEffect(() => {
    if (inView) setActive(index);
  }, [inView, index]);

  return (
    <section ref={ref} className="relative mb-12 lg:mb-24">
      <div
        ref={localRef}
        className="absolute left-0 lg:left-0 top-4 lg:top-6 w-full pointer-events-none"
      >
        {/* node anchor */}
      </div>

      <div
        className={`flex flex-col lg:flex-row items-start lg:items-center ${
          side === "left" ? "lg:flex-row-reverse" : ""
        }`}
      >
        <div className="lg:w-24 flex justify-center">
          <div
            className={`node w-10 h-10 rounded-full flex items-center justify-center transition-transform duration-300 ${
              isActive ? "scale-105 ring-4 ring-cyan-400/40" : ""
            } ${
              completed.has(index)
                ? "bg-green-500"
                : "bg-gradient-to-br from-cyan-400 to-violet-600"
            }`}
            aria-hidden="true"
          >
            {completed.has(index) ? "✓" : ""}
          </div>
        </div>

        <MotionWrapper
          className={`stage-card cursor-pointer p-4 rounded-lg bg-white dark:bg-gray-800 shadow-sm transition-transform duration-300 w-full lg:max-w-3xl ${
            isActive ? "scale-100 shadow-lg" : "opacity-90"
          }`}
          motionProps={{
            initial: { opacity: 0, y: 8 },
            animate: { opacity: 1, y: 0 },
            transition: { duration: 0.35 },
          }}
          tabIndex={0}
          onClick={() => scrollTo(index)}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              scrollTo(index);
            }
          }}
        >
          <h3 className="font-semibold text-lg text-gray-900 dark:text-white">
            {stage.title}
          </h3>
          {stage.summary && (
            <p className="text-sm text-gray-600 dark:text-gray-300 mt-2">
              {stage.summary}
            </p>
          )}
          <div className="mt-3 flex items-center gap-3">
            <button
              onClick={(ev) => {
                ev.stopPropagation();
                markCompleted(index);
              }}
              className="px-3 py-1 rounded bg-blue-600 text-white text-sm"
            >
              Mark Done
            </button>
            <button
              onClick={(ev) => {
                ev.stopPropagation();
                scrollTo(index);
              }}
              className="px-3 py-1 rounded border border-gray-200 dark:border-gray-700 text-sm"
            >
              Focus
            </button>
          </div>
        </MotionWrapper>
      </div>
    </section>
  );
}
