import React from "react";
import { ActiveStageProvider, useActiveStage } from "./ActiveStageController";
import StageNode from "./StageNode";
import "./spine.css";

function InnerKeyboardNav({ stages }) {
  const { activeIndex, focusNext, focusPrev, scrollTo } = useActiveStage();

  // Announce active stage for screen readers
  const title = (stages && stages[activeIndex] && stages[activeIndex].title) || "";

  function onKeyDown(e) {
    // Keyboard navigation: ArrowUp/ArrowLeft -> prev, ArrowDown/ArrowRight -> next, Home/End -> first/last
    switch (e.key) {
      case "ArrowUp":
      case "ArrowLeft":
        e.preventDefault();
        focusPrev();
        break;
      case "ArrowDown":
      case "ArrowRight":
        e.preventDefault();
        focusNext();
        break;
      case "Home":
        e.preventDefault();
        scrollTo(0);
        break;
      case "End":
        e.preventDefault();
        scrollTo(Math.max(0, stages.length - 1));
        break;
      default:
        break;
    }
  }

  return (
    <div onKeyDown={onKeyDown} tabIndex={0}>
      <div aria-live="polite" className="sr-only">
        {`Stage ${activeIndex + 1}: ${title}`}
      </div>
    </div>
  );
}

export default function SpineLayout({
  stages = [],
  onStageComplete,
  onStageFocus,
}) {
  return (
    <ActiveStageProvider
      onStageComplete={onStageComplete}
      onStageFocus={onStageFocus}
    >
      <div className="spine-layout container mx-auto px-4 lg:px-8 py-8">
        <div className="lg:flex lg:items-start">
          <aside className="hidden lg:block w-28 sticky top-24">
            <div className="spine h-full mx-auto" aria-hidden="true" />
          </aside>

          <main className="flex-1 lg:pl-10">
            {/* Keyboard navigation and live announcer live inside the provider so they can use the context */}
            <InnerKeyboardNav stages={stages} />
            {stages.map((s, i) => (
              <StageNode
                key={s.id ?? i}
                stage={s}
                index={i}
                total={stages.length}
              />
            ))}
          </main>
        </div>
      </div>
    </ActiveStageProvider>
  );
}
