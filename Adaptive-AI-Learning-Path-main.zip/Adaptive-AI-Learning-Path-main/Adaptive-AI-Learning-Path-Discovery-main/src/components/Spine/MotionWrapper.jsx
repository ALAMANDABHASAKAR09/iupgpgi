import React from "react";
import { motion, useReducedMotion } from "framer-motion";

// MotionWrapper uses framer-motion to wrap children with a motion.div and
// respects the user's prefers-reduced-motion setting. This requires
// framer-motion to be installed (added to package.json).
export default function MotionWrapper({
  children,
  motionProps = {},
  className = "",
  ...rest
}) {
  const reduce = useReducedMotion();

  // If the user prefers reduced motion, neutralize animation props
  const safeProps = reduce
    ? {
        initial: {},
        animate: {},
        transition: { duration: 0 },
      }
    : motionProps;

  return (
    <motion.div className={className} {...safeProps} {...rest}>
      {children}
    </motion.div>
  );
}
