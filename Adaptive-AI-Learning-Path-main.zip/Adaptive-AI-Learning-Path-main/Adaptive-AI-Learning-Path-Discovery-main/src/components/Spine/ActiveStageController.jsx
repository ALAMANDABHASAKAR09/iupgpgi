import React, { createContext, useContext, useRef, useState } from "react";

const ActiveStageContext = createContext(null);

export function ActiveStageProvider({
  children,
  onStageComplete,
  onStageFocus,
}) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [completed, setCompleted] = useState(() => new Set());
  const nodeRefs = useRef([]);

  function registerRef(i, el) {
    nodeRefs.current[i] = el;
  }

  function scrollTo(i) {
    const el = nodeRefs.current[i];
    if (!el) return;
    try {
      el.scrollIntoView({ behavior: "smooth", block: "center" });
    } catch (e) {
      el.scrollIntoView();
    }
    setActiveIndex(i);
    try {
      if (typeof onStageFocus === "function") onStageFocus(i);
    } catch (e) {}
  }

  function markCompleted(i) {
    setCompleted((s) => new Set([...Array.from(s), i]));
    try {
      if (typeof onStageComplete === "function") onStageComplete(i);
    } catch (e) {}
  }

  function focusNext() {
    const len = nodeRefs.current.length;
    if (len === 0) return;
    const next = Math.min(len - 1, activeIndex + 1);
    scrollTo(next);
  }

  function focusPrev() {
    const len = nodeRefs.current.length;
    if (len === 0) return;
    const prev = Math.max(0, activeIndex - 1);
    scrollTo(prev);
  }

  return (
    <ActiveStageContext.Provider
      value={{
        activeIndex,
        setActive: setActiveIndex,
        registerRef,
        scrollTo,
        completed,
        markCompleted,
        focusNext,
        focusPrev,
      }}
    >
      {children}
    </ActiveStageContext.Provider>
  );
}

export function useActiveStage() {
  const ctx = useContext(ActiveStageContext);
  if (!ctx)
    throw new Error("useActiveStage must be used within ActiveStageProvider");
  return ctx;
}
