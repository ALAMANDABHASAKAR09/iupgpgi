/**
 * cn() - Safe className merging utility
 * Safely merges Tailwind classes and filters out falsy values
 */
export function cn(...classes) {
  return classes.filter(Boolean).join(" ").trim();
}

export async function fetchAllCourses() {
  // updated to use final_* datasets generated for each level
  const baseUrl = import.meta.env.BASE_URL || "/";
  const files = [
    `${baseUrl}final_beginner_courses.json`,
    `${baseUrl}final_intermediate_courses.json`,
    `${baseUrl}final_expert_courses.json`,
  ];
  console.debug("[fetchAllCourses] Base URL:", baseUrl);
  console.debug("[fetchAllCourses] Fetching files:", files);

  const results = [];
  for (const f of files) {
    try {
      console.debug("[fetchAllCourses] Fetching:", f);
      const res = await fetch(f);
      if (!res.ok) {
        console.warn("failed to fetch", f, "status:", res.status);
        continue;
      }
      const data = await res.json();
      console.debug(
        "[fetchAllCourses] Loaded courses from",
        f,
        "count:",
        data.length
      );
      results.push(...data);
    } catch (e) {
      console.warn("failed to fetch", f, e);
    }
  }

  console.debug("[fetchAllCourses] Total courses loaded:", results.length);

  // normalize
  return results.map((c) => ({
    ...c,
    level: c.level || c.Level || "Beginner",
    Rating: parseFloat(c.ratingValue) || parseFloat(c.Rating) || 0,
    totalHours: parseFloat(c.totalHours) || 0,
    ImageURL: c.imageSrc || c.image || "",
  }));
}
