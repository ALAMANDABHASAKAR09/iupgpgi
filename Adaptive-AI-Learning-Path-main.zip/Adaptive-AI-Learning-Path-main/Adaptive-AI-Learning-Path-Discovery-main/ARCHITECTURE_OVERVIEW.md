# ARCHITECTURE OVERVIEW & DATA FLOW DIAGRAMS

## Adaptive AI Learning Path Discovery - System Design

---

## 1. CURRENT DATA FLOW (BEFORE FIXES)

```
┌─────────────────────────────────────────────────────────────────┐
│                         USER BROWSER                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌─────────────────┐      ┌──────────────────┐                   │
│  │  Home.jsx       │      │  Explorer.jsx    │                   │
│  │  (Wizard)       │      │  (Course Grid)   │                   │
│  └────────┬────────┘      └────────┬─────────┘                   │
│           │                        │                             │
│           ├─ Step1_Field          │ CourseCard                   │
│           ├─ Step2_Level          │ FilterControls              │
│           ├─ Step3_Topic          │ ActiveFilters               │
│           ├─ Step4_Duration       │                             │
│           ├─ Step5_AdaptiveAssess │                             │
│           └─ Step6_Results        │                             │
│                                    │                             │
└────────────────────────────────────────────────────────────────┘
                        ↓
        ┌───────────────────────────────┐
        │   PUBLIC DATA FILES (JSON)    │
        ├───────────────────────────────┤
        │ final_beginner_courses.json   │
        │ final_intermediate_courses.json
        │ final_expert_courses.json     │
        │ mcq_questions.json            │
        │ mcms_questions.json           │
        │ profiler_questions.json       │
        └───────────────────────────────┘
                        │
        ┌───────────────┴────────────────┐
        ↓                                ↓
    ┌─────────────┐          ┌──────────────────┐
    │ PROBLEMS:   │          │  ISSUES:         │
    │- No retries │          │  - Races courses │
    │- 404s fail  │          │  - Bad question  │
    │- Timeouts   │          │  - No norms      │
    └─────────────┘          └──────────────────┘
```

**Current Problems:**

- No error handling on fetch failures
- No data normalization (inconsistent field names)
- No retry logic (timeouts kill flow)
- No loading states (UI seems frozen)

---

## 2. IMPROVED DATA FLOW (AFTER FIXES)

```
┌────────────────────────────────────────────────────────────────────────┐
│                      APP INITIALIZATION                                │
├────────────────────────────────────────────────────────────────────────┤
│  1. App.jsx loads                                                       │
│  2. App wraps with ErrorBoundary (catch crashes)                        │
│  3. Dark mode initialized from localStorage                             │
│  4. Home.jsx mounts                                                     │
│  5. Courses fetched with resilient retry logic                          │
│  6. Questions loaded when Step 5 reached                                │
│  7. User profile restored from localStorage (Set de-serialization)      │
└────────────────────────────────────────────────────────────────────────┘
                            ↓
┌────────────────────────────────────────────────────────────────────────┐
│                      STEP 1-4: PREFERENCES                             │
├────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌─────────────────────┐  ┌────────────────────────┐                   │
│  │ setSelection()      │→ │ appState.selections    │                   │
│  │ Stores user         │  │ {                      │                   │
│  │ choices:            │  │   field: string        │                   │
│  │ - field             │  │   level: string        │                   │
│  │ - level             │  │   topic: [string]      │                   │
│  │ - topics            │  │   duration: [string]   │                   │
│  │ - duration          │  │   outcome: string      │                   │
│  │ - outcome           │  │   format: [string]     │                   │
│  │ - format            │  │   tools: [string]      │                   │
│  │ - tools             │  │ }                      │                   │
│  │ - maxHours          │  └────────────────────────┘                   │
│  └─────────────────────┘           ↓                                   │
│                             Stored in localStorage                      │
└────────────────────────────────────────────────────────────────────────┘
                            ↓
┌────────────────────────────────────────────────────────────────────────┐
│                      STEP 5: ADAPTIVE ASSESSMENT                       │
├────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌──────────────────────────┐      ┌─────────────────────────────┐    │
│  │ Fetch & Normalize        │      │ Preprocess Question Bank    │    │
│  │ Questions:               │→     │ (for each tag)              │    │
│  │ 1. Fetch 3 JSON files    │      │ {                           │    │
│  │    - mcq_questions.json  │      │   'Core ML': {              │    │
│  │    - mcms_questions.json │      │     1: [q1, q2],            │    │
│  │    - profiler.json       │      │     2: [q3],                │    │
│  │                          │      │     ...                     │    │
│  │ 2. Normalize types:      │      │     10: [q99]               │    │
│  │    'MCQ' ← 'mcq'         │      │   }                         │    │
│  │    'MCMS' ← variations   │      │   'RAG/Vector': { ... }     │    │
│  │                          │      │ }                           │    │
│  │ 3. Extract tags          │      └─────────────────────────────┘    │
│  │    - From question.tag   │                ↓                        │
│  │    - Remove 'Profiler'   │      ┌─────────────────────────────┐    │
│  │                          │      │ Initialize User Profile     │    │
│  │ 4. Handle errors:        │      │ {                           │    │
│  │    - Timeout: 10s        │      │   isActive: true            │    │
│  │    - Empty response: []  │      │   isComplete: false         │    │
│  │    - Invalid JSON: warn  │      │   questionsAsked: Set()     │    │
│  │                          │      │   tagLevels: { tag: 5 }    │    │
│  │ 5. Serialize Set to Array│      │   tagScores: {}             │    │
│  │    before localStorage   │      │   profilerAnswers: {}       │    │
│  └──────────────────────────┘      └─────────────────────────────┘    │
│                                                      ↓                 │
│                          ┌─────────────────────────────────────┐      │
│                          │ For each question:                  │      │
│                          │ 1. selectNextQuestion()             │      │
│                          │    - Pick by adaptive difficulty    │      │
│                          │    - Respect quotas by type         │      │
│                          │ 2. updateProfile() on answer        │      │
│                          │    - Track scores per tag           │      │
│                          │    - Adjust difficulty per tag      │      │
│                          │ 3. Persist to localStorage          │      │
│                          │    (Set → Array conversion)         │      │
│                          └─────────────────────────────────────┘      │
│                                      ↓                                 │
│                          After 7 questions:                            │
│                          generateFinalProfile()                        │
│                          {                                             │
│                            totalAnswered: 7                            │
│                            totalCorrect: X                             │
│                            overallPct: Y                               │
│                            level: "Beginner|Intermediate|Expert"      │
│                            interestTags: []                            │
│                            weaknessTags: []                            │
│                          }                                             │
└────────────────────────────────────────────────────────────────────────┘
                            ↓
┌────────────────────────────────────────────────────────────────────────┐
│                      STEP 6: RECOMMENDATIONS                           │
├────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌───────────────────────────┐                                         │
│  │ handleAdaptiveComplete()  │                                         │
│  │ - Validate profile        │                                         │
│  │ - Merge user prefs        │                                         │
│  │ - Ensure all fields       │                                         │
│  │ - Store in appState       │                                         │
│  │ - Persist profile         │                                         │
│  └────────────┬──────────────┘                                         │
│               ↓                                                         │
│  ┌───────────────────────────┐     ┌──────────────────────┐            │
│  │ Recommendation Engine     │     │ Course Normalization │            │
│  │ (recommender.js):         │ ←   │ (api.js)             │            │
│  │                           │     │ - Resolve fields     │            │
│  │ 1. Fetch all courses      │     │ - Normalize analytics│            │
│  │    (if missing level)     │     │ - Set defaults       │            │
│  │                           │     └──────────────────────┘            │
│  │ 2. Score each course:     │                                         │
│  │    - Relevance match      │                                         │
│  │    - Level match          │                                         │
│  │    - Analytics scores     │                                         │
│  │    - Engagement bonus     │                                         │
│  │                           │                                         │
│  │ 3. Generate tags:         │                                         │
│  │    - Strengths (green)    │                                         │
│  │    - Weaknesses (red)     │                                         │
│  │    - Topics (blue)        │                                         │
│  │    - Badges (gold)        │                                         │
│  │                           │                                         │
│  │ 4. Explain score:         │                                         │
│  │    - Top 3 drivers        │                                         │
│  │    - Weighted factors     │                                         │
│  └───────────────────────────┘                                         │
│               ↓                                                         │
│  ┌───────────────────────────┐                                         │
│  │ STEP 6 COMPONENT          │                                         │
│  │ Display to user:          │                                         │
│  │ - Top recommendation      │                                         │
│  │ - By-level recommendations                                          │
│  │ - Per-course insights     │                                         │
│  │ - Score explainer         │                                         │
│  └───────────────────────────┘                                         │
└────────────────────────────────────────────────────────────────────────┘
                            ↓
┌────────────────────────────────────────────────────────────────────────┐
│                      STEP 7: COURSE EXPLORER                           │
├────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌────────────────┐       ┌─────────────────┐                          │
│  │ Fetch Courses  │       │ Derive Filters  │                          │
│  │ (from Step 6)  │→      │ from courses:   │                          │
│  │ - Normalize    │       │ - Levels        │                          │
│  │ - Validate     │       │ - Topics        │                          │
│  │ - Filter       │       │ - Durations     │                          │
│  └────────────────┘       └────────┬────────┘                          │
│                                    ↓                                   │
│                    ┌───────────────────────────────┐                   │
│                    │ FilterControls Component      │                   │
│                    │ - Level radio (single select) │                   │
│                    │ - Topic checkboxes (multi)    │                   │
│                    │ - Duration checkboxes (multi) │                   │
│                    │ - Rating slider               │                   │
│                    │ - Enrollment slider           │                   │
│                    │ - Search text input           │                   │
│                    │ - Sort dropdown               │                   │
│                    └───────────┬───────────────────┘                   │
│                                ↓                                       │
│                    ┌───────────────────────────────┐                   │
│                    │ ActiveFilters Component       │                   │
│                    │ Show all active filters       │                   │
│                    │ Allow removing individually   │                   │
│                    └───────────┬───────────────────┘                   │
│                                ↓                                       │
│                    ┌───────────────────────────────┐                   │
│                    │ CourseGrid Component          │                   │
│                    │ Filtered & paginated courses  │                   │
│                    │ Pagination (3 per page)       │                   │
│                    │ Empty state if no results     │                   │
│                    └───────────────────────────────┘                   │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 3. STATE MANAGEMENT STRUCTURE

```
┌──────────────────────────────────────────────────────────────┐
│                  HOME.JSX STATE (in-memory)                  │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────────────────────────────────────────────┐    │
│  │ appState (useLocalStorage 'wizard-state')            │    │
│  │ {                                                    │    │
│  │   currentStep: 1-7                                   │    │
│  │   maxStep: highest step user reached                 │    │
│  │   assessmentSubStep: 'Basics' | 'Concepts' | 'Depth'│    │
│  │   selections: {                                      │    │
│  │     field: 'ai-ml' | 'data-science' | etc           │    │
│  │     level: 'Beginner' | 'Intermediate' | 'Expert'   │    │
│  │     topic: ['RAG/Vector', 'Development', ...]       │    │
│  │     duration: ['Short (< 5h)', 'Medium ...', ...]   │    │
│  │     assessmentAnswers: { qId: answer, ...}          │    │
│  │     assessmentResults: { ...finalProfile }          │    │
│  │     outcome: 'product' | 'job' | 'manager'          │    │
│  │     format: ['Self-paced', 'Instructor-led', ...]   │    │
│  │     tools: ['Python', 'JavaScript', ...]            │    │
│  │     maxHours: number | null                          │    │
│  │   }                                                  │    │
│  │ }                                                    │    │
│  │                                                      │    │
│  │ PERSISTS TO: localStorage['wizard-state'] (JSON)     │    │
│  └──────────────────────────────────────────────────────┘    │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐    │
│  │ courses (useState)                                   │    │
│  │ [{                                                  │    │
│  │   id: string                                        │    │
│  │   title: string                                     │    │
│  │   level: 'Beginner' | 'Intermediate' | 'Expert'    │    │
│  │   Rating: 0-5                                       │    │
│  │   totalHours: number                                │    │
│  │   ImageURL: url                                     │    │
│  │   analytics: { ... }                                │    │
│  │ }, ...]                                             │    │
│  │                                                      │    │
│  │ SOURCE: fetchAllCourses() → normalized from JSON    │    │
│  └──────────────────────────────────────────────────────┘    │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐    │
│  │ questionPool (useState)                              │    │
│  │ {                                                   │    │
│  │   'Core ML': {                                      │    │
│  │     1: [question, ...],   // difficulty 1           │    │
│  │     2: [question, ...],   // difficulty 2           │    │
│  │     ...                                             │    │
│  │     10: [question, ...]   // difficulty 10          │    │
│  │   },                                                │    │
│  │   'RAG/Vector': { 1: [...], ... },                 │    │
│  │   ...                                               │    │
│  │   'Profiler': [question, ...]   // special case     │    │
│  │ }                                                   │    │
│  │                                                      │    │
│  │ SOURCE: preprocessQuestionBank() when Step 5        │    │
│  └──────────────────────────────────────────────────────┘    │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐    │
│  │ userProfile (useState + localStorage backup)         │    │
│  │ {                                                   │    │
│  │   isActive: boolean                                 │    │
│  │   isComplete: boolean                               │    │
│  │   currentQuestionIndex: number                      │    │
│  │   questionsAsked: Set(qIds) ⚠️ Serialize to Array  │    │
│  │   tagsToTest: [tags to ask about]                  │    │
│  │   tagLevels: { tag: difficulty 1-10 }             │    │
│  │   tagScores: { tag: score }                        │    │
│  │   isBeginnerPivot: boolean                         │    │
│  │   profilerAnswers: { answer }                      │    │
│  │   firstFourHistory: [...]                          │    │
│  │ }                                                   │    │
│  │                                                      │    │
│  │ PERSISTS TO: localStorage['adaptive-user-profile']  │    │
│  │              (questionsAsked converted: Set ↔ Array)│    │
│  └──────────────────────────────────────────────────────┘    │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐    │
│  │ allQuestions (useState)                              │    │
│  │ Array of all loaded questions                        │    │
│  │ Used for scoring and reference                       │    │
│  │ [{id, tag, type, text, options, ...}, ...]          │    │
│  │                                                      │    │
│  │ SOURCE: Loaded with questionPool in Step 5          │    │
│  └──────────────────────────────────────────────────────┘    │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐    │
│  │ allTags (useState)                                   │    │
│  │ ['Core ML', 'RAG/Vector', 'Development', ...]       │    │
│  │                                                      │    │
│  │ SOURCE: Extracted from allQuestions                 │    │
│  └──────────────────────────────────────────────────────┘    │
│                                                               │
└──────────────────────────────────────────────────────────────┘
```

---

## 4. ERROR HANDLING FLOW

```
┌─────────────────────────────────────────────────────────────┐
│              ERROR HANDLING ARCHITECTURE                     │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│                   ┌─────────────────────┐                    │
│                   │  Error Occurs       │                    │
│                   │  (in any component) │                    │
│                   └──────────┬──────────┘                    │
│                              ↓                              │
│          ┌───────────────────┴────────────────────┐          │
│          │                                        │          │
│      ┌───┴────────────┐             ┌────────┴────┐         │
│      ↓                ↓             ↓             ↓          │
│  ┌─────────┐    ┌──────────┐  ┌──────────┐  ┌────────┐      │
│  │ Render  │    │ Lifecycle│  │ Event    │  │ Async  │      │
│  │ Error   │    │ Error    │  │ Handler  │  │ Error  │      │
│  │ (UI)    │    │ (mount)  │  │ Error    │  │ (fetch)│      │
│  └────┬────┘    └────┬─────┘  └────┬─────┘  └───┬────┘      │
│       │              │             │            │           │
│       └──────────┬───┴─────────────┴────────────┘           │
│                  ↓                                           │
│         ┌────────────────────┐                              │
│         │  Caught by         │                              │
│         │ ErrorBoundary?     │                              │
│         └────────┬───────┬───┘                              │
│                  │       │                                  │
│              YES │       │ NO                              │
│                  ↓       ↓                                  │
│         ┌──────────┐   ┌──────────────┐                     │
│         │ Fallback │   │ Global error │                     │
│         │ UI shown │   │ handler +    │                     │
│         │ "Reload" │   │ console.error                      │
│         │ button   │   └──────────────┘                     │
│         └──────────┘                                        │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ SPECIFIC ERROR TYPES & HANDLING                      │   │
│  ├──────────────────────────────────────────────────────┤   │
│  │                                                      │   │
│  │ 1. Network Error (fetch fails)                      │   │
│  │    → Retry with exponential backoff (3 attempts)    │   │
│  │    → Show: "Could not load data. Retrying..."       │   │
│  │    → If all fail: "Check internet connection"       │   │
│  │                                                      │   │
│  │ 2. JSON Parse Error                                 │   │
│  │    → Log full response to console                   │   │
│  │    → Show: "Invalid data format"                    │   │
│  │    → Try backup/fallback source                     │   │
│  │                                                      │   │
│  │ 3. localStorage Error                               │   │
│  │    → Catch try/catch blocks                         │   │
│  │    → Log but don't fail (in-memory fallback)         │   │
│  │    → Show warning to user (optional)                │   │
│  │                                                      │   │
│  │ 4. Component Render Error                           │   │
│  │    → ErrorBoundary catches it                       │   │
│  │    → Show error UI with retry                       │   │
│  │                                                      │   │
│  │ 5. Timeout Error                                    │   │
│  │    → AbortController signals on timeout             │   │
│  │    → Clean up pending requests                      │   │
│  │    → Show: "Request took too long"                  │   │
│  │                                                      │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

## 5. COMPONENT HIERARCHY & RESPONSIBILITY

```
┌────────────────────────────────────────────────────────────┐
│                     App.jsx                                 │
│                  (Root component)                           │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ - Dark mode initialization                          │  │
│  │ - ErrorBoundary wrapper                             │  │
│  │ - Global styles                                     │  │
│  └──────────────────┬───────────────────────────────────┘  │
│                     │                                       │
│         ┌───────────┴──────────────┐                        │
│         ↓                          ↓                        │
│   ┌──────────────┐         ┌──────────────────┐             │
│   │ Home.jsx     │         │ ErrorBoundary    │             │
│   │ (Main Logic) │         │ (Error Container)│             │
│   └──────┬───────┘         └──────────────────┘             │
│          │                                                  │
│          ├─ State: appState, courses, userProfile           │
│          ├─ Hooks: useLocalStorage, useEffect              │
│          ├─ Functions: nextStep, prevStep, setSelection    │
│          │                                                  │
│          └─ Renders based on currentStep:                   │
│             │                                               │
│             ├─ Step 1 → Step1_Field                        │
│             │            └─ SelectionCard (reusable)       │
│             │                                               │
│             ├─ Step 2 → Step2_Level                        │
│             │            └─ SelectionCard                  │
│             │                                               │
│             ├─ Step 3 → Step3_Topic                        │
│             │            ├─ SelectionCard                  │
│             │            └─ QuickAdd buttons                │
│             │                                               │
│             ├─ Step 4 → Step4_Duration                     │
│             │            ├─ SelectionCard                  │
│             │            └─ Max hours input                │
│             │                                               │
│             ├─ Step 5 → Step5_AdaptiveAssessment           │
│             │            ├─ Question component             │
│             │            ├─ Progress indicator              │
│             │            └─ Submit button                   │
│             │                                               │
│             ├─ Step 6 → Step6_Results                      │
│             │            ├─ DomainAnalysis (charts)        │
│             │            ├─ RecommendationCard             │
│             │            └─ Top N recommendations           │
│             │                                               │
│             └─ Step 7 → Explorer                           │
│                        ├─ Header (search, theme)           │
│                        ├─ FilterControls (sidebar)         │
│                        ├─ ActiveFilters (tags)             │
│                        └─ CourseGrid (paginated)           │
│                           └─ CourseCard (individual)       │
│                                                             │
└────────────────────────────────────────────────────────────┘

UTILITIES & LOGIC:

┌─ api.js ──────────────────────────────────────┐
│ - cn() - className merging                    │
│ - normalizeCourse() - data normalization      │
│ - fetchJSON() - resilient fetching            │
│ - fetchAllCourses() - course loading          │
└───────────────────────────────────────────────┘

┌─ assessmentLogic.js ──────────────────────────┐
│ - preprocessQuestionBank() - organize questions│
│ - selectNextQuestion() - adaptive selection   │
│ - updateProfile() - track progress            │
│ - scoreWrittenAnswer() - grade essays         │
│ - generateFinalProfile() - compute results    │
│ - generateRecommendations() - pick courses    │
└───────────────────────────────────────────────┘

┌─ recommender.js ──────────────────────────────┐
│ - scoreCourse() - calculate fit score         │
│ - generateTags() - create metadata tags       │
│ - computeDrivers() - explain scoring          │
│ - recommend() - engine entry point            │
└───────────────────────────────────────────────┘

┌─ explorerLogic.js ────────────────────────────┐
│ - applySorting() - sort courses               │
└───────────────────────────────────────────────┘

┌─ hooks/ ──────────────────────────────────────┐
│ - useLocalStorage.js - persist state          │
│ - useDebounce, useMediaQuery, useClickOutside │
│ - useKeyPress, useAsync                       │
│ - useLoadingState (NEW)                       │
│ - usePersistedAssessment (NEW)                │
└───────────────────────────────────────────────┘

┌─ context/ (NEW) ──────────────────────────────┐
│ - QuestionContext - global question pool      │
│ - ThemeContext - dark mode (future)           │
│ - NotificationContext - toasts (future)       │
└───────────────────────────────────────────────┘
```

---

## 6. DATA SERIALIZATION / DESERIALIZATION

```
┌────────────────────────────────────────────────────────┐
│         CRITICAL: SET SERIALIZATION FLOW              │
│ (This is the #1 bug that needed fixing!)              │
├────────────────────────────────────────────────────────┤
│                                                         │
│  ❌ BROKEN (before fix):                               │
│  ────────────────────────                              │
│  userProfile.questionsAsked = new Set([1, 2, 3])      │
│  localStorage.setItem('profile', JSON.stringify(userProfile))
│                         ↓                              │
│                    ERROR: Set not serializable!        │
│                    Output: '{...questionsAsked: {}}'   │
│                                                         │
│                                                         │
│  ✅ CORRECT (after fix):                               │
│  ────────────────────────                              │
│  const copy = { ...userProfile }                       │
│  if (userProfile.questionsAsked instanceof Set) {      │
│    copy.questionsAsked = Array.from(userProfile.questionsAsked)
│  }                                                     │
│  localStorage.setItem('profile', JSON.stringify(copy))│
│                         ↓                              │
│  Success! Output: '{...questionsAsked: [1, 2, 3]}'    │
│                                                         │
│  ────────────────────────────────────────────────────  │
│                                                         │
│  DESERIALIZATION (on app reload):                      │
│  ────────────────────────────────────────────          │
│  const raw = localStorage.getItem('profile')          │
│  const parsed = JSON.parse(raw)  // parsed.questionsAsked is Array
│  parsed.questionsAsked = new Set(                      │
│    Array.isArray(parsed.questionsAsked)                │
│      ? parsed.questionsAsked                           │
│      : []                                              │
│  )                                                     │
│  setUserProfile(parsed)                                │
│                         ↓                              │
│  Now userProfile.questionsAsked is a Set again! ✓      │
│                                                         │
└────────────────────────────────────────────────────────┘
```

---

## 7. COURSE NORMALIZATION FLOW

```
┌─────────────────────────────────────────────────────────────┐
│          COURSE DATA NORMALIZATION PIPELINE                │
│  (Handling inconsistent field names across JSON files)      │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  RAW COURSE OBJECTS (from JSON):                            │
│  ────────────────────────────────────────────────────────  │
│                                                             │
│  From final_beginner_courses.json:                          │
│  { "id": "c1", "title": "Beginner AI",                      │
│    "ratingValue": 4.5, "imageSrc": "...", "level": "..." } │
│                                                             │
│  From final_intermediate_courses.json:                      │
│  { "course_id": "c2", "courseTitle": "Advanced ML",         │
│    "Rating": 4.8, "image": "...", "Level": "..." }         │
│                                                             │
│  From final_expert_courses.json:                            │
│  { "id": "c3", "heading": "Expert RAG",                     │
│    "rating": 4.2, "thumbnail_url": "...", ...}             │
│                                                             │
│                         ↓ normalizeCourse()                 │
│                                                             │
│  NORMALIZED COURSE OBJECT (guaranteed fields):              │
│  ────────────────────────────────────────────────────────  │
│  {                                                          │
│    id: string (fallback: "course-{random}")               │
│    title: string (fallback: "Untitled Course")             │
│    description: string                                     │
│    ImageURL: string (fallback: "/placeholder.jpg")         │
│    thumbnail: string                                       │
│    level: "Beginner|Intermediate|Expert"                   │
│    Rating: 0-5 (number)                                    │
│    totalHours: number                                      │
│    instructor: string                                      │
│    platform: string                                        │
│    whatYoullLearn: string[]                                │
│    keyPoints: string[]                                     │
│    analytics: {                                            │
│      final_comparison_score: 0-100                         │
│      relevance_score: 0-1                                  │
│      normalized_rating: 0-1                                │
│      normalized_popularity: 0-1                            │
│      filter_tags: string[]                                 │
│      content_freshness_score: 0-1                          │
│      course_engagement_score: 0-1                          │
│      sentiment_analysis: {                                 │
│        sentiment_score: 0-1                                │
│        detected_strengths: string[]                        │
│        detected_pain_points: string[]                      │
│      }                                                     │
│      content_features: { has_capstone_project: boolean}    │
│    }                                                       │
│    enrollmentCount: number                                 │
│    _raw: object (original for debugging)                   │
│  }                                                          │
│                                                             │
│                         ↓                                   │
│                                                             │
│  ALL COURSES NOW HAVE CONSISTENT SHAPE!                    │
│  Safe to access: course.title, course.Rating, etc.         │
│                                                             │
│  VALIDATION:                                                │
│  - Filter courses where !id (remove invalid)               │
│  - Use getField() helper for safe fallbacks                │
│  - Parse numbers with parseNum() to avoid NaN              │
│  - Ensure arrays with getArray()                           │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 8. QUESTION TYPE CLASSIFICATION

```
┌──────────────────────────────────────────────────────────────┐
│        QUESTION TYPE NORMALIZATION                           │
│  (Handling different spellings/formats of types)             │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  RAW TYPES (from different JSON sources):                    │
│  ─────────────────────────────────────────                  │
│  'MCQ', 'mcq', 'MCQ', 'single-choice', 'multiple-choice'  │
│  'MCMS', 'mcms', 'checkbox', 'multiple-select'             │
│  'ShortAnswer', 'shortanswer', 'short-answer', 'fillin'    │
│  'LongAnswer', 'longanswer', 'long-answer', 'essay'        │
│                                                              │
│                   ↓ normalizeQuestionType()                  │
│                                                              │
│  NORMALIZED TYPES (canonical):                              │
│  ──────────────────────────────────                         │
│  All map to one of these 4:                                │
│  1. 'MCQ' - single correct answer                           │
│  2. 'MCMS' - multiple correct answers                       │
│  3. 'ShortAnswer' - 1-2 sentence response                   │
│  4. 'LongAnswer' - essay response                           │
│                                                              │
│  TYPE QUOTAS (in assessment):                               │
│  ──────────────────────────────────                         │
│  MCQ: 2 questions                                           │
│  MCMS: 2 questions                                          │
│  MCQ-Reorder: 2 questions                                   │
│  ShortAnswer: 1 question                                    │
│  ────────────────────────                                   │
│  TOTAL: 7 questions per session                             │
│                                                              │
│  FILTERING LOGIC:                                           │
│  ────────────────────                                       │
│  const mcqTypes = new Set(['MCQ', 'MCQ-Matching', ...])    │
│  const mcqQuestions = mcqData.filter(q =>                   │
│    mcqTypes.has(q.type) // Use normalized type!            │
│  )                                                          │
│                                                              │
│  ✓ This ensures questions are correctly categorized         │
│  ✓ Prevents duplicate counts due to spelling variations     │
│  ✓ Enables consistent quota enforcement                     │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

---

## 9. ASSESSMENT RESULTS GENERATION

```
┌─────────────────────────────────────────────────────────────┐
│            ASSESSMENT RESULTS PIPELINE                       │
│  (From individual answers → Final profile)                   │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  INPUT: userProfile after all 7 questions                   │
│  {                                                          │
│    totalAnswered: 7                                         │
│    questionsAsked: Set(['q1', 'q2', 'q3', ...])            │
│    tagScores: {                                            │
│      'Core ML': { correct: 2, total: 2 },                  │
│      'RAG/Vector': { correct: 1, total: 2 },               │
│      'Development': { correct: 1, total: 2 },              │
│      ...                                                    │
│    }                                                        │
│  }                                                          │
│                      ↓                                      │
│            generateFinalProfile()                           │
│                      ↓                                      │
│  1. Calculate totals:                                       │
│     - totalAnswered = 7                                     │
│     - totalCorrect = sum of all correct                     │
│                                                              │
│  2. Calculate percentage:                                   │
│     - overallPct = (totalCorrect / totalAnswered) * 100     │
│     - clamp to 0-100                                        │
│                                                              │
│  3. Determine level:                                        │
│     - pct >= 81 → "Expert"                                 │
│     - pct >= 61 → "Intermediate"                           │
│     - pct >= 40 → "Beginner"                               │
│     - pct < 40 → "Beginner"                                │
│                                                              │
│  4. Extract weak tags (score < 0.4):                        │
│     - weaknessTags = ['Tag1', 'Tag2']                      │
│                                                              │
│  5. Extract interest tags (score > 0.6):                    │
│     - interestTags = ['Tag3', 'Tag4']                      │
│                                                              │
│  6. Merge with user preferences:                            │
│     - Add topic and field selections                        │
│     - Remove duplicates with Set                            │
│                                                              │
│                      ↓                                      │
│  OUTPUT: finalResults object                                │
│  {                                                          │
│    totalAnswered: 7,                                        │
│    totalCorrect: 5,                                         │
│    overallPct: 71,                                          │
│    level: "Intermediate",                                   │
│    interestTags: ['Core ML', 'RAG/Vector', 'ai-ml'],       │
│    weaknessTags: ['Development', 'Ethics/Impact'],         │
│    tagProfile: {                                            │
│      'Core ML': { score: 1.0, weight: 2, ... },            │
│      'RAG/Vector': { score: 0.5, weight: 1, ... },         │
│      ...                                                    │
│    },                                                       │
│    levelTagGroups: {                                        │
│      beginner: [...],                                       │
│      intermediate: [...],                                   │
│      expert: [...]                                          │
│    },                                                       │
│    timestamp: Date.now()                                    │
│  }                                                          │
│                      ↓                                      │
│  STORED IN:                                                 │
│  - appState.selections.assessmentResults                    │
│  - localStorage['adaptive-user-profile']                    │
│  - Passed to Step6_Results component                        │
│                      ↓                                      │
│  USED FOR:                                                  │
│  - Recommendations (filter by level & interest tags)        │
│  - Display scores and insights                              │
│  - Explorer initial filters                                 │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

## 10. KEY IMPROVEMENTS AT A GLANCE

| Issue                 | Before                            | After                            |
| --------------------- | --------------------------------- | -------------------------------- |
| **Set Serialization** | ❌ Crashes on localStorage        | ✅ Array conversion before save  |
| **Question Loading**  | ⏰ Infinite loop / race condition | ✅ Single load per session       |
| **Course Data**       | 🔀 Inconsistent field names       | ✅ Normalized object shape       |
| **Question Types**    | 😕 Mismatch (MCQ vs mcq)          | ✅ Canonical types               |
| **Error Handling**    | 🔴 App crashes silently           | ✅ ErrorBoundary + user messages |
| **Type Detection**    | 🤦 Questions never filter         | ✅ Robust normalization          |
| **Results Display**   | 📭 Missing when undefined         | ✅ Fallback derivation           |
| **Filter Reset**      | 🔄 Persists old filters           | ✅ Reset on new courses          |
| **Retry Logic**       | ❌ Single attempt, fail hard      | ✅ Exponential backoff (3x)      |
| **Accessibility**     | 🙈 No ARIA labels                 | ✅ Semantic HTML + labels        |

---

**This architecture document provides a complete visual and structural understanding of the fixed system. Reference this when implementing patches to understand the data flow and relationships.**
