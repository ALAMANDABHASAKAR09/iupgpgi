# DEBUG: Question File Paths & Loading Issues

## ✅ File Status & Inventory

### Question Files (All Files Located & Readable)

| File                    | Count            | Types               | Tags                                                                             | Status |
| ----------------------- | ---------------- | ------------------- | -------------------------------------------------------------------------------- | ------ |
| mcq_questions.json      | 26 questions     | MCQ                 | Generative AI, Prompt Engineering, AI Ethics, RAG/Vector, Langchain, Huggingface | ✅     |
| mcms_questions.json     | 1 question       | MCMS                | RAG/Vector                                                                       | ✅     |
| profiler_questions.json | 3 questions      | MCQ (Profiler tag)  | Profiler                                                                         | ✅     |
| **TOTAL**               | **30 questions** | MCQ, MCMS, Profiler | **7 unique tags**                                                                | ✅     |

### Tag Distribution in MCQ

```
Generative AI:        6 questions (ids: genai_b_001 to genai_b_005, genai_b_007)
Prompt Engineering:   2 questions (ids: genai_b_006, genai_b_008)
AI Ethics:            1 question  (id: genai_b_009)
RAG/Vector:           7 questions (ids: rag_d_001 to rag_d_007)
Langchain:            4 questions (ids: langchain_d_001 to langchain_d_004)
Huggingface:          6 questions (id: huggingface_b_001+)
```

**Problem Analysis:**

- ✅ Questions DO exist in all files
- ✅ Questions ARE properly tagged
- ⚠️ Some tags have very few questions (AI Ethics: only 1)
- ⚠️ Total questions (30) is more than enough for assessment

---

## 🔍 How Questions Are Being Loaded

### Step 1: Home.jsx Fetches Files

```javascript
// Line 95 in Home.jsx
const baseUrl = import.meta.env.BASE_URL;
// During dev: '/Adaptive-AI-Learning-Path-Discovery/'
// During build: '/Adaptive-AI-Learning-Path-Discovery/'

const mcqPath = `${baseUrl}mcq_questions.json`;
// Full URL: /Adaptive-AI-Learning-Path-Discovery/mcq_questions.json
```

### Step 2: Fetch Responses

```
✅ mcq_questions.json → 200 OK → 26 questions loaded
✅ mcms_questions.json → 200 OK → 1 question loaded
✅ profiler_questions.json → 200 OK → 3 questions loaded
```

### Step 3: Filter by Type

```javascript
const mcqTypes = [
  "MCQ",
  "MCQ-Matching",
  "MCQ-Reorder",
  "MCQ-Scenario",
  "MCQ-Matching",
];
const mcqQuestions = mcqData.filter((q) => mcqTypes.includes(q.type));
// Result: 26 MCQ questions ✅

const mcmsQuestions = mcmsData.filter((q) => q.type === "MCMS");
// Result: 1 MCMS question ✅

const profilerQuestions = profilerData.filter((q) => q.tag === "Profiler");
// Result: 3 Profiler questions ✅

const combined = [...mcqQuestions, ...mcmsQuestions, ...profilerQuestions];
// Total: 30 questions ✅
```

### Step 4: Extract Tags & Create Pool

```javascript
const tags = Array.from(new Set(filteredTech.map((q) => q.tag)));
// Result: ['Generative AI', 'Prompt Engineering', 'AI Ethics', 'RAG/Vector', 'Langchain', 'Huggingface']

const pool = preprocessQuestionBank(combined);
// Structure: {
//   'Generative AI': {
//     1: [q1, q2, ...],    // difficulty 1
//     2: [q3, q4, ...],    // difficulty 2
//     ...
//   },
//   'RAG/Vector': { ... },
//   ...
// }
```

---

## ⚠️ Why "No Question Available" Appears

### The Error Message Shows Up When:

```javascript
// Step5_AdaptiveAssessment.jsx, line 75 in pickNextForQuotas()
if (!currentQuestion) {
  // ... tries to pick a question
  // If ALL candidates are null:

  return <div>⚠️ No question available</div>;
}
```

### Possible Root Causes:

#### **Cause 1: Questions Loaded but Pool Structure Wrong** (MOST LIKELY)

```javascript
// preprocessQuestionBank() might not be organizing correctly
// Check console: [Step5] Preprocessed pool structure
// If pool tags are empty → Questions aren't being organized by tag
```

#### **Cause 2: Files Not Fetching**

```javascript
// Check console for:
// [Step5] MCQ response: 404
// [Step5] MCMS response: 404
// [Step5] Profiler response: 404
```

#### **Cause 3: All Questions Exhausted**

```javascript
// Can't happen on first question, but check:
// userProfile.questionsAsked should be empty Set
```

#### **Cause 4: No Tags Extracted**

```javascript
// Check console: [Step5] Unique tags: []
// If empty, questions don't have 'tag' field
```

---

## 📋 Console Debug Output Expected

When you navigate to Step 5, you should see:

```
[Step5] Loading question banks...
[Step5] Using base URL: /Adaptive-AI-Learning-Path-Discovery/
[Step5] Fetch paths: {
  mcqPath: '/Adaptive-AI-Learning-Path-Discovery/mcq_questions.json',
  mcmsPath: '/Adaptive-AI-Learning-Path-Discovery/mcms_questions.json',
  profilerPath: '/Adaptive-AI-Learning-Path-Discovery/profiler_questions.json'
}

[Step5] MCQ response: 200 OK
[Step5] MCMS response: 200 OK
[Step5] Profiler response: 200 OK

[Step5] Loaded question data: { mcq: 26, mcms: 1, profiler: 3 }

[Step5] Sample MCQ: {
  id: "genai_b_001",
  text: "What does 'Generative AI' primarily focus on creating?",
  tag: "Generative AI",
  type: "MCQ",
  options: [ ... ],
  correctAnswer: "Creating new content (text, images, etc.)"
}

[Step5] Sample MCMS: {
  id: "rag_d_005",
  text: "Which of the following are common components...",
  tag: "RAG/Vector",
  type: "MCMS",
  options: [ ... ],
  correctAnswers: [ ... ]
}

[Step5] Sample Profiler: {
  id: "prof_001",
  text: "What's your primary motivation for exploring AI courses...",
  tag: "Profiler",
  type: "MCQ",
  options: [ ... ]
}

[Step5] Filtered questions: { mcq: 26, mcms: 1, profiler: 3 }
[Step5] Combined pool size: 30
[Step5] Tags in questions: [
  'Generative AI', 'Generative AI', 'Generative AI', 'Generative AI',
  'Generative AI', 'Prompt Engineering', 'Generative AI',
  'Prompt Engineering', 'AI Ethics', 'RAG/Vector', ... (more)
]
[Step5] Unique tags: [
  'Generative AI',
  'Prompt Engineering',
  'AI Ethics',
  'RAG/Vector',
  'Langchain',
  'Huggingface'
]

[Step5] Preprocessed pool structure: {
  tags: [ 'Generative AI', 'Prompt Engineering', 'AI Ethics', 'RAG/Vector', 'Langchain', 'Huggingface' ],
  sampleTag: 'Generative AI',
  sampleTagDifficulties: [ '1', '2', '3' ]
}
```

---

## 🔧 How to Diagnose

### Option 1: Check Browser Console

1. **Open DevTools** → F12
2. **Go to Console** tab
3. **Navigate to Step 5**
4. **Copy all messages starting with `[Step5]`**
5. **Share them here**

### Option 2: Check Network Tab

1. **Open DevTools** → F12
2. **Go to Network** tab
3. **Navigate to Step 5**
4. **Look for these requests:**
   - `mcq_questions.json` → Should show **Status 200**
   - `mcms_questions.json` → Should show **Status 200**
   - `profiler_questions.json` → Should show **Status 200**
5. **If any show 404** → File path is wrong

### Option 3: Check Application Tab

1. **Open DevTools** → F12
2. **Go to Application** tab
3. **Local Storage** → Look for `adaptive-user-profile`
4. **Check it has:**
   ```json
   {
     "tagLevels": { "Generative AI": 5, "RAG/Vector": 5, ... },
     "questionsAsked": [],
     "tagScores": {}
   }
   ```

---

## 🎯 Next Steps

### If Console Shows All Files Loaded ✅

Problem is in `preprocessQuestionBank()` or `pickNextForQuotas()`:

- Check `src/utils/assessmentLogic.js`
- The pool structure might not be correct

### If Console Shows 404 ❌

File paths are wrong:

- Check if dev server is running at correct port
- Check if base URL is correct
- Try manual fetch: `fetch('/Adaptive-AI-Learning-Path-Discovery/mcq_questions.json')`

### If Console Shows No [Step5] Logs

Effect hook might not be triggering:

- Verify `appState.currentStep === 5` in Home.jsx
- Check if `useEffect` dependencies are correct

---

## 📊 Summary

**What We Know:**

- ✅ 30 questions exist across 3 files
- ✅ All questions have proper structure
- ✅ All questions have `tag` and `type` fields
- ✅ Files are in correct `public/` folder
- ✅ Fetch paths use `import.meta.env.BASE_URL`

**What We Need to Check:**

- [ ] Are files actually fetching? (Check Network tab)
- [ ] Are files being parsed correctly? (Check console logs)
- [ ] Is pool being organized by tag? (Check pool structure)
- [ ] Is pickNextForQuotas() finding questions? (Add more debugging)

**Most Likely Issue:**
The `preprocessQuestionBank()` function might not be correctly organizing questions, OR the first question selection logic has a bug.

---

## 🚀 Solution

Once you share the console output, we can pinpoint the exact issue and fix it. The questions are definitely loading - it's just a matter of how they're being organized and selected!
