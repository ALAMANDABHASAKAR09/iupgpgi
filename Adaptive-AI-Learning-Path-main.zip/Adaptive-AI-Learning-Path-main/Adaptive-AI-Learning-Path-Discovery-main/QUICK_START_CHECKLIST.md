# QUICK START CHECKLIST - Implementation Roadmap

## Adaptive AI Learning Path Discovery - Step-by-Step Fix Guide

**THIS DOCUMENT:** Quick reference checklist. Start here, reference other docs as needed.

---

## 📋 PRE-IMPLEMENTATION (READ FIRST)

**Read these documents in order:**

1. ✅ **DEBUGGING_AND_MODERNIZATION_GUIDE.md** - Understand all issues and fixes
2. ✅ **EXACT_CODE_PATCHES.md** - Get exact code to apply
3. ✅ This checklist - Follow step-by-step

**Tools needed:**

- VS Code with file editor
- Terminal/PowerShell
- Git (optional but recommended)
- Browser DevTools (Chrome/Firefox)

**Time estimate:** 2-3 hours for all patches

---

## 🔴 PHASE 1: CRITICAL BUG FIXES (BLOCKING)

These fixes MUST be applied first. Without them, the app will not work.

### ✅ Task 1.1: Fix Set Serialization Bug

**File:** `src/pages/Home.jsx`  
**Lines to replace:** 54-72  
**From:** DEBUGGING_AND_MODERNIZATION_GUIDE.md → PART 1 → Bug #1  
**Patch:** EXACT_CODE_PATCHES.md → PATCH 1

**Verification:**

```javascript
// In browser console after applying fix:
localStorage.setItem("test", JSON.stringify({ s: [1, 2, 3] }));
JSON.parse(localStorage.getItem("test"));
// Should return: { s: [1, 2, 3] }
```

**☑️ Status:** [ ] DONE

---

### ✅ Task 1.2: Fix Question Loading Race Condition

**File:** `src/pages/Home.jsx`  
**Lines to replace:** 91-126  
**From:** DEBUGGING_AND_MODERNIZATION_GUIDE.md → PART 1 → Bug #2  
**Patch:** EXACT_CODE_PATCHES.md → PATCH 2

**Verification:**

- Navigate to Step 5 in UI
- Open DevTools Console
- Should see logs like:
  ```
  Loaded question types: Set(7) ['MCQ', 'MCMS', ...]
  Loaded 45 MCQ, 12 MCMS, 5 Profiler questions
  ```
- Should NOT see repeated fetch requests

**☑️ Status:** [ ] DONE

---

### ✅ Task 1.3: Add Course Normalization Utility

**File:** `src/utils/api.js`  
**Replace:** Entire file  
**From:** EXACT_CODE_PATCHES.md → PATCH 3

**Verification:**

```javascript
// In browser console:
fetch("/final_beginner_courses.json")
  .then((r) => r.json())
  .then((data) => {
    const normalized = data.map((c) => ({
      id: c.id || c.course_id || "",
      title: c.title || c.courseTitle || "Untitled",
      level: c.level || c.Level || "Beginner",
    }));
    console.log(
      "All courses have required fields:",
      normalized.every((c) => c.id && c.title && c.level)
    );
  });
```

**☑️ Status:** [ ] DONE

---

### ✅ Task 1.4: Fix Question Type Detection

**File:** `src/pages/Home.jsx`  
**Lines to update:** 91-126 (already included in PATCH 2)

**Verification:**

- DevTools console should show question types like:
  ```
  Loaded question types: Set(7) [ 'MCQ', 'MCMS', 'MCQ-Reorder', ... ]
  ```
- No type errors in console
- Question count > 0 for each type

**☑️ Status:** [ ] DONE

---

### ✅ Task 1.5: Add Assessment Results Error Handling

**File:** `src/pages/Home.jsx`  
**Lines to replace:** 188-230  
**From:** EXACT_CODE_PATCHES.md → PATCH 4

**Verification:**

- Complete full assessment
- DevTools console shows:
  ```
  Assessment complete. Stored results: {...}
  ```
- Step 6 displays recommendations
- Page reload preserves results

**☑️ Status:** [ ] DONE

---

### ✅ Task 1.6: Add Input Validation to Step6_Results

**File:** `src/components/Wizard/Step6_Results.jsx`  
**Lines to replace:** 8-25  
**From:** EXACT_CODE_PATCHES.md → PATCH 5

**Verification:**

- If no results, shows amber warning box (not blank/error)
- If results missing analytics, automatically derives them
- Component doesn't crash with partial data

**☑️ Status:** [ ] DONE

---

### ✅ Task 1.7: Reset Explorer Filters on New Courses

**File:** `src/components/Explorer/Explorer.jsx`  
**Lines to update:** 23-24  
**From:** EXACT_CODE_PATCHES.md → PATCH 6

**Verification:**

- In Explorer, apply some filters
- Navigate away and back
- Filters should be reset
- Page counter reset to 1

**☑️ Status:** [ ] DONE

---

## 🟡 PHASE 2: ARCHITECTURAL PATTERNS (FOUNDATION)

These create infrastructure for better error handling and state management.

### ✅ Task 2.1: Create Error Boundary Component

**File (NEW):** `src/components/ErrorBoundary.jsx`  
**From:** EXACT_CODE_PATCHES.md → PATCH 7

**Steps:**

1. Create new file at path above
2. Copy code from PATCH 7
3. Save

**Verification:**

- File exists and has no syntax errors
- Component can be imported: `import ErrorBoundary from './components/ErrorBoundary'`

**☑️ Status:** [ ] DONE

---

### ✅ Task 2.2: Wrap App with Error Boundary

**File:** `src/App.jsx`  
**From:** EXACT_CODE_PATCHES.md → PATCH 8

**Steps:**

1. Add import at top: `import ErrorBoundary from './components/ErrorBoundary'`
2. Wrap Home component with `<ErrorBoundary>` tags
3. Test by intentionally causing an error (e.g., throw new Error in Home)
4. Remove test error
5. Verify normal app works

**Verification:**

- App starts without errors
- If an error is thrown, error boundary catches it gracefully

**☑️ Status:** [ ] DONE

---

### ✅ Task 2.3: Create useLoadingState Hook

**File (NEW):** `src/hooks/useLoadingState.js`  
**From:** EXACT_CODE_PATCHES.md → PATCH 9

**Steps:**

1. Create new file at path above
2. Copy code from PATCH 9
3. Save

**Verification:**

- File exists and imports correctly
- Can use in components: `const { data, isLoading } = useLoadingState(asyncFn)`

**☑️ Status:** [ ] DONE

---

## 🟢 PHASE 3: ACCESSIBILITY ENHANCEMENTS (USER EXPERIENCE)

These make the app accessible to all users.

### ✅ Task 3.1: Add Accessibility to Step1_Field

**File:** `src/components/Wizard/Step1_Field.jsx`  
**From:** EXACT_CODE_PATCHES.md → PATCH 10

**Changes:**

1. Ensure `<fieldset>` wraps options (not just `<div>`)
2. Add `<legend>` inside fieldset
3. Add `aria-label` to each input
4. Add `aria-describedby` linking to help text
5. Add `role="option"` and `aria-selected` to labels

**Verification:**

- Press Tab key → focus moves logically through options
- Screen reader reads: "AI/ML, button, not pressed, Core AI and Machine Learning"
- Keyboard Enter/Space selects options

**☑️ Status:** [ ] DONE

---

## 🔵 PHASE 4: BUILD & TEST

Final verification before considering done.

### ✅ Task 4.1: Validate Code Changes

**Steps:**

1. Open terminal in project root
2. Run: `npm run build`
3. Should see:
   ```
   ✓ built in X.XXs
   ```

**If errors:**

- Check that all syntax is correct
- Review PATCH sections for typos
- Check for mismatched quotes/brackets

**☑️ Status:** [ ] DONE

---

### ✅ Task 4.2: Start Development Server

**Steps:**

1. Terminal: `npm run dev`
2. Should see:
   ```
   VITE v7.X.X ready in XXXms
   Local:    http://localhost:5173/...
   ```
3. Open in browser

**If errors:**

- Check console for errors
- Verify all patches applied correctly
- Check file paths are exact

**☑️ Status:** [ ] DONE

---

### ✅ Task 4.3: Test Full Wizard Flow

**Steps:**

1. **Step 1:** Select a field → Next
2. **Step 2:** Select a level → Next
3. **Step 3:** Select topics → Next
4. **Step 4:** Select duration → Next
5. **Step 5:** Answer questions (should load 7 questions) → Complete
6. **Step 6:** Should show recommendations → Next
7. **Explorer:** Should show course grid with filters

**Expected Results:**

- No red errors in console
- All data displays correctly
- Navigation works without lag
- Results persist after page reload

**Fixes if broken:**

- Check console for error messages
- Verify JSON files are valid (use fix_json.js if needed)
- Check network tab for failed requests
- Review PATCH 1 and 2 if questions don't load

**☑️ Status:** [ ] DONE

---

### ✅ Task 4.4: Test Dark Mode

**Steps:**

1. In Inspector, toggle dark mode: `document.documentElement.classList.toggle('dark')`
2. Verify:
   - Background is dark
   - Text is readable (white on dark)
   - No elements are hidden
   - Borders visible
   - Shadows gone or subtle

**Fixes if broken:**

- Check components don't have `dark:bg-white` (inverted)
- Add missing `dark:*` classes
- Reference existing working components for pattern

**☑️ Status:** [ ] DONE

---

### ✅ Task 4.5: Test Mobile Responsiveness

**Steps:**

1. Open DevTools → Device Emulation
2. Test these widths:
   - 320px (small mobile)
   - 480px (mobile)
   - 768px (tablet)
   - 1024px (desktop)
   - 1440px (large desktop)

**Verify:**

- Text readable at all sizes
- Buttons tappable (not tiny)
- No horizontal scroll
- Images scale properly
- Cards stack on mobile

**Fixes if broken:**

- Add `sm:`, `md:`, `lg:` responsive classes
- Check grid layouts use `grid-cols-1 sm:grid-cols-2`
- Ensure padding adjusts with `px-4 sm:px-6 lg:px-8`

**☑️ Status:** [ ] DONE

---

### ✅ Task 4.6: Test Keyboard Navigation

**Steps:**

1. Press Tab repeatedly through entire app
2. Verify:
   - Focus moves to interactive elements only
   - Focus outline visible (ring)
   - Order is logical (top-to-bottom, left-to-right)
   - Can submit form with Space or Enter

**Fixes if broken:**

- Add `focus-visible:ring-2 focus-visible:ring-offset-2` to buttons
- Add `tabIndex={-1}` to non-interactive divs if needed
- Check labels are associated with inputs

**☑️ Status:** [ ] DONE

---

## 📊 COMPLETION CHECKLIST

### Phase 1: Critical Bugs (7 tasks)

- [ ] 1.1: Set Serialization
- [ ] 1.2: Question Loading Race Condition
- [ ] 1.3: Course Normalization
- [ ] 1.4: Question Type Detection
- [ ] 1.5: Assessment Results Handling
- [ ] 1.6: Step6 Input Validation
- [ ] 1.7: Explorer Filter Reset

**Phase 1 Status:** \_\_\_/7

---

### Phase 2: Architecture (3 tasks)

- [ ] 2.1: Create ErrorBoundary
- [ ] 2.2: Wrap App with ErrorBoundary
- [ ] 2.3: Create useLoadingState Hook

**Phase 2 Status:** \_\_\_/3

---

### Phase 3: Accessibility (1 task)

- [ ] 3.1: Add Accessibility to Step1

**Phase 3 Status:** \_\_\_/1

---

### Phase 4: Build & Test (6 tasks)

- [ ] 4.1: Validate Code Changes
- [ ] 4.2: Start Dev Server
- [ ] 4.3: Test Full Wizard Flow
- [ ] 4.4: Test Dark Mode
- [ ] 4.5: Test Mobile Responsiveness
- [ ] 4.6: Test Keyboard Navigation

**Phase 4 Status:** \_\_\_/6

---

## 🎯 SUCCESS CRITERIA

When complete, the app should:

✅ **Data Loading**

- Questions load from JSON without console errors
- Questions count > 0 for MCQ, MCMS, and Profiler
- Courses load and normalize properly

✅ **Assessment**

- Can answer all 7 questions
- Results display with correct percentage and level
- Results persist after page reload

✅ **Recommendations**

- Step 6 shows relevant course recommendations
- Recommendations have scores and tags
- No crashes or undefined data

✅ **UI/UX**

- Dark mode toggle works
- Mobile layout is readable
- Keyboard navigation works
- Accessibility labels present

✅ **Error Handling**

- Error boundary catches errors gracefully
- User-friendly error messages shown
- No unhandled promise rejections

---

## 🚀 DEPLOYMENT

After completing all phases:

1. **Commit changes:**

   ```bash
   git add .
   git commit -m "Fix data flow, add error handling, improve accessibility"
   ```

2. **Push to GitHub:**

   ```bash
   git push origin main
   ```

3. **GitHub Actions will:**

   - Build the app
   - Run tests
   - Deploy to GitHub Pages
   - Watch deployment in Actions tab

4. **Verify deployment:**
   - Visit https://ALAMANDABHASAKAR09.github.io/Adaptive-AI-Learning-Path-Discovery/
   - Test full flow on live site

---

## 📞 TROUBLESHOOTING

### "Questions not loading"

→ Check PATCH 2 application  
→ Verify JSON files exist in `/public`  
→ Check DevTools Network tab for 404s

### "Set cannot serialize" error

→ Check PATCH 1 applied correctly  
→ Verify `Array.from()` is used on Sets  
→ Check localStorage format

### "Dark mode not working"

→ Add `dark:` classes to components  
→ Test toggle: `document.documentElement.classList.toggle('dark')`  
→ Check for conflicting colors

### "Build fails"

→ Run `npm install` to ensure dependencies  
→ Check for syntax errors (quotes, brackets)  
→ Search error message in DEBUGGING_AND_MODERNIZATION_GUIDE.md

### "App crashes"

→ Check ErrorBoundary is installed (PATCH 7, 8)  
→ Open DevTools Console for full error  
→ Review stack trace against DEBUGGING guide

---

## ✨ NEXT STEPS (AFTER COMPLETION)

Once all patches applied and tested:

1. **Optional:** Apply accessibility to other step components (Steps 2-4)
2. **Optional:** Create QuestionContext for better state management
3. **Optional:** Add loading spinners while data fetches
4. **Consider:** Implement React Router for multi-page routing
5. **Consider:** Add user profile export (PDF)

---

## 📖 REFERENCE DOCUMENTS

- **Full debugging guide:** DEBUGGING_AND_MODERNIZATION_GUIDE.md
- **Code patches:** EXACT_CODE_PATCHES.md
- **Architecture patterns:** DEBUGGING_AND_MODERNIZATION_GUIDE.md → PART 2
- **Testing section:** DEBUGGING_AND_MODERNIZATION_GUIDE.md → PART 5

---

**You're ready to start! Begin with Phase 1, Task 1.1 and work down the list. Good luck! 🚀**
